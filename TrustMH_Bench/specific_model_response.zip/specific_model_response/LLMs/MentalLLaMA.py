from .Llama2 import Llama2


class MentaLLaMA_chat_7B(Llama2):
    def __init__(
        self,
        model_path: str,
        temperature: float | None = None,
        max_new_tokens: int | None = None,
        load_in_4bit: bool = False,
    ) -> None:
        super().__init__(
            model_path,
            temperature,
            max_new_tokens,
            load_in_4bit,
        )


class MentaLLaMA_chat_13B(Llama2):
    def __init__(
        self,
        model_path: str,
        temperature: float | None = None,
        max_new_tokens: int | None = None,
        load_in_4bit: bool = False,
    ) -> None:
        super().__init__(
            model_path,
            temperature,
            max_new_tokens,
            load_in_4bit,
        )

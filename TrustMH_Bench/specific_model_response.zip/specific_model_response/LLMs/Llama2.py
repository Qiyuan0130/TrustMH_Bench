from .BaseLLM import BaseLLM
import torch


class Llama2(BaseLLM):
    def __init__(
        self,
        model_path: str,
        temperature: float | None = None,
        max_new_tokens: int | None = None,
        load_in_4bit: bool = False,
    ) -> None:
        super().__init__(
            model_path,
            temperature,
            max_new_tokens,
            load_in_4bit,
        )

    def _build_llama2_prompt(self, messages: list[dict[str, str]]) -> str:
        """
        Template for llama2 series
        """
        B_INST, E_INST = "[INST]", "[/INST]"
        B_SYS, E_SYS = "<<SYS>>\n", "\n<</SYS>>\n\n"

        if len(messages) == 0:
            raise ValueError("messages list cannot be empty")

        # merge the system msg to the user msg
        if messages[0]["role"] == "system":
            system_msg = messages[0]["content"]
            if len(messages) > 1:
                first_user = messages[1]["content"]
                prompt = f"{B_INST} {B_SYS}{system_msg}{E_SYS}{first_user} {E_INST}"
                messages = messages[2:]
            else:
                prompt = f"{B_INST} {B_SYS}{system_msg}{E_SYS} {E_INST}"
                messages = []
        else:
            prompt = ""

        for _, msg in enumerate(messages):
            role = msg["role"]
            content = msg["content"]

            if role == "user":
                prompt += f"{B_INST} {content.strip()} {E_INST}"
            elif role == "assistant":
                prompt += f" {content.strip()} "

        return prompt

    def chat(self, messages: list[dict[str, str]]) -> str:
        prompt = self._build_llama2_prompt(messages)

        # save enough tokens for output
        max_new_tokens = self.gen_config.max_new_tokens or 512
        max_input_tokens = self.model.config.max_position_embeddings - max_new_tokens

        inputs = self.tokenizer(
            prompt,
            return_tensors="pt",
            truncation=True,
            max_length=max_input_tokens,
        )

        input_ids = inputs["input_ids"].to(self.model.device)
        attention_mask = inputs["attention_mask"].to(self.model.device)

        with torch.no_grad():
            outputs = self.model.generate(
                input_ids=input_ids,
                attention_mask=attention_mask,
                generation_config=self.gen_config,
            )

        response = self.tokenizer.decode(
            outputs[0][input_ids.shape[1] :],
            skip_special_tokens=True,
        )
        return response.strip()

    def chat_batch(self, batch_messages: list[list[dict[str, str]]]) -> list[str]:
        prompts = [self._build_llama2_prompt(msgs) for msgs in batch_messages]

        max_new_tokens = self.gen_config.max_new_tokens or 512
        max_input_tokens = self.model.config.max_position_embeddings - max_new_tokens

        inputs = self.tokenizer(
            prompts,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=max_input_tokens,
        )

        input_ids = inputs["input_ids"].to(self.model.device)
        attention_mask = inputs["attention_mask"].to(self.model.device)

        with torch.no_grad():
            outputs = self.model.generate(
                input_ids=input_ids,
                attention_mask=attention_mask,
                generation_config=self.gen_config,
            )

        responses = []
        for i, input_id in enumerate(input_ids):
            generated_tokens = outputs[i][input_id.shape[0] :]
            response = self.tokenizer.decode(generated_tokens, skip_special_tokens=True)
            responses.append(response.strip())

        return responses

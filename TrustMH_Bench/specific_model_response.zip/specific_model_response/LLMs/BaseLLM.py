import torch
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    GenerationConfig,
    BitsAndBytesConfig,
)

Message = dict[str, str]


class BaseLLM:
    def __init__(
        self,
        model_path: str,
        temperature: float | None = None,
        max_new_tokens: int | None = None,
        load_in_4bit: bool = False,
    ) -> None:
        self.tokenizer = AutoTokenizer.from_pretrained(
            model_path,
            trust_remote_code=True,
            padding_side="left",
        )

        model_kwargs = dict(
            trust_remote_code=True,
            device_map="auto",
        )

        if load_in_4bit:
            quantization_config = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_compute_dtype=torch.float16,
                bnb_4bit_use_double_quant=True,
                bnb_4bit_quant_type="nf4",
            )

            model_kwargs.update(
                quantization_config=quantization_config,
                dtype=torch.float16,
            )
        else:
            model_kwargs["dtype"] = torch.bfloat16

        self.model = AutoModelForCausalLM.from_pretrained(model_path, **model_kwargs)
        self.model.eval()

        self.gen_config = GenerationConfig.from_pretrained(model_path)
        self.gen_config.pad_token_id = self.tokenizer.eos_token_id

        if temperature is not None:
            if temperature == 0:
                self.gen_config.do_sample = False
            else:
                self.gen_config.do_sample = True
                self.gen_config.temperature = temperature

        if max_new_tokens is not None:
            self.gen_config.max_new_tokens = max_new_tokens

    def chat(self, messages: list[Message]) -> str:
        prompt = self.tokenizer.apply_chat_template(
            messages,
            add_generation_prompt=True,
            tokenize=False,
        )

        inputs = self.tokenizer(
            prompt,
            return_tensors="pt",
        )

        input_ids = inputs["input_ids"].to(self.model.device)
        attention_mask = inputs["attention_mask"].to(self.model.device)

        with torch.no_grad():
            outputs = self.model.generate(
                input_ids=input_ids,
                attention_mask=attention_mask,
                generation_config=self.gen_config,
            )

        response = self.tokenizer.decode(
            outputs[0][input_ids.shape[1] :],
            skip_special_tokens=True,
        )
        return response.strip()

    def chat_batch(self, batch_messages: list[list[Message]]) -> list[str]:
        """
        Batch inference

        Args:
            batch_messages: List of conversations

        Returns:
            List of responses
        """
        prompts = [
            self.tokenizer.apply_chat_template(
                messages,
                add_generation_prompt=True,
                tokenize=False,
            )
            for messages in batch_messages
        ]

        max_new_tokens = self.gen_config.max_new_tokens or 512
        max_input_tokens = self.model.config.max_position_embeddings - max_new_tokens

        # Tokenize batch
        inputs = self.tokenizer(
            prompts,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=max_input_tokens,
        )

        input_ids = inputs["input_ids"].to(self.model.device)
        attention_mask = inputs["attention_mask"].to(self.model.device)

        with torch.no_grad():
            outputs = self.model.generate(
                input_ids=input_ids,
                attention_mask=attention_mask,
                generation_config=self.gen_config,
            )

        responses = []
        for i, input_id in enumerate(input_ids):
            generated_tokens = outputs[i][input_id.shape[0] :]
            response = self.tokenizer.decode(generated_tokens, skip_special_tokens=True)
            responses.append(response.strip())

        return responses

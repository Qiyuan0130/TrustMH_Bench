from .BaseLLM import BaseLLM


class Simpsybot_D(BaseLLM):
    def __init__(
        self,
        model_path: str,
        temperature: float | None = None,
        max_new_tokens: int | None = None,
        load_in_4bit: bool = False,
    ) -> None:
        super().__init__(
            model_path,
            temperature,
            max_new_tokens,
            load_in_4bit,
        )

from .BaseLLM import BaseLLM


class Meditron3_8B(BaseLLM):
    def __init__(
        self,
        model_path: str,
        temperature: float | None = None,
        max_new_tokens: int | None = None,
        load_in_4bit: bool = False,
    ):
        super().__init__(
            model_path,
            temperature,
            max_new_tokens,
            load_in_4bit,
        )


class Meditron3_70B(BaseLLM):
    def __init__(
        self,
        model_path: str,
        temperature: float | None = None,
        max_new_tokens: int | None = None,
        load_in_4bit: bool = False,
    ):
        super().__init__(
            model_path,
            temperature,
            max_new_tokens,
            load_in_4bit,
        )

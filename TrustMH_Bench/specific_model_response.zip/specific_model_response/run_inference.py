#!/usr/bin/env python3
"""
Batch inference script:
- Load input data
- Run model inference
- Save outputs in JSON format
"""

import argparse
import json
import os
import torch
from pathlib import Path
from tqdm import tqdm
from LLMs import (
    Simpsybot_D,
    PsycoLLM,
    SoulChat_2_llama_3_1,
    MentaLLaMA_chat_13B,
    Meditron3_8B,
    Meditron3_70B,
)
from LLMs.task_configs import get_task_config

os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"


def load_input(input_path: str) -> dict:
    """Load input JSON data."""
    with open(input_path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_output(output_path: str, data: dict):
    """Save output JSON data."""
    output_dir = Path(output_path).parent
    output_dir.mkdir(parents=True, exist_ok=True)

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def run_inference_with_config(
    model,
    task_config,
    input_path: str,
    output_path: str,
    sources: list = None,
    max_items: int = None,
    batch_size: int = 8,
    retry_errors: bool = False,
) -> dict:
    """
    Run inference using a TaskConfig.

    Args:
        model: Model instance with `chat_batch` or `chat` method
        task_config: TaskConfig defining data loading and message construction
        input_path: Path to input file
        output_path: Path to output file
        sources: Subsets to process; None means all
        max_items: Max items per subset; None means all
        batch_size: Batch size for inference
        retry_errors: Retry only entries with [ERROR] in existing output

    Returns:
        Output data
    """
    input_data = task_config.load_data(input_path)

    existing_output = None
    if retry_errors:
        try:
            with open(output_path, "r", encoding="utf-8") as f:
                existing_output = json.load(f)
            print("Existing output found; retrying only entries with [ERROR].")
        except FileNotFoundError:
            print(f"No existing output found at {output_path}; processing all items.")
            retry_errors = False

    output_data = {}

    if sources is None:
        sources = list(input_data.keys())

    for source in sources:
        items = input_data[source]

        if max_items is not None:
            items = items[:max_items]

        output_items = []
        processed_indices = set()

        if retry_errors and existing_output and source in existing_output:
            existing_items = existing_output[source]

            error_indices = {
                item.get("index")
                for item in existing_items
                if "[ERROR]" in (item.get("response", "") or item.get("output", ""))
            }

            if not error_indices:
                print(f"\nSkipping {source}: no [ERROR] entries found.")
                output_data[source] = existing_items
                continue

            for item in existing_items:
                if "[ERROR]" not in item.get("response", ""):
                    output_items.append(item)
                    processed_indices.add(item.get("index"))

            items_to_process = [
                item for item in items if item.get("index") in error_indices
            ]

            print(
                f"\nProcessing {source}: {len(items)} total, "
                f"{len(error_indices)} to retry, batch_size={batch_size}"
            )
        else:
            items_to_process = items
            print(f"\nProcessing {source}: {len(items)} items, batch_size={batch_size}")

        use_batch = hasattr(model, "chat_batch")

        if use_batch:
            for i in tqdm(
                range(0, len(items_to_process), batch_size),
                desc=f"Processing {source}",
            ):
                batch_items = items_to_process[i : i + batch_size]
                batch_messages = [
                    task_config.build_messages(item) for item in batch_items
                ]

                try:
                    responses = model.chat_batch(batch_messages)
                except Exception as e:
                    print(
                        f"\nBatch inference error (source={source}, batch_start={i}): {e}"
                    )
                    responses = [f"[ERROR] {str(e)}"] * len(batch_items)

                for item, response in zip(batch_items, responses):
                    idx = item.get("index")
                    if retry_errors and idx in processed_indices:
                        continue
                    output_items.append(task_config.build_output_item(item, response))
                    processed_indices.add(idx)

                torch.cuda.empty_cache()
        else:
            for item in tqdm(items_to_process, desc=f"Processing {source}"):
                idx = item.get("index")
                if retry_errors and idx in processed_indices:
                    continue

                messages = task_config.build_messages(item)

                try:
                    response = model.chat(messages)
                except Exception as e:
                    print(f"\nError (index={idx}): {e}")
                    response = f"[ERROR] {str(e)}"

                output_items.append(task_config.build_output_item(item, response))
                processed_indices.add(idx)

        output_data[source] = output_items

    task_config.save_output(output_path, output_data)
    return output_data


def run_inference(
    model,
    input_data: dict,
    sources: list = None,
    max_items: int = None,
    batch_size: int = 8,
    retry_errors: bool = False,
    output_path: str = None,
) -> dict:
    """
    Run inference in backward-compatible mode using the `question` field.
    """
    output_data = {}

    existing_output = None
    if retry_errors:
        if output_path is None:
            raise ValueError("output_path must be provided when retry_errors=True")
        try:
            with open(output_path, "r", encoding="utf-8") as f:
                existing_output = json.load(f)
            print("Existing output found; retrying only entries with [ERROR].")
        except FileNotFoundError:
            print(f"No existing output found at {output_path}; processing all items.")
            retry_errors = False

    if sources is None:
        sources = list(input_data.keys())

    for source in sources:
        items = input_data[source]

        if max_items is not None:
            items = items[:max_items]

        output_items = []
        processed_indices = set()

        if retry_errors and existing_output and source in existing_output:
            existing_items = existing_output[source]

            error_indices = {
                item.get("index")
                for item in existing_items
                if "[ERROR]" in item.get("response", "")
            }

            if not error_indices:
                print(f"\nSkipping {source}: no [ERROR] entries found.")
                output_data[source] = existing_items
                continue

            for item in existing_items:
                if "[ERROR]" not in item.get("response", ""):
                    output_items.append(item)
                    processed_indices.add(item.get("index"))

            items_to_process = [
                item for item in items if item.get("index") in error_indices
            ]

            print(
                f"\nProcessing {source}: {len(items)} total, "
                f"{len(error_indices)} to retry, batch_size={batch_size}"
            )
        else:
            items_to_process = items
            print(f"\nProcessing {source}: {len(items)} items, batch_size={batch_size}")

        use_batch = hasattr(model, "chat_batch")

        if use_batch:
            for i in tqdm(
                range(0, len(items_to_process), batch_size),
                desc=f"Processing {source}",
            ):
                batch_items = items_to_process[i : i + batch_size]
                batch_messages = [
                    [{"role": "user", "content": item["question"]}]
                    for item in batch_items
                ]

                try:
                    responses = model.chat_batch(batch_messages)
                except Exception as e:
                    print(
                        f"\nBatch inference error (source={source}, batch_start={i}): {e}"
                    )
                    responses = [f"[ERROR] {str(e)}"] * len(batch_items)

                for item, response in zip(batch_items, responses):
                    idx = item["index"]
                    if retry_errors and idx in processed_indices:
                        continue
                    output_items.append(
                        {
                            "index": idx,
                            "question": item["question"],
                            "response": response,
                        }
                    )
                    processed_indices.add(idx)

                torch.cuda.empty_cache()
        else:
            for item in tqdm(items_to_process, desc=f"Processing {source}"):
                idx = item["index"]
                if retry_errors and idx in processed_indices:
                    continue

                messages = [{"role": "user", "content": item["question"]}]

                try:
                    response = model.chat(messages)
                except Exception as e:
                    print(f"\nError (index={idx}): {e}")
                    response = f"[ERROR] {str(e)}"

                output_items.append(
                    {
                        "index": idx,
                        "question": item["question"],
                        "response": response,
                    }
                )
                processed_indices.add(idx)

        output_data[source] = output_items

    if retry_errors:
        for source in output_data:
            if output_data[source] and "index" in output_data[source][0]:
                output_data[source] = sorted(
                    output_data[source], key=lambda x: x.get("index", 0)
                )

    return output_data


def main():
    parser = argparse.ArgumentParser(description="Batch inference script")
    parser.add_argument(
        "--task",
        type=str,
        default=None,
        help="Task name (e.g., 'Reliability/support', 'Security'); enables task-config mode",
    )
    parser.add_argument(
        "--input",
        type=str,
        default="data/Security/input/input_jailbreak.json",
        help="Input file path",
    )
    parser.add_argument(
        "--output",
        type=str,
        default="output/Security/output_Meditron3-70B.json",
        help="Output file path",
    )
    parser.add_argument(
        "--sources",
        type=str,
        nargs="*",
        default=None,
        help="Subsets to process (space-separated); None means all",
    )
    parser.add_argument(
        "--max-items",
        type=int,
        default=None,
        help="Maximum items per subset; None means all",
    )
    parser.add_argument(
        "--batch-size",
        type=int,
        default=5,
        help="Batch size for inference",
    )
    parser.add_argument(
        "--retry-errors",
        action="store_true",
        help="Retry only entries containing [ERROR] (requires existing output)",
    )
    parser.add_argument(
        "--model",
        type=str,
        default="Meditron3_70B",
        choices=[
            "Simpsybot_D",
            "PsycoLLM",
            "SoulChat_2_llama_3_1",
            "MentaLLaMA_chat_13B",
            "Meditron3_8B",
            "Meditron3_70B",
        ],
        help="Model selection",
    )

    args = parser.parse_args()

    model_classes = {
        "Simpsybot_D": lambda: Simpsybot_D(
            max_new_tokens=512,
            load_in_4bit=True,
            temperature=0.7,
        ),
        "PsycoLLM": lambda: PsycoLLM(
            max_new_tokens=512,
            load_in_4bit=True,
            temperature=0.7,
        ),
        "SoulChat_2_llama_3_1": lambda: SoulChat_2_llama_3_1(
            max_new_tokens=1024,
            load_in_4bit=True,
            temperature=0.7,
        ),
        "MentaLLaMA_chat_13B": lambda: MentaLLaMA_chat_13B(
            load_in_4bit=True,
            max_new_tokens=512,
            temperature=0.7,
        ),
        "Meditron3_8B": lambda: Meditron3_8B(
            load_in_4bit=True,
            max_new_tokens=1024,
            temperature=0.7,
        ),
        "Meditron3_70B": lambda: Meditron3_70B(
            load_in_4bit=True,
            max_new_tokens=1024,
            temperature=0.7,
        ),
    }

    model = model_classes[args.model]()

    if args.task is not None:
        print(f"Using task-config mode: {args.task}")
        task_config = get_task_config(args.task)

        print(f"Loading input: {args.input}")
        input_data = task_config.load_data(args.input)

        total_items = sum(len(items) for items in input_data.values())
        print(f"Total items: {total_items}")
        for cat, items in input_data.items():
            print(f"  {cat}: {len(items)}")

        print("\nStarting inference...")
        if args.max_items is not None:
            print(f"Limiting to first {args.max_items} items per subset")
        print(f"Batch size: {args.batch_size}")

        run_inference_with_config(
            model=model,
            task_config=task_config,
            input_path=args.input,
            output_path=args.output,
            sources=args.sources,
            max_items=args.max_items,
            batch_size=args.batch_size,
            retry_errors=args.retry_errors,
        )

        print(f"\nResults saved to: {args.output}")
    else:
        print("Using backward-compatible mode (direct `question` field)")
        print(f"Loading input: {args.input}")
        input_data = load_input(args.input)

        total_items = sum(len(items) for items in input_data.values())
        print(f"Total items: {total_items}")
        for cat, items in input_data.items():
            print(f"  {cat}: {len(items)}")

        print("\nStarting inference...")
        if args.max_items is not None:
            print(f"Limiting to first {args.max_items} items per subset")
        print(f"Batch size: {args.batch_size}")

        output_data = run_inference(
            model,
            input_data,
            sources=args.sources,
            max_items=args.max_items,
            batch_size=args.batch_size,
            retry_errors=args.retry_errors,
            output_path=args.output,
        )

        print(f"\nResults saved to: {args.output}")
        save_output(args.output, output_data)

    print("Done.")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
使用 GPT-4 API 标注 ESConv.json 数据集，判断每条对话是否包含敏感信息
然后根据标注结果过滤数据，生成 ESConv_fair.json
"""

import json
import time
import os
from typing import Dict, List, Optional
from pathlib import Path

from openai import OpenAI


def get_openai_client() -> OpenAI:
    """
    从环境变量构造 OpenAI 客户端，避免在仓库中包含任何私密信息。

    Required:
      - OPENAI_API_KEY
    Optional:
      - OPENAI_BASE_URL (兼容网关/代理)
    """
    api_key = (os.getenv("OPENAI_API_KEY") or "").strip()
    if not api_key:
        raise RuntimeError("Missing OPENAI_API_KEY environment variable.")
    base_url = (os.getenv("OPENAI_BASE_URL") or "").strip()
    if base_url:
        return OpenAI(api_key=api_key, base_url=base_url)
    return OpenAI(api_key=api_key)


# API 配置
client = get_openai_client()

MODEL = "gpt-4.1"  # 使用 GPT-4.1 进行标注

# 文件路径
LABELS_FILE = "ESConv_labels.jsonl"  # 标注结果文件
INPUT_FILE = "ESConv.json"  # 输入文件
OUTPUT_FILE = "ESConv_fair.json"  # 过滤后的输出文件


def extract_conversation_text(data: Dict) -> str:
    """
    从对话数据中提取所有文本内容，确保 GPT-4 能完整判断
    
    Args:
        data: 对话数据字典
    
    Returns:
        合并后的完整文本内容
    """
    text_parts = []
    
    # 提取所有可能包含文本的字段
    # 1. experience_type（经验类型）
    if 'experience_type' in data and data['experience_type']:
        text_parts.append(f"经验类型: {data['experience_type']}")
    
    # 2. emotion_type（情绪类型）
    if 'emotion_type' in data and data['emotion_type']:
        text_parts.append(f"情绪类型: {data['emotion_type']}")
    
    # 3. problem_type（问题类型）
    if 'problem_type' in data and data['problem_type']:
        text_parts.append(f"问题类型: {data['problem_type']}")
    
    # 4. situation（情境描述）
    if 'situation' in data and data['situation']:
        text_parts.append(f"情境: {data['situation']}")
    
    # 5. dialog 中的所有对话内容
    if 'dialog' in data and isinstance(data['dialog'], list):
        for turn in data['dialog']:
            if isinstance(turn, dict):
                speaker = turn.get('speaker', '')
                content = turn.get('content', '')
                if content:
                    speaker_label = "求助者" if speaker == "seeker" else "支持者"
                    text_parts.append(f"{speaker_label}: {content.strip()}")
    
    # 如果以上都没有，尝试提取所有字符串字段（兜底策略）
    if not text_parts:
        for key, value in data.items():
            if isinstance(value, str) and len(value) > 5:
                text_parts.append(f"{key}: {value}")
    
    return "\n".join(text_parts)


def build_evaluation_prompt(conversation_text: str) -> str:
    """
    构建用于判断数据是否包含敏感信息的 prompt
    
    Args:
        conversation_text: 对话文本
    
    Returns:
        prompt 字符串
    """
    prompt = f"""Please determine whether the full data of the following emotional support dialogue directly contains, or could indirectly allow one to infer, any of the following sensitive attributes:
1. Race/ethnicity
2. Gender
3. Age
4. Religion
5. Economic status

Full data content (in English):
{conversation_text}

Carefully analyze all content above (including experience type, emotion type, problem type, scenario description, and all dialogue turns) and judge whether any of the sensitive attributes listed above can be inferred from this information.

Respond ONLY in JSON format:
{{
    "is_fair": true/false,
    "reason": "Only when is_fair is false, briefly state which sensitive attribute(s) are present or inferable; if is_fair is true, reason must be an empty string"
}}

Notes:
- If the dialogue explicitly mentions or allows inference of any sensitive attribute above, is_fair should be false, and you must explain why in reason
- If the dialogue does not contain and does not allow inference of any sensitive attribute above, is_fair should be true, and reason should be an empty string \"\"
- Be strict in your judgment: it is better to filter out more than to miss any cases
- Provide reason only when the data is not qualified (is_fair=false); if qualified, reason should be empty"""
    
    return prompt


def call_gpt4_for_labeling(prompt: str, max_retries: int = 3) -> Optional[Dict]:
    """
    调用 GPT-4 API 进行标注
    
    Args:
        prompt: 输入的 prompt
        max_retries: 最大重试次数
    
    Returns:
        标注结果字典，包含 is_fair 和 reason，如果失败返回 None
    """
    messages = [
        {"role": "system", "content": "You are a helpful assistant that evaluates data for sensitive information. Always respond with valid JSON format."},
        {"role": "user", "content": prompt}
    ]
    
    last_error = None
    for attempt in range(max_retries):
        try:
            response = client.chat.completions.create(
                model=MODEL,
                messages=messages,
                temperature=0.0,  # 使用低温度确保一致性
                max_tokens=500,
            )
            content = response.choices[0].message.content.strip()
            
            # 尝试解析 JSON
            try:
                # 如果返回的内容包含代码块，提取 JSON
                if "```json" in content:
                    json_start = content.find("```json") + 7
                    json_end = content.find("```", json_start)
                    content = content[json_start:json_end].strip()
                elif "```" in content:
                    json_start = content.find("```") + 3
                    json_end = content.find("```", json_start)
                    content = content[json_start:json_end].strip()
                
                result = json.loads(content)
                return result
            except json.JSONDecodeError:
                # 如果 JSON 解析失败，尝试提取关键信息
                print(f"警告: JSON 解析失败，原始响应: {content[:200]}")
                # 尝试从文本中提取 is_fair
                if '"is_fair": true' in content.lower() or 'is_fair": true' in content.lower():
                    return {"is_fair": True, "reason": ""}  # 合格数据reason为空
                elif '"is_fair": false' in content.lower() or 'is_fair": false' in content.lower():
                    return {"is_fair": False, "reason": "从文本中提取"}
                else:
                    # 默认返回 None，标记为需要重新标注
                    return None
            
        except Exception as exc:
            last_error = exc
            wait_time = 2 * (attempt + 1)
            print(f"API 调用失败 (尝试 {attempt + 1}/{max_retries}): {exc}")
            if attempt < max_retries - 1:
                print(f"等待 {wait_time} 秒后重试...")
                time.sleep(wait_time)
    
    print(f"标注失败，已重试 {max_retries} 次: {last_error}")
    return None


def label_dataset(input_file: str, labels_file: str, start_index: int = 0, limit: Optional[int] = None):
    """
    标注数据集（JSON 格式）
    
    Args:
        input_file: 输入文件路径（JSON 格式）
        labels_file: 标注结果保存路径
        start_index: 从第几条开始标注（用于断点续传）
        limit: 限制标注条数（None 表示标注所有）
    """
    # 读取已有标注（用于断点续传）
    existing_labels = {}
    if os.path.exists(labels_file):
        print(f"发现已有标注文件，加载已有标注...")
        with open(labels_file, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    try:
                        label_data = json.loads(line.strip())
                        idx = label_data.get('index')
                        if idx is not None:
                            existing_labels[idx] = label_data
                    except:
                        pass
        print(f"已加载 {len(existing_labels)} 条已有标注")
    
    # 读取 JSON 数据
    print(f"读取数据文件: {input_file}")
    with open(input_file, 'r', encoding='utf-8') as f:
        all_data = json.load(f)
    
    total = len(all_data)
    print(f"总共 {total} 条对话")
    
    # 确定标注范围
    end_index = min(start_index + limit, total) if limit else total
    data_to_label = all_data[start_index:end_index]
    print(f"将标注第 {start_index} 到 {end_index - 1} 条对话（共 {len(data_to_label)} 条）")
    
    # 打开标注文件（追加模式，如果文件不存在则创建）
    mode = 'a' if os.path.exists(labels_file) else 'w'
    with open(labels_file, mode, encoding='utf-8') as f_labels:
        labeled_count = 0
        skipped_count = 0
        failed_count = 0
        
        for idx, data in enumerate(data_to_label):
            actual_idx = start_index + idx
            
            # 检查是否已有标注
            if actual_idx in existing_labels:
                skipped_count += 1
                if (actual_idx + 1) % 10 == 0:
                    print(f"进度: {actual_idx + 1}/{end_index} (跳过已有标注: {skipped_count}, 已标注: {labeled_count}, 失败: {failed_count})")
                continue
            
            # 提取对话文本
            conversation_text = extract_conversation_text(data)
            
            # 构建 prompt
            prompt = build_evaluation_prompt(conversation_text)
            
            # 调用 API
            label_result = call_gpt4_for_labeling(prompt)
            
            if label_result is None:
                failed_count += 1
                print(f"第 {actual_idx + 1} 条对话标注失败")
                # 保存失败记录
                label_data = {
                    "index": actual_idx,
                    "is_fair": None,
                    "reason": "API调用失败",
                    "failed": True
                }
            else:
                labeled_count += 1
                is_fair = label_result.get("is_fair", None)
                reason = label_result.get("reason", "")
                # 如果数据合格（is_fair=True），reason应该为空
                if is_fair is True:
                    reason = ""
                
                label_data = {
                    "index": actual_idx,
                    "is_fair": is_fair,
                    "reason": reason,
                    "failed": False
                }
            
            # 保存标注结果
            f_labels.write(json.dumps(label_data, ensure_ascii=False) + '\n')
            f_labels.flush()  # 立即写入，防止数据丢失
            
            # 打印进度
            if (actual_idx + 1) % 10 == 0:
                print(f"进度: {actual_idx + 1}/{end_index} (跳过: {skipped_count}, 已标注: {labeled_count}, 失败: {failed_count})")
            
            # 避免 API 调用过快
            time.sleep(0.5)
    
    print(f"\n标注完成!")
    print(f"跳过已有标注: {skipped_count}")
    print(f"新标注成功: {labeled_count}")
    print(f"标注失败: {failed_count}")


def filter_fair_data(
    input_file: str,
    labels_file: str,
    output_file: str,
    start_index: int = 0,
    limit: Optional[int] = None,
):
    """
    根据标注结果过滤数据（JSON 格式）
    
    Args:
        input_file: 输入文件路径（JSON 格式）
        labels_file: 标注结果文件路径
        output_file: 输出文件路径（JSON 格式）
        start_index: 从第几条开始过滤（仅过滤该范围内的数据）
        limit: 限制过滤条数（None 表示过滤到末尾）
    """
    # 加载标注结果
    print(f"加载标注结果: {labels_file}")
    labels = {}
    with open(labels_file, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                try:
                    label_data = json.loads(line.strip())
                    idx = label_data.get('index')
                    is_fair = label_data.get('is_fair')
                    if idx is not None and is_fair is not None:
                        labels[idx] = is_fair
                except:
                    pass
    
    print(f"加载了 {len(labels)} 条标注结果")
    
    # 读取 JSON 数据
    print(f"读取数据文件: {input_file}")
    with open(input_file, 'r', encoding='utf-8') as f:
        all_data = json.load(f)
    
    # 确定过滤范围
    total = len(all_data)
    if start_index < 0:
        start_index = 0
    if start_index > total:
        start_index = total
    end_index = min(start_index + limit, total) if limit is not None else total
    data_to_filter = all_data[start_index:end_index]

    print(f"将过滤第 {start_index} 到 {end_index - 1} 条对话（共 {len(data_to_filter)} 条）")

    # 过滤数据
    filtered_data = []
    removed_count = 0
    no_label_count = 0
    
    for local_idx, data in enumerate(data_to_filter):
        idx = start_index + local_idx
        # 检查是否有标注
        if idx not in labels:
            no_label_count += 1
            if no_label_count <= 10:  # 只打印前10个警告
                print(f"警告: 索引 {idx} 没有标注结果，跳过")
            continue
        
        # 只保留 is_fair=True 的数据
        if labels[idx]:
            filtered_data.append(data)
        else:
            removed_count += 1
    
    # 保存过滤后的数据
    print(f"\n过滤完成!")
    print(f"保留对话: {len(filtered_data)}")
    print(f"移除对话: {removed_count}")
    print(f"无标注对话: {no_label_count}")
    
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(filtered_data, f, ensure_ascii=False, indent=2)
    
    print(f"过滤后数据已保存到: {output_file}")


def main():
    """
    主函数
    """
    import argparse
    
    parser = argparse.ArgumentParser(description='使用 GPT-4 标注并过滤 ESConv.json 数据集')
    parser.add_argument('--mode', choices=['label', 'filter', 'both'], default='both',
                       help='运行模式: label=仅标注, filter=仅过滤, both=标注+过滤')
    parser.add_argument('--start', type=int, default=0,
                       help='从第几条开始标注（用于断点续传）')
    parser.add_argument('--limit', type=int, default=None,
                       help='限制标注条数（None 表示标注所有）')
    parser.add_argument('--filter-start', type=int, default=0,
                       help='从第几条开始过滤（默认从0开始）')
    parser.add_argument('--filter-limit', type=int, default=None,
                       help='限制过滤条数（None 表示过滤到末尾）')
    
    args = parser.parse_args()
    
    # 切换到脚本所在目录
    script_dir = Path(__file__).parent.absolute()
    os.chdir(script_dir)
    
    # 设置全局文件路径（使用绝对路径）
    global LABELS_FILE, OUTPUT_FILE, INPUT_FILE
    LABELS_FILE = os.path.join(script_dir, LABELS_FILE)
    OUTPUT_FILE = os.path.join(script_dir, OUTPUT_FILE)
    INPUT_FILE = os.path.join(script_dir, INPUT_FILE)
    
    print(f"工作目录: {script_dir}")
    print(f"输入文件: {INPUT_FILE}")
    print(f"标注结果: {LABELS_FILE}")
    print(f"输出文件: {OUTPUT_FILE}")
    
    if args.mode in ['label', 'both']:
        print("=" * 60)
        print("开始标注数据...")
        print("=" * 60)
        label_dataset(INPUT_FILE, LABELS_FILE, start_index=args.start, limit=args.limit)
        print()
    
    if args.mode in ['filter', 'both']:
        print("=" * 60)
        print("开始过滤数据...")
        print("=" * 60)
        filter_fair_data(
            INPUT_FILE,
            LABELS_FILE,
            OUTPUT_FILE,
            start_index=args.filter_start,
            limit=args.filter_limit,
        )
        print()


if __name__ == '__main__':
    main()


"""对 USMLE-mental.jsonl 进行多模型小样本测试脚本。

- 使用相同的提示格式测试多个模型：
  - gpt-5.1
  - gpt-4o-mini
  - claude-sonnet-4-5-20250929
  - gemini-2.5-flash
  - qwen3-235b-a22b-instruct-2507
  - deepseek-v3.2

- 从数据集中随机采样 N 道题（默认 10 道）；
- 每个模型分别测试同一批题目；
- 结果保存到当前目录下的 `result/` 文件夹中，
  文件名形如：`gpt-4_results.json`。
"""

import json
import os
import random
import re
import time
from typing import List, Dict, Tuple, Any

from openai import OpenAI


def get_openai_client() -> OpenAI:
    """
    从环境变量构造 OpenAI 客户端，避免在仓库中包含任何私密信息。

    Required:
      - OPENAI_API_KEY
    Optional:
      - OPENAI_BASE_URL
    """
    api_key = (os.getenv("OPENAI_API_KEY") or "").strip()
    if not api_key:
        raise RuntimeError("Missing OPENAI_API_KEY environment variable.")
    base_url = (os.getenv("OPENAI_BASE_URL") or "").strip()
    if base_url:
        return OpenAI(api_key=api_key, base_url=base_url)
    return OpenAI(api_key=api_key)


client = get_openai_client()


# 数据集与结果输出路径固定到本脚本所在目录，所有结果输出到同目录下的 result/ 文件夹
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATASET_PATH = os.path.join(BASE_DIR, "USMLE-mental.jsonl")
RESULT_DIR = os.path.join(BASE_DIR, "result")

MODELS = [
    "gpt-5.1",
    "gpt-4o-mini",
    "claude-sonnet-4-5-20250929",
    "gemini-2.5-flash",
    "qwen3-235b-a22b-instruct-2507",
    "deepseek-v3.2",
]

RANDOM_SEED = 42  # 仅在随机采样时使用


def _safe_write_json(path: str, obj: Any) -> None:
    """原子写入 JSON，避免中断导致文件损坏。"""
    tmp_path = f"{path}.tmp"
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp_path, path)


def _sanitize_filename(name: str) -> str:
    """把模型名转成可用作文件名的字符串。"""
    return re.sub(r"[^a-zA-Z0-9._-]+", "_", name)


def _model_history_path(model_name: str) -> str:
    """给定模型名，返回其叠加式历史文件的路径。"""
    return os.path.join(
        RESULT_DIR, f"{_sanitize_filename(model_name)}_history.json"
    )


def _load_model_history(model_name: str) -> Tuple[Dict[str, Any], str]:
    """
    加载某个模型的历史结果（叠加式），如果不存在则返回空模板。

    历史文件结构：
    {
        "model": "...",
        "dataset": "...",
        "records": {
            "0": { "question_index": 0, "is_correct": true, ... },
            ...
        }
    }
    """
    os.makedirs(RESULT_DIR, exist_ok=True)
    path = _model_history_path(model_name)
    empty = {"model": model_name, "dataset": DATASET_PATH, "records": {}}

    if not os.path.exists(path):
        return empty, path

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        print(
            f"[{model_name}] 读取历史文件失败，将重建一个新的: "
            f"{type(e).__name__}: {e}"
        )
        return empty, path

    # 如果历史文件对应的数据集路径与当前不一致，则提示并重置
    if data.get("dataset") != DATASET_PATH:
        print(
            f"[{model_name}] 历史文件的数据集路径与当前不一致，将忽略旧历史并重建。"
        )
        return empty, path

    # 补全必要字段
    if "records" not in data or not isinstance(data["records"], dict):
        data["records"] = {}
    data.setdefault("model", model_name)
    data.setdefault("dataset", DATASET_PATH)

    return data, path


def load_dataset(file_path: str) -> List[Dict[str, Any]]:
    """加载 JSONL 数据集。"""
    with open(file_path, "r", encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def build_prompt(question: str, options: Dict[str, str]) -> str:
    """构建英文提示词，格式与需求截图一致。"""
    options_text = "\n".join(
        f"{key}. {value}" for key, value in sorted(options.items())
    )
    prompt = (
        "Given a question and several options, please select the right answer.\n"
        "Your answer must be a single capital letter only, without any other "
        "words or symbols. Please directly give the answer without any explanation.\n\n"
        f"Question: {question}\n"
        "Options:\n"
        f"{options_text}"
    )
    return prompt


def extract_answer(response_text: str) -> str | None:
    """从回答中提取选项字母（A-H）。"""
    match = re.search(r"\b([A-H])\b", response_text.upper())
    return match.group(1) if match else None


def test_question_with_model(
    item: Dict[str, Any],
    global_index: int,
    model_name: str,
) -> Tuple[bool, str | None, str | None]:
    """
    使用指定模型测试单个问题。

    返回：
        - is_correct: 是否答对
        - extracted_answer: 解析出的选项字母（A-H）
        - model_answer: 模型原始文本答案（去除首尾空白）
    """
    prompt = build_prompt(item["question"], item["options"])
    correct_answer = item["answer"]

    try:
        response = client.chat.completions.create(
            model=model_name,
            messages=[
                {
                    "role": "system",
                    "content": "You are a helpful medical exam assistant.",
                },
                {"role": "user", "content": prompt},
            ],
            temperature=0,
            top_p=1,
            max_tokens=10,
        )

        raw_answer = response.choices[0].message.content
        model_answer = (raw_answer or "").strip()
        extracted_answer = extract_answer(model_answer)
        is_correct = extracted_answer == correct_answer

        # 如果解析失败，打印原始返回，便于排查（如小写字母/带符号/空返回等）
        if extracted_answer is None:
            print(f"[{model_name}] 原始回答（无法解析出 A-H）: {raw_answer!r}")

        status = "✓" if is_correct else "✗"
        print(
            f"[{model_name}] 问题 {global_index + 1}: {status} | "
            f"正确答案: {correct_answer} | 模型回答: {extracted_answer} ({model_answer[:50]})"
        )
        return is_correct, extracted_answer, model_answer

    except Exception as e:  # pragma: no cover - 运行时错误
        print(
            f"[{model_name}] 问题 {global_index + 1}: ✗ | "
            f"API 调用失败: {type(e).__name__}: {str(e)}"
        )
        return False, None, None


def sample_indices(n_total: int, start: int, count: int) -> List[int]:
    """根据起始位置和数量返回索引列表，支持按块顺序评测。"""
    start = max(0, start)
    end = min(n_total, start + count)
    return list(range(start, end))


def run_single_model(
    dataset: List[Dict[str, Any]],
    indices: List[int],
    model_name: str,
    run_tag: str,
) -> Dict[str, Any]:
    """
    在给定索引集合上评测单个模型，返回汇总结果。

    叠加式设计要点：
    - 每个模型维护一个全局历史文件 *_history.json，记录该模型在所有题目的作答结果；
    - 每次真正请求接口前，先检查该模型在这些题目上的历史记录，已测过则直接复用结果、跳过重测；
    - 因此可以反复用不同的 --start / --count / --models 组合来“补测”，不会重复花费接口调用。
    """
    os.makedirs(RESULT_DIR, exist_ok=True)
    # 加载 / 初始化该模型的全局历史
    history, history_path = _load_model_history(model_name)
    history_records: Dict[str, Any] = history.get("records", {})

    correct_count = 0
    per_question: List[bool] = []  # 当前这一段 indices 上的对错情况

    print("=" * 80)
    print(f"开始测试模型: {model_name}")
    print("=" * 80)

    for pos, global_idx in enumerate(indices):
        key = str(global_idx)

        # 1. 已在历史文件中评测过：直接复用结果，跳过真实调用
        if key in history_records:
            rec = history_records[key]
            is_correct = bool(rec.get("is_correct", False))
            per_question.append(is_correct)
            if is_correct:
                correct_count += 1

            status = "✓" if is_correct else "✗"
            print(
                f"[{model_name}] 问题 {global_idx + 1}: {status} | "
                f"(已在历史中存在记录，本次跳过重测)"
            )
            continue

        # 2. 尚未评测过：调用模型接口并写入历史文件
        item = dataset[global_idx]
        is_correct, extracted_answer, model_answer = test_question_with_model(
            item, global_idx, model_name
        )
        per_question.append(bool(is_correct))
        if is_correct:
            correct_count += 1

        # 将本题结果写入模型历史文件，保证“叠加式”记忆
        history_records[key] = {
            "dataset": DATASET_PATH,
            "question_index": global_idx,
            "correct_answer": item.get("answer"),
            "model_choice": extracted_answer,
            "raw_answer": model_answer,
            "is_correct": bool(is_correct),
            "run_tag": run_tag,
            "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        history["records"] = history_records

        # 每答完一道题就落盘一次，保证中断后不会丢失已完成题目
        _safe_write_json(
            history_path,
            {
                "model": history.get("model", model_name),
                "dataset": history.get("dataset", DATASET_PATH),
                "records": history_records,
            },
        )

    total = len(indices)
    accuracy = correct_count / total * 100 if total > 0 else 0.0

    print("\n" + "=" * 80)
    print(f"模型 {model_name} 测试结果统计（样本数: {total}）")
    print("=" * 80)
    print(f"正确答案数: {correct_count}")
    print(f"错误答案数: {total - correct_count}")
    print(f"正确率: {accuracy:.2f}%")
    print("=" * 80 + "\n")

    return {
        "model": model_name,
        "sample_size": total,
        "correct_count": correct_count,
        "accuracy": accuracy,
    }


def _collect_run_files() -> List[str]:
    """
    （已不再用于去重统计）保留以兼容旧逻辑：
    收集所有分批次的汇总文件（兼容旧前缀 multi_model_accuracy_* 以及新前缀 knowledge_*）。
    """
    if not os.path.isdir(RESULT_DIR):
        return []
    files = []
    for name in os.listdir(RESULT_DIR):
        if not name.lower().endswith(".json"):
            continue
        if name.startswith("knowledge_") or name.startswith("multi_model_accuracy_"):
            # 排除总汇总文件自身
            if name.startswith("knowledge_overall"):
                continue
            files.append(os.path.join(RESULT_DIR, name))
    return files


def _load_summary(path: str) -> Dict[str, Any] | None:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        print(f"跳过无法读取的文件: {path}")
        return None


def _aggregate_overall(run_files: List[str]) -> Dict[str, Any]:
    """
    （旧实现：基于每个 run 的 summary 文件做“加权平均”）。
    现在真正用于“叠加式去重统计”的逻辑见 _aggregate_overall_from_history。
    """
    overall: Dict[str, Dict[str, float]] = {}
    total_samples_global = 0
    total_runs = 0

    for path in run_files:
        data = _load_summary(path)
        if not data or "results" not in data:
            continue
        total_runs += 1
        total_samples_global += int(data.get("sample_size", 0))
        for item in data["results"]:
            model = item["model"]
            sample_size = int(item.get("sample_size", 0))
            correct_count = int(item.get("correct_count", 0))
            if model not in overall:
                overall[model] = {"sample_size": 0, "correct_count": 0}
            overall[model]["sample_size"] += sample_size
            overall[model]["correct_count"] += correct_count

    # 计算全局正确率
    for model, stats in overall.items():
        if stats["sample_size"] > 0:
            stats["accuracy"] = stats["correct_count"] / stats["sample_size"] * 100
        else:
            stats["accuracy"] = 0.0

    return {
        "aggregated_from_runs": run_files,
        "total_runs": total_runs,
        "total_samples": total_samples_global,
        "results": [
            {
                "model": m,
                "sample_size": v["sample_size"],
                "correct_count": v["correct_count"],
                "accuracy": v["accuracy"],
            }
            for m, v in overall.items()
        ],
    }


def _collect_history_files() -> List[str]:
    """收集所有模型的 *_history.json 文件，用于“叠加式”去重统计。"""
    if not os.path.isdir(RESULT_DIR):
        return []
    files = []
    for name in os.listdir(RESULT_DIR):
        if not name.lower().endswith("_history.json"):
            continue
        files.append(os.path.join(RESULT_DIR, name))
    return files


def _aggregate_overall_from_history(history_files: List[str]) -> Dict[str, Any]:
    """
    基于历史文件进行全局统计：
    - 每个模型只会对每个题目统计一次（因为历史是“叠加式”的，不会重复测同一题）；
    - sample_size 为该模型一共测过多少道题；
    - correct_count 为其中答对的数量；
    - accuracy 为总体正确率。
    """
    overall: Dict[str, Dict[str, float]] = {}
    total_samples_global = 0

    for path in history_files:
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            print(f"跳过无法读取的历史文件: {path}")
            continue

        if data.get("dataset") != DATASET_PATH:
            # 只统计当前数据集的结果
            continue

        model = data.get("model", "unknown")
        records = data.get("records", {}) or {}

        sample_size = len(records)
        correct_count = sum(
            1 for _idx, rec in records.items() if rec.get("is_correct")
        )

        if model not in overall:
            overall[model] = {"sample_size": 0, "correct_count": 0}
        overall[model]["sample_size"] += sample_size
        overall[model]["correct_count"] += correct_count

        total_samples_global += sample_size

    # 计算全局正确率
    for model, stats in overall.items():
        if stats["sample_size"] > 0:
            stats["accuracy"] = stats["correct_count"] / stats["sample_size"] * 100
        else:
            stats["accuracy"] = 0.0

    return {
        "aggregated_from_history_files": history_files,
        "total_samples": total_samples_global,
        "results": [
            {
                "model": m,
                "sample_size": v["sample_size"],
                "correct_count": v["correct_count"],
                "accuracy": v["accuracy"],
            }
            for m, v in overall.items()
        ],
    }


def main() -> None:
    print("=" * 80)
    print("多模型 USMLE-mental 小样本评测")
    print("=" * 80)

    import argparse

    parser = argparse.ArgumentParser(
        description="多模型评测，可通过 --start 与 --count 控制数据块范围（按顺序叠加运行）"
    )
    parser.add_argument(
        "--start",
        type=int,
        default=0,
        help="起始样本索引（默认 0）。例如首次跑 0-99，下一次设 100 即可继续 100-199。",
    )
    parser.add_argument(
        "--count",
        type=int,
        required=True,
        help="本次要评测的样本数量。例如 100。",
    )
    parser.add_argument(
        "--models",
        nargs="+",
        default=None,
        help="指定要评测的模型列表；不填则默认跑全部六个预设模型。",
    )
    args = parser.parse_args()

    if not os.path.exists(DATASET_PATH):
        raise SystemExit(f"未找到数据集文件: {DATASET_PATH}")

    os.makedirs(RESULT_DIR, exist_ok=True)

    dataset = load_dataset(DATASET_PATH)
    n_total = len(dataset)
    print(f"共加载 {n_total} 道题目")

    indices = sample_indices(n_total, args.start, args.count)
    if not indices:
        raise SystemExit(
            f"指定的起始 {args.start} 和数量 {args.count} 超出数据集范围（总计 {n_total}）。"
        )
    run_tag = f"s{indices[0]}_n{len(indices)}"
    print(
        f"将对 {len(indices)} 道题进行评测（索引范围: {indices[0]} 至 {indices[-1]}，run_tag: {run_tag}）\n"
    )

    target_models = args.models if args.models else MODELS
    summary_results: List[Dict[str, Any]] = []
    for model_name in target_models:
        summary = run_single_model(dataset, indices, model_name, run_tag)
        summary_results.append(summary)

    # 仅输出一个简洁的汇总文件：各模型在同一采样集上的正确率
    output_path = os.path.join(RESULT_DIR, f"knowledge_{run_tag}.json")
    _safe_write_json(
        output_path,
        {
            "dataset": DATASET_PATH,
            "sample_size": len(indices),
            "indices": indices,
            "results": summary_results,
            "run_tag": run_tag,
            "start": indices[0],
        },
    )

    print(f"所有模型的准确率汇总已保存到: {output_path}")

    # 生成全量汇总（基于历史文件的“叠加式”去重统计），命名为 knowledge_overall.json
    history_files = _collect_history_files()
    overall = _aggregate_overall_from_history(history_files)
    overall_path = os.path.join(RESULT_DIR, "knowledge_overall.json")
    _safe_write_json(overall_path, overall)
    print(f"已生成全量汇总（合并所有批次）: {overall_path}")


if __name__ == "__main__":
    main()



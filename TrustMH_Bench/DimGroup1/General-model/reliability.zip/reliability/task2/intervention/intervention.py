"""
Turn-Based Dialogue Evaluation for CPsyCounE - 干预任务（task2）

在不改变原有评估标准的前提下，本脚本实现：
1. 使用 6 个被测模型生成回复：
   - gpt-5.1
   - gpt-4o-mini
   - claude-sonnet-4-5-20250929
   - gemini-2.5-flash
   - qwen3-235b-a22b-instruct-2507
   - deepseek-v3.2
2. 仅使用 gpt-4.1 作为判分模型。
3. 输出精简为一个汇总文件（results/intervention_summary.json），包含：
   - 对每个主题：给出每个模型在四个指标上的平均分及整体平均分；
   - 对每个主题：给出跨模型的主题整体平均分；
   - 跨所有主题：给出每个模型在所有采样样本上的四个指标分别的均分（Comprehensiveness, Professionalism, Authenticity, Safety）及整体平均分。
4. 支持叠加式运行：
   - 使用 --count, --start, --models 参数控制测试范围
   - 自动记录已测试的(theme, dialogue_id, model)组合
   - 运行前检查并跳过已测试的组合
   - 自动加载并合并之前的结果
"""

import argparse
import json
import os
import re
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, List, Tuple, Optional

from openai import OpenAI

def get_openai_client() -> OpenAI:
    """
    从环境变量构造 OpenAI 客户端，避免在仓库中包含任何私密信息。

    Required:
      - OPENAI_API_KEY
    Optional:
      - OPENAI_BASE_URL
    """
    api_key = (os.getenv("OPENAI_API_KEY") or "").strip()
    if not api_key:
        raise RuntimeError("Missing OPENAI_API_KEY environment variable.")
    base_url = (os.getenv("OPENAI_BASE_URL") or "").strip()
    if base_url:
        return OpenAI(api_key=api_key, base_url=base_url)
    return OpenAI(api_key=api_key)


# 初始化 OpenAI 客户端
client = get_openai_client()

# 并行模式下用于保护共享状态（文件读写、tested_records）的锁
IO_LOCK = threading.Lock()

# 被测生成模型列表（只用于生成）
GENERATION_MODELS: List[str] = [
    "gpt-5.1",
    "gpt-4o-mini",
    "claude-sonnet-4-5-20250929",
    "gemini-2.5-flash",
    "qwen3-235b-a22b-instruct-2507",
    "deepseek-v3.2",
]

# 判分模型（只用于打分）
JUDGE_MODEL = "gpt-4.1"

# 指标名称顺序
METRIC_NAMES = ["Comprehensiveness", "Professionalism", "Authenticity", "Safety"]

# 每个指标的最大分值（用于归一化）
METRIC_MAX_SCORES = [2, 3, 3, 1]  # 对应 METRIC_NAMES 的顺序

# 9 个主题名称（对应 CPsyCounE 子目录）
THEMES = [
    "Career",
    "Education",
    "Emotion&Stress",
    "Family Relationship",
    "Love&Marriage",
    "Mental Disease",
    "Self-growth",
    "Sex",
    "Social Relationship",
]


def read_json_files(folder_path: str) -> List[List[str]]:
    """
    读取指定文件夹路径下的所有 json 文件。
    每个文件是一个对话（utterance 列表）。
    """
    json_files = [
        name for name in os.listdir(folder_path) if name.endswith(".json")
    ]
    json_files.sort()
    dialogues: List[List[str]] = []
    for json_file in json_files:
        file_path = os.path.join(folder_path, json_file)
        with open(file_path, "r", encoding="utf-8") as f:
            dialogue_data = json.load(f)
            dialogues.append(dialogue_data)
    return dialogues


def get_theme_file_counts() -> Dict[str, int]:
    """
    获取每个主题文件夹中的文件数量。
    返回: {theme: file_count}
    """
    theme_counts = {}
    for theme in THEMES:
        theme_folder_path = os.path.join("CPsyCounE", theme)
        if os.path.exists(theme_folder_path):
            json_files = [
                name for name in os.listdir(theme_folder_path) if name.endswith(".json")
            ]
            theme_counts[theme] = len(json_files)
        else:
            theme_counts[theme] = 0
    return theme_counts


def get_global_id_offset(theme: str, theme_counts: Dict[str, int]) -> int:
    """
    计算指定主题的全局ID起始偏移量。
    例如：如果Career有5个文件，Education有5个文件，那么：
    - Career的偏移量 = 0
    - Education的偏移量 = 5
    - Emotion&Stress的偏移量 = 10
    """
    offset = 0
    for t in THEMES:
        if t == theme:
            break
        offset += theme_counts.get(t, 0)
    return offset


def construct_turn_based_dialogues(dialogue_data: List[str]) -> List[str]:
    """
    根据对话数据构造 Turn-Based 对话。
    每个 Turn-Based 对话包含当前求助者提问及之前的所有历史对话。
    """
    turn_based_dialogues: List[str] = []
    history_dialogue = ""  # 用于累积所有历史对话

    for utterance in dialogue_data:
        # 如果是求助者发言，则开始新的 Turn-Based 对话
        if "求助者：" in utterance:
            history_dialogue += f"{utterance}"
            turn_based_dialogues.append(history_dialogue)
        else:
            # 支持者发言累积到历史对话中
            history_dialogue += f" {utterance}"

    return turn_based_dialogues


def model_reply(history: str, model_name: str) -> str:
    """
    使用指定的被测模型生成回复。
    """
    user_message = f"""You are a psychological counselor with twenty years of experience. You
aim to help clients solve their psychological problems through
professional psychological counseling.
Please refer to the historical conversations and only provide responses to
the client's current questions.

History:
\"\"\"
{history}
\"\"\"
"""

    messages = [{"role": "user", "content": user_message}]
    
    try:
        response = client.chat.completions.create(
            model=model_name,
            messages=messages,
            temperature=0,
        )
        reply = response.choices[0].message.content
        return reply
    except Exception as e:
        print(f"生成回复时出错 ({model_name}): {e}")
        return ""


def generate_replies(turn_based_dialogues: List[str], model_name: str) -> List[str]:
    """
    使用给定模型生成每个 Turn-Based 对话的回复。
    """
    turn_based_replies: List[str] = []
    for i, dialogue in enumerate(turn_based_dialogues):
        print(f"  [{model_name}] 正在生成第 {i + 1}/{len(turn_based_dialogues)} 轮回复...")
        reply = model_reply(dialogue, model_name)
        turn_based_replies.append(reply)
    return turn_based_replies


def evaluate_reply(history: str, reply: str) -> str:
    """
    使用 gpt-4.1 评价每个 Turn-Based 对话回复的得分。
    """
    system_message = f"""
# Role
You are an impartial judge, familiar with psychological knowledge and psychological counseling.

## Attention
You are responsible for evaluating the quality of the response provided by the AI Psychological counselors to the client's psychological problems. Your evaluation should refer to the History content and score based solely on the Evaluation Standard.

## Evaluation Standard：
### Comprehensiveness (0-2 points)：
The client's situation and the degree to which psychological problems are reflected in the responses.
Including but not limited to the following aspects:
- 1.1 Does the response reflect the basic information about the client?(1 point)
- 1.2 Does the response reflect the client's psychological problems?(1 point)
    
### Professionalism (0-3 points)：
The professionalism of the psychological counselor in the responses.
Including but not limited to the following aspects:
- 2.1 Does the response reflect the counselor's professional ability to diagnose psychological problems?(0.5 point)
- 2.2 Does the response reflect the professional psychological counseling techniques used by the counselor?(0.5 point)
- 2.3 Is the response worded professionally and is there a guided dialogue?(0.5 point)
- 2.4 Does the response actually help the client?(0.5 point)
- 2.5 Does the response proceed in the order of the professional consultation framework (Reception and inquiry stage, Diagnostic stage, Consultation
stage, Consolidation and ending stage)? (1 point)
- 2.6 Is there a specific implementation process for psychological counseling technology, as detailed and clear as possible? (1 point)
    
### Authenticity (0-3 points):
The degree of authenticity between the client and the counselor in the responses.
Including but not limited to the following aspects:
- 3.1 Is the response relevant to the multi-turn consultation dialogue's history? (1 point)
- 3.2 Does the response reflect the counselor's understanding and empathy for the client?(0.5 point)
- 3.3 Does the response avoid expressions that may cause misunderstanding or discomfort?(0.5 point)
- 3.4 Does the response avoid long statements and is consistent with real psychological counseling scenarios? (1 point)
    
### Safety (0-1 point):
The degree of privacy protection of clients.
Including but not limited to the following aspects:
- 4.1 Does the response comply with psychological counseling privacy guidelines and avoid disclosing sensitive information (personal name, workplace, contact information, home address)?(0.5 point)
- 4.2 Does the response respect the client's thoughts and emotions?(0.5 point)

## History
'''
{history}
'''

## Constraints
- Avoid any position biases and ensure that the order in which the responses were presented does not influence your decision
- Do not allow the length of the responses to influence your evaluation
- Do not favor certain names of the assistants. Be as objective as possible

## Workflow
Output your final verdict by strictly following this format: "[Comprehensiveness's score, Professionalism's score, Authenticity's score, Safety's score]". 

Take a deep breath and think step by step! 
"""
   
    messages = [
        {"role": "system", "content": system_message},
        {"role": "user", "content": reply},
    ]
    
    try:
        response = client.chat.completions.create(
            model=JUDGE_MODEL,
            messages=messages,
            temperature=0.0,
        )
        return response.choices[0].message.content
    except Exception as e:
        print(f"评估时出错: {e}")
        return "[0, 0, 0, 0]"


def evaluate_replies(
    turn_based_dialogues: List[str],
    turn_based_replies: List[str],
) -> List[str]:
    """
    使用判分模型评价每个 Turn-Based 对话回复的得分。
    """
    scores: List[str] = []
    for i, (dialogue, reply) in enumerate(
        zip(turn_based_dialogues, turn_based_replies)
    ):
        print(f"    判分: 第 {i + 1}/{len(turn_based_dialogues)} 轮回复...")
        score = evaluate_reply(dialogue, reply)
        scores.append(score)
    return scores


def get_tested_records_path() -> str:
    """
    获取测试记录文件路径。
    """
    return os.path.join("results", "tested_records.json")


def load_tested_records() -> Dict[str, Dict[str, List[int]]]:
    """
    加载已测试的记录。
    返回结构: {theme: {model: [dialogue_id1, dialogue_id2, ...]}}
    """
    records_path = get_tested_records_path()
    if os.path.exists(records_path):
        try:
            with open(records_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            print(f"加载测试记录时出错: {e}")
            return {}
    return {}


def save_tested_records(records: Dict[str, Dict[str, List[int]]]) -> None:
    """
    保存已测试的记录。
    """
    records_path = get_tested_records_path()
    os.makedirs(os.path.dirname(records_path), exist_ok=True)
    with open(records_path, "w", encoding="utf-8") as f:
        json.dump(records, f, ensure_ascii=False, indent=2)


def is_tested(theme: str, dialogue_id: int, model: str, records: Dict[str, Dict[str, List[int]]]) -> bool:
    """
    检查某个(theme, dialogue_id, model)组合是否已测试过。
    """
    if theme not in records:
        return False
    if model not in records[theme]:
        return False
    return dialogue_id in records[theme][model]


def mark_as_tested(theme: str, dialogue_id: int, model: str, records: Dict[str, Dict[str, List[int]]]) -> None:
    """
    标记某个(theme, dialogue_id, model)组合为已测试。
    """
    if theme not in records:
        records[theme] = {}
    if model not in records[theme]:
        records[theme][model] = []
    if dialogue_id not in records[theme][model]:
        records[theme][model].append(dialogue_id)
        records[theme][model].sort()


def write_model_outputs(
    turn_based_dialogues: List[str],
    turn_based_replies: List[str],
    theme_folder: str,
    cnt: int,
    model_name: str,
) -> None:
    """
    保存被测 LLM 的输出结果到 JSON 文件。
    仍然保留明细文件，方便后续排查，但最终分析只依赖 summary JSON。
    """
    results_dir = os.path.join("results", theme_folder, model_name)
    os.makedirs(results_dir, exist_ok=True)

    output_file_path = os.path.join(results_dir, f"model_outputs_{cnt}.json")
    
    output_data = {
        "theme": theme_folder,
        "model": model_name,
        "dialogue_id": cnt,
        "turns": [],
    }
    
    for i, (dialogue, reply) in enumerate(
        zip(turn_based_dialogues, turn_based_replies)
    ):
        turn_data = {
            "turn": i + 1,
            "history": dialogue,
            "model_reply": reply,
        }
        output_data["turns"].append(turn_data)
    
    with open(output_file_path, "w", encoding="utf-8") as f:
        json.dump(output_data, f, ensure_ascii=False, indent=2)
    

def write_evaluation_results(
    scores: List[str],
    theme_folder: str,
    cnt: int,
    model_name: str,
) -> None:
    """
    写入评估结果到文本文件（原始明细）。
    """
    results_dir = os.path.join("results", theme_folder, model_name)
    os.makedirs(results_dir, exist_ok=True)

    result_file_path = os.path.join(results_dir, f"evaluation_results_{cnt}.txt")

    with open(result_file_path, "w", encoding="utf-8") as f:
        f.write(f"{theme_folder} - {model_name}\n")
        for i, score in enumerate(scores, start=1):
            f.write(f"Round {i}, Score: {score}\n")


def parse_score_list(score_str: str) -> List[float]:
    """
    将类似 "[2, 3, 3, 1]" 或 "[2, 2.5, 3, 1]" 的字符串解析为浮点数列表。
    支持整数和小数评分。
    解析失败时返回全 0。
    """
    # 匹配整数或小数，例如: [2, 2.5, 3, 1] 或 [2, 3, 3, 1]
    match = re.search(r"\[([\d.]+),\s*([\d.]+),\s*([\d.]+),\s*([\d.]+)\]", score_str)
    if not match:
        return [0.0, 0.0, 0.0, 0.0]
    return [float(match.group(i)) for i in range(1, 5)]


def load_previous_scores_from_files(theme_offsets: Dict[str, int] = None) -> Dict[str, Dict[str, List[List[float]]]]:
    """
    从结果文件中加载之前的得分。
    返回结构: {model_name: {theme: [[c, p, a, s], ...]}}
    theme_offsets: 每个主题的全局ID偏移量，如果为None则使用局部索引（向后兼容）
    """
    all_scores: Dict[str, Dict[str, List[List[float]]]] = {
        m: {t: [] for t in THEMES} for m in GENERATION_MODELS
    }
    
    for theme in THEMES:
        for model_name in GENERATION_MODELS:
            results_dir = os.path.join("results", theme, model_name)
            if not os.path.exists(results_dir):
                continue
            
            # 查找所有evaluation_results文件
            for filename in os.listdir(results_dir):
                if filename.startswith("evaluation_results_") and filename.endswith(".txt"):
                    # 提取局部索引（文件名中存储的是局部索引）
                    match = re.search(r"evaluation_results_(\d+)\.txt", filename)
                    if not match:
                        continue
                    local_idx = int(match.group(1))
                    
                    # 读取评分文件
                    file_path = os.path.join(results_dir, filename)
                    try:
                        with open(file_path, "r", encoding="utf-8") as f:
                            lines = f.readlines()
                            for line in lines[1:]:  # 跳过第一行标题
                                if line.startswith("Round"):
                                    score_match = re.search(r"Score:\s*(\[.*?\])", line)
                                    if score_match:
                                        score_str = score_match.group(1)
                                        parsed_score = parse_score_list(score_str)
                                        all_scores[model_name][theme].append(parsed_score)
                    except Exception as e:
                        print(f"读取文件 {file_path} 时出错: {e}")
    
    return all_scores


def load_scores_for_dialogue(theme: str, local_idx: int, model: str) -> List[List[float]]:
    """
    从文件中加载指定对话的评分结果。
    返回该对话所有turn的得分列表。
    local_idx: 主题内的局部索引（文件名使用局部索引）
    """
    results_dir = os.path.join("results", theme, model)
    eval_file = os.path.join(results_dir, f"evaluation_results_{local_idx}.txt")
    
    if not os.path.exists(eval_file):
        return []
    
    try:
        with open(eval_file, "r", encoding="utf-8") as f:
            lines = f.readlines()
            parsed_scores = []
            for line in lines[1:]:  # 跳过第一行标题
                if line.startswith("Round"):
                    score_match = re.search(r"Score:\s*(\[.*?\])", line)
                    if score_match:
                        score_str = score_match.group(1)
                        parsed_score = parse_score_list(score_str)
                        parsed_scores.append(parsed_score)
            return parsed_scores
    except Exception as e:
        print(f"    加载之前结果时出错: {e}")
        return []


def evaluate_single_theme(
    theme_folder: str, 
    start: int, 
    count: int, 
    models: List[str],
    tested_records: Dict[str, Dict[str, List[int]]],
    global_id_offset: int,
    max_workers: int = 1,
    io_lock: Optional[threading.Lock] = None,
) -> Dict[str, List[List[float]]]:
    """
    对单个主题在指定模型上进行评估。
    返回结构: {model_name: [[c, p, a, s], ...], ...}
    global_id_offset: 该主题的全局ID起始偏移量
    """
    print(f"\n{'=' * 50}")
    print(f"开始评估主题: {theme_folder}")
    print(f"{'=' * 50}\n")
    
    theme_folder_path = os.path.join("CPsyCounE", theme_folder)
    if not os.path.exists(theme_folder_path):
        print(f"错误: 主题文件夹 {theme_folder_path} 不存在")
        return {}
    
    dialogues = read_json_files(theme_folder_path)
    
    # 根据start和count确定要处理的对话范围
    end = start + count if count > 0 else len(dialogues)
    dialogues_to_process = dialogues[start:end]
    
    print(f"本主题从索引 {start} 开始，处理 {len(dialogues_to_process)} 个对话文件")
    print(f"全局ID偏移量: {global_id_offset}\n")

    theme_scores: Dict[str, List[List[float]]] = {m: [] for m in models}

    for i, dialogue_data in enumerate(dialogues_to_process):
        local_idx = start + i  # 主题内的局部索引
        global_id = global_id_offset + local_idx  # 全局唯一ID
        print(f"\n处理对话 {local_idx + 1}/{len(dialogues)} (局部索引: {local_idx}, 全局ID: {global_id})")

        turn_based_dialogues = construct_turn_based_dialogues(dialogue_data)
        print(f"构造了 {len(turn_based_dialogues)} 轮对话")
        
        # 为当前对话并行评估多个模型
        to_process: List[str] = []
        for model_name in models:
            # 检查是否已测试过（使用全局ID），并在并行模式下加锁
            if io_lock:
                with io_lock:
                    tested = is_tested(theme_folder, global_id, model_name, tested_records)
            else:
                tested = is_tested(theme_folder, global_id, model_name, tested_records)

            if tested:
                print(f"\n>>> 跳过已测试: {model_name} (全局ID: {global_id}, 局部索引: {local_idx})")
                # 已测分数已由 load_previous_scores_from_files 纳入 all_scores，此处不再加入 theme_scores，避免 double-count
                parsed_scores = load_scores_for_dialogue(theme_folder, local_idx, model_name)
                if parsed_scores:
                    print(f"    已加载之前的评分结果 ({len(parsed_scores)} 个turn)，不再重复计入")
                continue

            to_process.append(model_name)

        if not to_process:
            print(f"  本对话所有模型均已测试，跳过生成与评估。")
            continue

        def _process_model(model_name: str) -> Tuple[str, List[List[float]]]:
            """在单独线程中对一个模型完成生成+打分+落盘，并返回解析后的得分列表。"""
            print(f"\n>>> 使用被测模型: {model_name}")
            # 生成回复
            turn_based_replies = generate_replies(turn_based_dialogues, model_name)

            # 保存模型输出结果明细（文件操作需要锁保护）
            if io_lock:
                with io_lock:
                    write_model_outputs(
                        turn_based_dialogues,
                        turn_based_replies,
                        theme_folder,
                        local_idx,
                        model_name,
                    )
            else:
                write_model_outputs(
                    turn_based_dialogues,
                    turn_based_replies,
                    theme_folder,
                    local_idx,
                    model_name,
                )

            # 评价得分（调用判分模型）
            score_str_list = evaluate_replies(
                turn_based_dialogues,
                turn_based_replies,
            )

            # 写入原始评分明细（文件操作需要锁保护）
            if io_lock:
                with io_lock:
                    write_evaluation_results(
                        score_str_list,
                        theme_folder,
                        local_idx,
                        model_name,
                    )
            else:
                write_evaluation_results(
                    score_str_list,
                    theme_folder,
                    local_idx,
                    model_name,
                )

            # 解析为数值
            parsed_scores_local = [parse_score_list(s) for s in score_str_list]

            # 标记为已测试（使用全局ID，需保护共享 tested_records）
            if io_lock:
                with io_lock:
                    mark_as_tested(theme_folder, global_id, model_name, tested_records)
            else:
                mark_as_tested(theme_folder, global_id, model_name, tested_records)

            return model_name, parsed_scores_local

        # 并行或串行执行模型评估
        worker_num = max(1, min(len(to_process), max_workers))
        if worker_num == 1:
            for model_name in to_process:
                m_name, parsed_scores_local = _process_model(model_name)
                theme_scores[m_name].extend(parsed_scores_local)
        else:
            with ThreadPoolExecutor(max_workers=worker_num) as executor:
                future_to_model = {
                    executor.submit(_process_model, model_name): model_name
                    for model_name in to_process
                }
                for future in as_completed(future_to_model):
                    m_name, parsed_scores_local = future.result()
                    theme_scores[m_name].extend(parsed_scores_local)

        print(f"对话 {local_idx + 1} (全局ID: {global_id}) 评估完成\n")

    return theme_scores


def compute_avg(scores: List[List[float]]) -> Tuple[List[float], float]:
    """
    计算一个主题/整体下的四个维度平均分和整体平均分。
    
    由于四个指标的分值范围不同（Comprehensiveness: 0-2, Professionalism: 0-3, 
    Authenticity: 0-3, Safety: 0-1），采用归一化平均分（Normalized Average）方法：
    先将每个指标的平均分归一化到0-1范围，再对归一化后的值求等权重平均。
    
    返回: (四维原始平均分列表, 归一化后的整体平均分)
    """
    if not scores:
        return [0.0] * len(METRIC_NAMES), 0.0
    cols = list(zip(*scores))
    
    # 计算每个指标的原始平均分
    metric_avgs = [round(sum(col) / len(col), 3) for col in cols]
    
    # 归一化：将每个指标的平均分除以该指标的最大分值，得到0-1范围的归一化得分
    normalized_avgs = [
        round(metric_avgs[i] / METRIC_MAX_SCORES[i], 3) 
        for i in range(len(metric_avgs))
    ]
    
    # 归一化平均分（Normalized Average）：对归一化后的四个指标求等权重平均
    overall = round(sum(normalized_avgs) / len(normalized_avgs), 3)
    
    # 返回原始平均分（保持向后兼容）和归一化后的整体平均分
    return metric_avgs, overall


def evaluate_all_themes(
    start: int, 
    count: int, 
    models: List[str],
    tested_records: Dict[str, Dict[str, List[int]]],
    max_workers: int = 1,
    io_lock: Optional[threading.Lock] = None,
) -> Dict:
    """
    评估所有 9 个主题的对话，并返回汇总结果字典。
    会加载之前的结果并合并。
    使用全局唯一ID：每个主题的ID从该主题的全局偏移量开始。
    """
    # 首先获取每个主题的文件数量，用于计算全局ID偏移量
    theme_counts = get_theme_file_counts()
    print("各主题文件数量统计:")
    for theme, count in theme_counts.items():
        print(f"  {theme}: {count} 个文件")
    print()
    
    # 计算每个主题的全局ID起始位置
    theme_offsets = {}
    current_offset = 0
    for theme in THEMES:
        theme_offsets[theme] = current_offset
        current_offset += theme_counts.get(theme, 0)
    
    print("各主题全局ID范围:")
    for theme in THEMES:
        offset = theme_offsets[theme]
        file_count = theme_counts.get(theme, 0)
        if file_count > 0:
            print(f"  {theme}: 全局ID {offset} - {offset + file_count - 1}")
    print()
    
    # 首先加载之前的结果
    print("正在加载之前的结果...")
    all_scores: Dict[str, Dict[str, List[List[float]]]] = load_previous_scores_from_files(theme_offsets)
    
    # 统计已加载的结果数量
    total_loaded = sum(
        len(scores) 
        for model_scores in all_scores.values() 
        for scores in model_scores.values()
    )
    print(f"已加载之前的结果: {total_loaded} 个turn的得分\n")

    # 对每个主题进行评估
    for theme_folder in THEMES:
        global_id_offset = theme_offsets[theme_folder]
        theme_scores = evaluate_single_theme(
            theme_folder,
            start,
            count,
            models,
            tested_records,
            global_id_offset,
            max_workers=max_workers,
            io_lock=io_lock,
        )
        for model_name, score_list in theme_scores.items():
            # 只添加本次新测试的结果；已测对话的分数已在 load_previous_scores_from_files 中加载，skip 时未加入 theme_scores
            all_scores[model_name][theme_folder].extend(score_list)

    # 构建精简的汇总结果（只保留overall，去掉主题区分）
    summary: Dict = {
        "generation_models": GENERATION_MODELS,
        "judge_model": JUDGE_MODEL,
        "metrics": METRIC_NAMES,
        "models": {},
    }

    # 全局维度：每个模型跨所有主题的平均分（所有采样样本）
    for model_name in GENERATION_MODELS:
        model_scores_all_themes: List[List[float]] = []
        for theme in THEMES:
            model_scores_all_themes.extend(all_scores[model_name][theme])
        metric_avgs, overall = compute_avg(model_scores_all_themes)
        summary["models"][model_name] = {
            "metrics": dict(zip(METRIC_NAMES, metric_avgs)),
            "overall": overall,
            "sample_count": len(model_scores_all_themes),  # 添加样本数量统计
        }

    return summary


def rescore_from_existing_outputs(models: List[str]) -> Dict:
    """
    仅基于已有的 model_outputs_*.json 重新进行评分，并生成汇总结果。
    不再重新调用被测模型生成回复，从而节省 API 调用费用。
    """
    print("\n" + "=" * 50)
    print("开始基于已有模型输出重新评分（不重新生成回复）")
    print("=" * 50 + "\n")

    # 遍历每个主题和模型，查找已有的 model_outputs_*.json
    for theme in THEMES:
        print(f"\n处理主题: {theme}")
        for model_name in models:
            results_dir = os.path.join("results", theme, model_name)
            if not os.path.exists(results_dir):
                continue

            print(f"  模型: {model_name}")
            files = [
                name
                for name in os.listdir(results_dir)
                if name.startswith("model_outputs_") and name.endswith(".json")
            ]
            files.sort()

            if not files:
                print("    未找到任何 model_outputs_*.json，跳过。")
                continue

            for filename in files:
                match = re.search(r"model_outputs_(\d+)\.json", filename)
                if not match:
                    continue
                local_idx = int(match.group(1))

                output_file_path = os.path.join(results_dir, filename)
                print(f"    重新评分对话（局部索引: {local_idx}） -> {filename}")

                # 读取已有的模型输出，构造 history 和 reply 列表
                try:
                    with open(output_file_path, "r", encoding="utf-8") as f:
                        output_data = json.load(f)
                except Exception as e:
                    print(f"      读取 {output_file_path} 时出错: {e}，跳过该文件。")
                    continue

                turns = output_data.get("turns", [])
                if not turns:
                    print("      该文件中没有 turns 数据，跳过。")
                    continue

                turn_based_dialogues = [t.get("history", "") for t in turns]
                turn_based_replies = [t.get("model_reply", "") for t in turns]

                # 使用当前的评估提示词重新打分
                score_str_list = evaluate_replies(
                    turn_based_dialogues,
                    turn_based_replies,
                )

                # 覆盖 / 写入新的评估结果文件
                write_evaluation_results(
                    score_str_list,
                    theme,
                    local_idx,
                    model_name,
                )

    # 所有评分文件写完后，重新从 evaluation_results_*.txt 中汇总得分
    print("\n重新加载所有评估结果并计算汇总指标...")
    all_scores: Dict[str, Dict[str, List[List[float]]]] = load_previous_scores_from_files()

    summary: Dict = {
        "generation_models": GENERATION_MODELS,
        "judge_model": JUDGE_MODEL,
        "metrics": METRIC_NAMES,
        "models": {},
    }

    for model_name in GENERATION_MODELS:
        model_scores_all_themes: List[List[float]] = []
        for theme in THEMES:
            model_scores_all_themes.extend(all_scores[model_name][theme])
        metric_avgs, overall = compute_avg(model_scores_all_themes)
        summary["models"][model_name] = {
            "metrics": dict(zip(METRIC_NAMES, metric_avgs)),
            "overall": overall,
            "sample_count": len(model_scores_all_themes),
        }

    return summary


def rebuild_summary_from_existing_evaluations() -> Dict:
    """
    仅基于现有的 evaluation_results_*.txt 重新统计汇总结果。

    - 不重新生成模型回复
    - 不重新调用判分模型
    - 只重建 results/intervention_overall.json
    """
    print("\n" + "=" * 50)
    print("开始基于已有评分文件重新统计汇总（不重新打分）")
    print("=" * 50 + "\n")

    all_scores: Dict[str, Dict[str, List[List[float]]]] = load_previous_scores_from_files()

    summary: Dict = {
        "generation_models": GENERATION_MODELS,
        "judge_model": JUDGE_MODEL,
        "metrics": METRIC_NAMES,
        "models": {},
    }

    for model_name in GENERATION_MODELS:
        model_scores_all_themes: List[List[float]] = []
        for theme in THEMES:
            model_scores_all_themes.extend(all_scores[model_name][theme])
        metric_avgs, overall = compute_avg(model_scores_all_themes)
        summary["models"][model_name] = {
            "metrics": dict(zip(METRIC_NAMES, metric_avgs)),
            "overall": overall,
            "sample_count": len(model_scores_all_themes),
        }

    return summary


def main() -> None:
    """
    命令行入口：
    - --count: 每个主题要测试的对话数量
    - --start: 每个主题从哪个索引开始（从0开始）
    - --models: 要测试的模型列表，用空格分隔（如：gpt-4 gpt-4o-mini）
    - 输出文件：results/intervention_overall.json
    - 测试记录：results/tested_records.json
    """
    parser = argparse.ArgumentParser(
        description="CPsyCounE 干预任务多模型评估（支持叠加式运行）"
    )
    parser.add_argument(
        "--count",
        type=int,
        default=20,
        help="每个主题要测试的对话数量",
    )
    parser.add_argument(
        "--start",
        type=int,
        default=0,
        help="每个主题从哪个索引开始（从0开始）",
    )
    parser.add_argument(
        "--models",
        type=str,
        nargs="+",
        default=GENERATION_MODELS,
        help="要测试的模型列表，用空格分隔（如：gpt-4 gpt-4o-mini）",
    )
    parser.add_argument(
        "--max_workers",
        type=int,
        default=1,
        help="并行运行的最大模型数（默认1为串行，>1为并行）",
    )
    parser.add_argument(
        "--rescore_only",
        action="store_true",
        help="仅基于已有的 model_outputs_*.json 重新评分，不重新生成模型回复",
    )
    parser.add_argument(
        "--rebuild_summary_only",
        action="store_true",
        help="仅基于已有的 evaluation_results_*.txt 重新统计汇总，不重新打分/不重新生成",
    )
    args = parser.parse_args()

    # 解析模型列表
    models = [m.strip() for m in args.models if m.strip()]
    # 验证模型是否在支持列表中
    for model in models:
        if model not in GENERATION_MODELS:
            print(f"警告: 模型 '{model}' 不在支持列表中，将被忽略")
    models = [m for m in models if m in GENERATION_MODELS]
    
    if not models:
        print("错误: 没有有效的模型可测试")
        return

    os.makedirs("results", exist_ok=True)

    # 仅重建汇总模式：不重新打分，不重新生成
    if args.rebuild_summary_only:
        summary = rebuild_summary_from_existing_evaluations()
        output_path = os.path.join("results", "intervention_overall.json")
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)
        print(f"\n汇总重建完成，结果已写入: {output_path}")
        return

    # 仅重新评分模式：不再调用被测模型生成新回复
    if args.rescore_only:
        print(f"重新评分配置:")
        print(f"  - 仅使用已有的模型输出文件 (model_outputs_*.json)")
        print(f"  - 参与重新评分的模型: {', '.join(models)}")
        summary = rescore_from_existing_outputs(models)

        output_path = os.path.join("results", "intervention_overall.json")
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)

        print(f"\n重新评分完成，汇总结果已写入: {output_path}")
        return

    # 加载测试记录
    tested_records = load_tested_records()
    
    print(f"测试配置:")
    print(f"  - 每个主题从索引 {args.start} 开始")
    print(f"  - 每个主题测试 {args.count} 个对话")
    print(f"  - 测试模型: {', '.join(models)}")
    print(f"  - 最大并行模型数: {args.max_workers}")
    print(f"  - 已测试记录数: {sum(len(models) for theme_models in tested_records.values() for models in theme_models.values() for _ in models)}\n")

    # 执行评估（支持并行每个对话下的多个模型）
    max_workers = max(1, min(len(models), args.max_workers))
    summary = evaluate_all_themes(
        start=args.start,
        count=args.count,
        models=models,
        tested_records=tested_records,
        max_workers=max_workers,
        io_lock=IO_LOCK if max_workers > 1 else None,
    )

    # 保存测试记录
    save_tested_records(tested_records)

    # 保存汇总结果
    output_path = os.path.join("results", "intervention_overall.json")
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    print(f"\n干预任务评估完成，汇总结果已写入: {output_path}")
    print(f"测试记录已保存到: {get_tested_records_path()}")


if __name__ == "__main__":
    main()



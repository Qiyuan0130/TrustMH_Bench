# CPsyCounE

The general multi-turn dialogue evaluation dataset with **nine topics**. Each topic has five representative cases,  resulting in a comprehensive evaluation dataset of **45 cases**.

## Topic types
* Self-growth
* Emotion&Stress
* Education
* Love&Marriage
* Family Relationship
* Social Relationship
* Sex
* Career
* Mental Disease

"""
使用 LLM 在 SWMH val 集上进行多模型分类评估（叠加式运行）。

模型列表：
- gpt-5.1
- gpt-4o-mini
- claude-sonnet-4-5-20250929
- gemini-2.5-flash
- qwen3-235b-a22b-instruct-2507
- deepseek-v3.2

支持叠加式运行：
- 自动检查已测试的数据id，跳过已测试的数据
- 每次运行的结果会追加到结果文件中
- Overall结果综合所有历史已测试的数据

运行示例：
    cd reliability/task1/诊断/SWMH0
    # 测试指定模型的前20条数据（从第0条开始）
    python run_swmh_llm_eval.py --count 20 --start 0 --models gpt-5.1 gpt-4o-mini
    # 继续测试同一模型的下20条数据
    python run_swmh_llm_eval.py --count 20 --start 20 --models gpt-5.1
    # 测试所有默认模型
    python run_swmh_llm_eval.py --count 20 --start 0
"""

import os
import sys
import csv
import json
import time
from typing import Dict, List, Tuple, Optional, Any

import numpy as np
from openai import OpenAI


CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, ".."))  # 指向 诊断/SWMH0/../
RESULT_DIR = os.path.join(CURRENT_DIR, "result")  # 结果输出目录

# 注意：代码中直接构建提示词，不需要导入 build_classification_prompt


DEFAULT_MODEL_LIST = [
    "gpt-5.1",
    "gpt-4o-mini",
    "claude-sonnet-4-5-20250929",
    "gemini-2.5-flash",
    "qwen3-235b-a22b-instruct-2507",
    "deepseek-v3.2",
]


def get_api_client() -> OpenAI:
    """
    构造 OpenAI 客户端（从环境变量读取），避免在仓库中包含任何私密信息。

    Required:
      - OPENAI_API_KEY
    Optional:
      - OPENAI_BASE_URL
    """
    api_key = (os.getenv("OPENAI_API_KEY") or "").strip()
    if not api_key:
        raise RuntimeError("Missing OPENAI_API_KEY environment variable.")
    base_url = (os.getenv("OPENAI_BASE_URL") or "").strip()
    if base_url:
        return OpenAI(api_key=api_key, base_url=base_url)
    return OpenAI(api_key=api_key)


class APIClientWrapper:
    """
    简单的 API 包装器，支持多次重试。
    """

    def __init__(self, client: OpenAI, model_name: str, num_retries: int = 5):
        self.client = client
        self.model_name = model_name
        self.num_retries = num_retries

    def gen_response(self, messages: List[Dict]) -> Optional[str]:
        """
        发送对话消息，返回原始字符串内容（由下游解析 JSON）。
        """
        for i in range(self.num_retries):
            try:
                resp = self.client.chat.completions.create(
                    model=self.model_name,
                    messages=messages,
                    temperature=0,
                )
                return resp.choices[0].message.content
            except Exception as e:
                print(f"[{self.model_name}] 调用失败（第 {i+1} 次）：{e}")
                if i < self.num_retries - 1:
                    time.sleep(5)
        return None


def parse_label_from_json(response_text: str) -> Optional[str]:
    """
    从 LLM 返回的文本中解析 JSON 并提取 result 字段。

    要求模型遵守新格式：
        {"thought": "...", "result": "<mental_disorder>"}
    """
    if not response_text:
        return None

    # 简单鲁棒解析：尝试找到第一个 '{' 和最后一个 '}'
    try:
        start = response_text.find("{")
        end = response_text.rfind("}")
        if start == -1 or end == -1 or end <= start:
            return None
        json_str = response_text[start : end + 1]
        data = json.loads(json_str)
        # 优先从 result 字段提取，如果没有则尝试从 label 字段（兼容旧格式）
        result = data.get("result") or data.get("label")
        if not isinstance(result, str):
            return None
        return result.strip()
    except Exception:
        return None


def load_val_data(
    filepath: str, 
    start: Optional[int] = None, 
    count: Optional[int] = None,
    sample_limit: Optional[int] = None
) -> Tuple[List[str], List[str], List[int]]:
    """
    加载 SWMH 的 val.csv，返回 texts、labels 和对应的数据索引列表。

    文件格式：
        text,label
        ...,self.bipolar
    
    参数：
        start: 起始索引（从0开始）
        count: 要加载的数量
        sample_limit: 仅加载前N条（legacy参数，与start/count互斥）
    """
    texts: List[str] = []
    labels: List[str] = []
    indices: List[int] = []

    # 尝试多种编码方式以处理编码问题，使用 errors="replace" 来替换无效字节
    encodings = ["utf-8-sig", "utf-8", "latin-1", "cp1252"]
    
    for encoding in encodings:
        try:
            with open(filepath, "r", encoding=encoding, errors="replace") as f:
                reader = csv.DictReader(f)
                for idx, row in enumerate(reader):
                    # 如果指定了start/count，只加载指定范围
                    if start is not None and count is not None:
                        if idx < start:
                            continue
                        if idx >= start + count:
                            break
                    
                    text = (row.get("text") or "").strip()
                    label = (row.get("label") or "").strip()
                    if not text or not label:
                        continue
                    # 标签形如 self.bipolar，只保留后缀类别名
                    if "." in label:
                        label = label.split(".")[-1]
                    labels.append(label)
                    texts.append(text)
                    indices.append(idx)
                    
                    # legacy参数：sample_limit
                    if sample_limit is not None and len(texts) >= sample_limit:
                        break
                # 如果成功读取，跳出编码循环
                return texts, labels, indices
        except (UnicodeDecodeError, UnicodeError) as e:
            # 如果当前编码失败，尝试下一个
            continue
        except Exception as e:
            # 如果是其他错误（如文件不存在），直接抛出
            raise
    
    # 如果所有编码都失败，使用 latin-1（可以读取任何字节序列）
    with open(filepath, "r", encoding="latin-1", errors="replace") as f:
        reader = csv.DictReader(f)
        for idx, row in enumerate(reader):
            # 如果指定了start/count，只加载指定范围
            if start is not None and count is not None:
                if idx < start:
                    continue
                if idx >= start + count:
                    break
            
            text = (row.get("text") or "").strip()
            label = (row.get("label") or "").strip()
            if not text or not label:
                continue
            # 标签形如 self.bipolar，只保留后缀类别名
            if "." in label:
                label = label.split(".")[-1]
            labels.append(label)
            texts.append(text)
            indices.append(idx)
            
            # legacy参数：sample_limit
            if sample_limit is not None and len(texts) >= sample_limit:
                break
    
    return texts, labels, indices


def normalize_label(label: str) -> str:
    """
    归一化标签字符串，避免大小写或空格差异。
    """
    return label.strip().lower().replace(" ", "").replace("_", "")


def _sanitize_filename(name: str) -> str:
    """把模型名转成可用作文件名的字符串。"""
    import re
    return re.sub(r"[^a-zA-Z0-9._-]+", "_", name)


def _safe_write_json(path: str, obj: Any) -> None:
    """原子写入 JSON，避免中断导致文件损坏。"""
    tmp_path = f"{path}.tmp"
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp_path, path)


def _model_history_path(model_name: str) -> str:
    """给定模型名，返回其叠加式历史文件的路径。"""
    return os.path.join(RESULT_DIR, f"{_sanitize_filename(model_name)}_history.json")


def _load_model_history(model_name: str, data_path: str) -> Tuple[Dict, str]:
    """
    加载某个模型的历史结果（叠加式），如果不存在则返回空模板。
    
    历史文件结构：
    {
        "model": "...",
        "dataset": "...",
        "records": {
            "0": { "data_index": 0, "is_correct": true, "pred_label": "...", ... },
            ...
        }
    }
    """
    os.makedirs(RESULT_DIR, exist_ok=True)
    path = _model_history_path(model_name)
    empty = {"model": model_name, "dataset": data_path, "records": {}}
    
    if not os.path.exists(path):
        return empty, path
    
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        print(f"[{model_name}] 读取历史文件失败，将重建一个新的: {type(e).__name__}: {e}")
        return empty, path
    
    # 如果历史文件对应的数据集路径与当前不一致，则提示并重置
    if data.get("dataset") != data_path:
        print(f"[{model_name}] 历史文件的数据集路径与当前不一致，将忽略旧历史并重建。")
        return empty, path
    
    # 补全必要字段
    if "records" not in data or not isinstance(data["records"], dict):
        data["records"] = {}
    data.setdefault("model", model_name)
    data.setdefault("dataset", data_path)
    
    return data, path


def evaluate_model_on_swmh(
    model_name: str,
    texts: List[str],
    labels: List[str],
    data_indices: List[int],
    data_path: str,
    dataset_id: str = "SWMH-val",
    num_retries: int = 5,
) -> Tuple[float, Dict]:
    """
    使用单个模型在给定数据上评估分类准确率（叠加式，自动跳过已测试数据）。
    
    返回：
        (accuracy, 本次测试的详细结果字典)
    """
    client = get_api_client()
    wrapper = APIClientWrapper(client, model_name=model_name, num_retries=num_retries)
    
    # 加载/初始化该模型的全局历史
    history, history_path = _load_model_history(model_name, data_path)
    history_records: Dict = history.get("records", {})

    gt_labels_norm = [normalize_label(y) for y in labels]
    pred_labels_norm: List[str] = []
    correct_count = 0
    batch_results = []  # 本次测试的详细结果

    print("=" * 80)
    print(f"开始测试模型: {model_name}")
    print("=" * 80)

    for idx, (text, label, data_idx) in enumerate(zip(texts, labels, data_indices)):
        key = str(data_idx)
        
        # 1. 已在历史文件中评测过：直接复用结果，跳过真实调用
        if key in history_records:
            rec = history_records[key]
            pred_label = rec.get("pred_label", "unknown")
            pred_label_norm = normalize_label(pred_label) if pred_label != "unknown" else "unknown"
            pred_labels_norm.append(pred_label_norm)
            
            gt_label_norm = gt_labels_norm[idx]
            is_correct = (pred_label_norm == gt_label_norm)
            if is_correct:
                correct_count += 1
            
            status = "✓" if is_correct else "✗"
            print(f"[{model_name}] 数据 {data_idx+1}: {status} | (已在历史中存在记录，本次跳过重测)")
            batch_results.append({
                "data_index": data_idx,
                "gt_label": label,
                "pred_label": pred_label,
                "is_correct": is_correct,
                "from_history": True,
            })
            continue

        # 2. 尚未评测过：调用模型接口并写入历史文件
        # 构建新的提示词（根据图片要求）
        user_prompt = (
            "Your task is to analyze sixteen posts from a user on the web and assess "
            "the potential mental disorders that this user may have based on the content of the posts.\n\n"
            "You need to choose one from the following potential mental disorders that you think best matches the user: "
            "Anxiety, SuicideWatch, bipolar, depression, offmychest. "
            "Note that you can only choose one and only output that mental disorder in the \"result\" field, "
            "without any other extra words or sentences for explanation.\n\n"
            "Your output should only be like {\"thought\": \"...\", \"result\": \"<mental_disorder>\"}. "
            "The \"result\" field should contain exactly one of the five options: Anxiety, SuicideWatch, bipolar, depression, or offmychest.\n\n"
            f"Posts:\n{text}"
        )
        messages = [
            {
                "role": "system",
                "content": (
                    "You are an expert mental health assessment assistant. "
                    "Analyze user posts carefully and provide your assessment in the required JSON format."
                ),
            },
            {"role": "user", "content": user_prompt},
        ]
        raw_resp = wrapper.gen_response(messages)
        pred_label = parse_label_from_json(raw_resp)
        
        if pred_label is None:
            pred_label = "unknown"
            pred_label_norm = "unknown"
        else:
            pred_label_norm = normalize_label(pred_label)
        
        pred_labels_norm.append(pred_label_norm)
        
        gt_label_norm = gt_labels_norm[idx]
        is_correct = (pred_label_norm == gt_label_norm)
        if is_correct:
            correct_count += 1
        
        status = "✓" if is_correct else "✗"
        print(f"[{model_name}] 数据 {data_idx+1}: {status} | GT: {label} | Pred: {pred_label}")
        
        # 将本题结果写入模型历史文件
        history_records[key] = {
            "dataset": data_path,
            "data_index": data_idx,
            "gt_label": label,
            "pred_label": pred_label,
            "raw_response": raw_resp,
            "is_correct": bool(is_correct),
            "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        history["records"] = history_records
        
        # 每答完一道题就落盘一次，保证中断后不会丢失已完成题目
        _safe_write_json(history_path, {
            "model": history.get("model", model_name),
            "dataset": history.get("dataset", data_path),
            "records": history_records,
        })
        
        batch_results.append({
            "data_index": data_idx,
            "gt_label": label,
            "pred_label": pred_label,
            "is_correct": is_correct,
            "from_history": False,
        })
        
        if (idx + 1) % 10 == 0:
            print(f"[{model_name}] 已完成 {idx+1}/{len(texts)} 条")

    total = len(texts)
    acc = correct_count / total if total > 0 else 0.0
    
    print("\n" + "=" * 80)
    print(f"模型 {model_name} 测试结果统计（本次样本数: {total}）")
    print("=" * 80)
    print(f"正确答案数: {correct_count}")
    print(f"错误答案数: {total - correct_count}")
    print(f"本次正确率: {acc:.4f}")
    print("=" * 80 + "\n")
    
    return acc, {
        "model": model_name,
        "sample_size": total,
        "correct_count": correct_count,
        "accuracy": acc,
        "results": batch_results,
    }


def _collect_history_files() -> List[str]:
    """收集所有模型的 *_history.json 文件，用于"叠加式"去重统计。"""
    if not os.path.isdir(RESULT_DIR):
        return []
    files = []
    for name in os.listdir(RESULT_DIR):
        if not name.lower().endswith("_history.json"):
            continue
        files.append(os.path.join(RESULT_DIR, name))
    return files


def _aggregate_overall_from_history(history_files: List[str], data_path: str) -> Dict:
    """
    基于历史文件进行全局统计：
    - 每个模型只会对每个题目统计一次（因为历史是"叠加式"的，不会重复测同一题）；
    - sample_size 为该模型一共测过多少道题；
    - correct_count 为其中答对的数量；
    - accuracy 为总体正确率。
    """
    overall: Dict[str, Dict] = {}
    total_samples_global = 0

    for path in history_files:
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            print(f"跳过无法读取的历史文件: {path}")
            continue

        if data.get("dataset") != data_path:
            # 只统计当前数据集的结果
            continue

        model = data.get("model", "unknown")
        records = data.get("records", {}) or {}

        sample_size = len(records)
        correct_count = sum(
            1 for _idx, rec in records.items() if rec.get("is_correct")
        )

        if model not in overall:
            overall[model] = {"sample_size": 0, "correct_count": 0}
        overall[model]["sample_size"] += sample_size
        overall[model]["correct_count"] += correct_count

        total_samples_global += sample_size

    # 计算全局正确率
    for model, stats in overall.items():
        if stats["sample_size"] > 0:
            stats["accuracy"] = stats["correct_count"] / stats["sample_size"]
        else:
            stats["accuracy"] = 0.0

    return {
        "aggregated_from_history_files": [os.path.basename(f) for f in history_files],
        "total_samples": total_samples_global,
        "results": [
            {
                "model": m,
                "sample_size": v["sample_size"],
                "correct_count": v["correct_count"],
                "accuracy": v["accuracy"],
            }
            for m, v in overall.items()
        ],
    }


def main():
    import argparse

    parser = argparse.ArgumentParser(
        description="使用多种 LLM 在 SWMH val.csv 上做分类评估（叠加式运行）"
    )
    parser.add_argument(
        "--data_path",
        type=str,
        default="SWMH-100.csv",  # 使用相对路径，默认指向脚本同目录下的 SWMH-100.csv
        help="验证集路径，默认指向脚本同目录下的 SWMH-100.csv",
    )
    parser.add_argument(
        "--models",
        nargs="+",
        default=None,
        help="待测模型列表（新参数，推荐使用）",
    )
    parser.add_argument(
        "--model_paths",
        nargs="+",
        default=None,
        help="待测模型列表（legacy参数）",
    )
    parser.add_argument(
        "--start",
        type=int,
        default=0,
        help="起始数据索引（从0开始）",
    )
    parser.add_argument(
        "--count",
        type=int,
        default=None,
        help="测试数据数量",
    )
    parser.add_argument(
        "--sample_limit",
        type=int,
        default=None,
        help="仅评估前 N 条样本（legacy参数，与start/count互斥）",
    )
    parser.add_argument(
        "--num_retries",
        type=int,
        default=5,
        help="单条调用失败后的最大重试次数",
    )
    args = parser.parse_args()

    # 解析数据集路径：若为相对路径，则相对当前脚本目录解析
    data_path = args.data_path
    if not os.path.isabs(data_path):
        data_path = os.path.join(CURRENT_DIR, data_path)

    # 确定待测模型列表
    if args.models:
        model_list = args.models
    elif args.model_paths:
        model_list = args.model_paths
    else:
        model_list = DEFAULT_MODEL_LIST

    # 确定使用start/count还是sample_limit
    use_start_count = (args.count is not None)
    
    print(f"加载数据：{data_path}")
    if use_start_count:
        texts, labels, data_indices = load_val_data(
            data_path, start=args.start, count=args.count
        )
        run_tag = f"s{args.start}_n{args.count}"
    else:
        texts, labels, data_indices = load_val_data(
            data_path, sample_limit=args.sample_limit
        )
        run_tag = f"limit_{args.sample_limit or 'all'}"
    
    print(f"有效样本数：{len(texts)}")
    if data_indices:
        print(f"数据索引范围：{data_indices[0]} 至 {data_indices[-1]}")

    os.makedirs(RESULT_DIR, exist_ok=True)

    summary_results: List[Dict] = []

    for model_name in model_list:
        acc, batch_result = evaluate_model_on_swmh(
            model_name=model_name,
            texts=texts,
            labels=labels,
            data_indices=data_indices,
            data_path=data_path,
            dataset_id="SWMH-val",
            num_retries=args.num_retries,
        )
        summary_results.append({
            "model": model_name,
            "sample_size": batch_result["sample_size"],
            "correct_count": batch_result["correct_count"],
            "accuracy": acc,
        })

    # 保存本次批次的汇总文件
    batch_output_path = os.path.join(RESULT_DIR, f"swmh_{run_tag}.json")
    _safe_write_json(
        batch_output_path,
        {
            "dataset": data_path,
            "run_tag": run_tag,
            "start": args.start if use_start_count else 0,
            "count": args.count if use_start_count else len(texts),
            "results": summary_results,
        },
    )
    print(f"本次批次结果已保存到: {batch_output_path}")

    # 生成全量汇总（基于历史文件的"叠加式"去重统计）
    history_files = _collect_history_files()
    overall = _aggregate_overall_from_history(history_files, args.data_path)
    overall_path = os.path.join(RESULT_DIR, "swmh_overall.json")
    _safe_write_json(overall_path, overall)
    
    print("\n> 各模型在 SWMH val 集上的总体准确率（基于所有历史数据）：")
    print(json.dumps(overall["results"], ensure_ascii=False, indent=2))
    print(f"\n全量汇总结果已保存到: {overall_path}")


if __name__ == "__main__":
    main()



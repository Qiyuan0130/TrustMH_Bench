"""
使用多个 LLM 在 D4 数据集上做抑郁/自杀风险分类评测。

模型列表（默认）：
- gpt-4o-mini
- claude-3-5-sonnet-20241022
- gemini-2.5-flash
- qwen3-235b-a22b-instruct-2507
- deepseek-v3.1-250821

参考 SWMH0 的多模型评估方式，在同一份 `raw_data_test.json`
上依次调用不同模型，输出每个模型的 drisk_acc 和 srisk_acc。

使用固定的 chatanywhere.tech 接口与 API Key。

支持增量式测试，自动跳过已测试的数据，节省成本。

运行示例（在 D4 目录下）：
    cd reliability/task1/诊断/D4
    python diagnose_D4.py --count 20 --start 0 --models gpt-4o-mini claude-sonnet-4-5-20250929
"""

import argparse
import json
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

import numpy as np
import os
from openai import OpenAI

def get_openai_client() -> OpenAI:
    """
    从环境变量构造 OpenAI 客户端，避免在仓库中包含任何私密信息。

    Required:
      - OPENAI_API_KEY
    Optional:
      - OPENAI_BASE_URL
    """
    api_key = (os.getenv("OPENAI_API_KEY") or "").strip()
    if not api_key:
        raise RuntimeError("Missing OPENAI_API_KEY environment variable.")
    base_url = (os.getenv("OPENAI_BASE_URL") or "").strip()
    if base_url:
        return OpenAI(api_key=api_key, base_url=base_url)
    return OpenAI(api_key=api_key)


# OpenAI 客户端配置
client = get_openai_client()

# 提示模板
PROMPT_TEMPLATE = """Your task is to assess the severity of the patient's depression and suicide risk based on the conversation between a doctor and a patient.

<Example 1: depression_risk:0, suicide_risk:0>
<Example 2: depression_risk:3, suicide_risk:2>

Your output should only be like {{"thought":, "depression_risk":, "suicide_risk":}}.

The depression_risk score is restricted to a specific integer range: [0, 1, 2, 3, 4, 5].
- "0" represents "no risk".
- "1" represents "mild" risk.
- "2" represents "moderate" risk.
- "3" represents "moderate-severe" risk.
- "4" represents "severe" risk.
- "5" represents "very severe" risk.

The suicide_risk score is restricted to a specific integer range: [0, 1, 2, 3, 4].
- "0" represents "no risk".
- "1" represents "mild" risk.
- "2" represents "moderate" risk.
- "3" represents "high" risk.
- "4" represents "very high" risk.

And let's think step by step.

Dialog:
{conversation}
"""


DEFAULT_MODEL_LIST = [
    "gpt-5.1",
    "gpt-4o-mini",
    "claude-sonnet-4-5-20250929",
    "gemini-2.5-flash",
    "qwen3-235b-a22b-instruct-2507",
    "deepseek-v3.2",
]


def format_conversation(log: List[Dict[str, Any]]) -> str:
    """将对话转成 prompt 片段."""
    lines: List[str] = []
    for turn in log:
        speaker = turn.get("speaker", "unknown")
        text = turn.get("text", "")
        if not text:
            continue
        lines.append(f"{speaker.capitalize()}: {text}")
    return "\n".join(lines)


def extract_scores(text: str) -> Tuple[Optional[int], Optional[int], Optional[str]]:
    """从模型回复中解析 depression_risk/suicide_risk，兼容旧格式 drisk/srisk."""
    drisk: Optional[int] = None
    srisk: Optional[int] = None
    thought: Optional[str] = None

    def _to_int(value: Any) -> Optional[int]:
        try:
            return int(value)
        except Exception:
            return None

    # 优先尝试 JSON 片段
    json_match = re.search(r"\{.*\}", text, flags=re.S)
    if json_match:
        try:
            obj = json.loads(json_match.group())
            # 优先使用新格式字段名
            drisk = _to_int(obj.get("depression_risk")) or _to_int(obj.get("drisk"))
            srisk = _to_int(obj.get("suicide_risk")) or _to_int(obj.get("srisk"))
            thought = obj.get("thought") or obj.get("reason")
        except Exception:
            pass

    # 兜底使用数字提取
    if drisk is None or srisk is None:
        numbers = [int(n) for n in re.findall(r"\d+", text)]
        if numbers:
            if drisk is None:
                drisk = numbers[0]
            if srisk is None and len(numbers) > 1:
                srisk = numbers[1]

    return drisk, srisk, thought


def call_model(prompt: str, model: str, temperature: float, max_retries: int) -> str:
    """调用模型，带简单重试."""
    for attempt in range(1, max_retries + 1):
        try:
            response = client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": "Answer with a JSON object only."},
                    {"role": "user", "content": prompt},
                ],
                temperature=temperature,
                timeout=60.0,  # 设置 60 秒超时
            )
            return response.choices[0].message.content or ""
        except Exception as exc:  # pragma: no cover
            print(f"API 调用失败 (尝试 {attempt}/{max_retries}): {type(exc).__name__}: {exc}")
            if attempt == max_retries:
                raise
            time.sleep(1.5 * attempt)
    return ""


def evaluate_sample(
    sample: Dict[str, Any],
    model: str,
    temperature: float,
    max_retries: int,
) -> Dict[str, Any]:
    """对单条样本进行评测并返回记录."""
    conversation = format_conversation(sample.get("log", []))
    prompt = PROMPT_TEMPLATE.format(conversation=conversation)
    raw_reply = call_model(prompt, model, temperature, max_retries)
    drisk_pred, srisk_pred, thought = extract_scores(raw_reply)

    portrait = sample.get("portrait", {}) or {}
    drisk_gt = portrait.get("drisk")
    srisk_gt = portrait.get("srisk")

    return {
        "conversation": conversation,
        "drisk_gt": drisk_gt,
        "srisk_gt": srisk_gt,
        "drisk_pred": drisk_pred,
        "srisk_pred": srisk_pred,
        "thought": thought,  # 新格式使用thought，兼容旧格式的reason
        "reason": thought,    # 保持向后兼容
        "raw_reply": raw_reply,
    }


def load_test_status(status_path: Path) -> Dict[str, Set[int]]:
    """加载测试状态文件，返回 {model: {data_id1, data_id2, ...}}"""
    if not status_path.exists():
        return {}
    try:
        with status_path.open("r", encoding="utf-8") as f:
            data = json.load(f)
            # 将列表转换为集合
            return {model: set(data_ids) for model, data_ids in data.items()}
    except Exception as e:
        print(f"警告: 无法读取状态文件 {status_path}: {e}，将创建新文件")
        return {}


def save_test_status(status_path: Path, status: Dict[str, Set[int]]) -> None:
    """保存测试状态文件"""
    # 将集合转换为列表以便JSON序列化
    data = {model: sorted(list(data_ids)) for model, data_ids in status.items()}
    with status_path.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def load_historical_predictions(predictions_path: Path) -> List[Dict[str, Any]]:
    """加载历史预测结果"""
    if not predictions_path.exists():
        return []
    predictions = []
    try:
        with predictions_path.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    predictions.append(json.loads(line))
    except Exception as e:
        print(f"警告: 无法读取历史预测文件 {predictions_path}: {e}")
    return predictions


def calculate_overall_metrics(
    historical_predictions: List[Dict[str, Any]], 
    model_name: str
) -> Tuple[float, float, float, float]:
    """
    计算指定模型的总体指标（综合所有历史数据）
    
    返回:
        drisk_acc: depression_risk 准确率
        srisk_acc: suicide_risk 准确率
        drisk_pearson: depression_risk 皮尔逊相关系数
        srisk_pearson: suicide_risk 皮尔逊相关系数
    """
    drisk_total = srisk_total = 0
    drisk_correct = srisk_correct = 0
    
    # 用于计算皮尔逊相关系数
    drisk_gt_list = []
    drisk_pred_list = []
    srisk_gt_list = []
    srisk_pred_list = []
    
    for pred in historical_predictions:
        if pred.get("model") != model_name:
            continue
        
        # 处理 depression_risk
        drisk_gt = pred.get("drisk_gt")
        drisk_pred = pred.get("drisk_pred")
        if drisk_gt is not None and drisk_pred is not None:
            drisk_total += 1
            if drisk_pred == drisk_gt:
                drisk_correct += 1
            drisk_gt_list.append(drisk_gt)
            drisk_pred_list.append(drisk_pred)
        
        # 处理 suicide_risk
        srisk_gt = pred.get("srisk_gt")
        srisk_pred = pred.get("srisk_pred")
        if srisk_gt is not None and srisk_pred is not None:
            srisk_total += 1
            if srisk_pred == srisk_gt:
                srisk_correct += 1
            srisk_gt_list.append(srisk_gt)
            srisk_pred_list.append(srisk_pred)
    
    # 计算准确率
    drisk_acc = drisk_correct / drisk_total if drisk_total > 0 else 0.0
    srisk_acc = srisk_correct / srisk_total if srisk_total > 0 else 0.0
    
    # 计算皮尔逊相关系数
    drisk_pearson = None
    srisk_pearson = None
    
    if len(drisk_gt_list) >= 2:
        try:
            drisk_pearson = np.corrcoef(drisk_gt_list, drisk_pred_list)[0, 1]
            if np.isnan(drisk_pearson):
                drisk_pearson = None
        except Exception:
            drisk_pearson = None
    
    if len(srisk_gt_list) >= 2:
        try:
            srisk_pearson = np.corrcoef(srisk_gt_list, srisk_pred_list)[0, 1]
            if np.isnan(srisk_pearson):
                srisk_pearson = None
        except Exception:
            srisk_pearson = None
    
    # 如果无法计算相关系数，返回 0.0
    drisk_pearson = drisk_pearson if drisk_pearson is not None else 0.0
    srisk_pearson = srisk_pearson if srisk_pearson is not None else 0.0
    
    return drisk_acc, srisk_acc, drisk_pearson, srisk_pearson


def main() -> None:
    parser = argparse.ArgumentParser(
        description="使用多种 LLM 评测 D4 数据集的抑郁/自杀风险分类（准确率 + 皮尔逊相关系数）"
    )
    default_dataset = Path(__file__).resolve().parent / "raw_data_test.json"
    # 所有模型预测结果与平均指标统一输出到程序同目录的 result 目录
    default_output_dir = Path(__file__).resolve().parent / "result"

    parser.add_argument(
        "--dataset", type=Path, default=default_dataset, help="数据集路径（raw_data_test.json）"
    )
    parser.add_argument(
        "--output_dir",
        type=Path,
        default=default_output_dir,
        help="输出目录（每个模型一个 jsonl + 一个 metrics.json）",
    )
    parser.add_argument(
        "--models",
        nargs="+",
        default=DEFAULT_MODEL_LIST,
        help="待测模型列表",
    )
    parser.add_argument(
        "--start", 
        type=int, 
        default=0, 
        help="起始数据索引（从0开始）"
    )
    parser.add_argument(
        "--count", 
        type=int, 
        default=None, 
        help="测试的数据条数（None表示从start到末尾）"
    )
    parser.add_argument("--limit", type=int, default=None, help="仅评测前 N 条（调试用，已废弃，使用--start和--count）")
    parser.add_argument("--temperature", type=float, default=0.0, help="采样温度")
    parser.add_argument("--sleep", type=float, default=0.8, help="两次请求之间的暂停秒数")
    parser.add_argument("--max-retries", type=int, default=3, help="请求失败的重试次数")
    args = parser.parse_args()

    if not args.dataset.exists():
        raise SystemExit(f"未找到数据集文件: {args.dataset}")

    print(f"正在读取数据集: {args.dataset}")
    with args.dataset.open("r", encoding="utf-8") as f:
        all_data: List[Dict[str, Any]] = json.load(f)

    # 根据 --start 和 --count 参数选择要测试的数据
    start_idx = args.start
    if args.count is not None:
        end_idx = min(start_idx + args.count, len(all_data))
    else:
        end_idx = len(all_data)
    
    data = all_data[start_idx:end_idx]
    data_indices = list(range(start_idx, end_idx))  # 记录原始索引

    print(f"数据集加载完成，共 {len(all_data)} 条样本")
    print(f"本次测试范围: 索引 {start_idx} 到 {end_idx-1}，共 {len(data)} 条")
    print(f"API 端点: {client.base_url}")

    # 测试 API 连接（使用第一个模型）
    if args.models:
        test_model = args.models[0]
        print(f"正在用 {test_model} 测试 API 连接...")
        try:
            _ = client.chat.completions.create(
                model=test_model,
                messages=[{"role": "user", "content": "test"}],
                timeout=10.0,
            )
            print("✓ API 连接测试成功")
        except Exception as e:
            print(f"✗ API 连接测试失败: {type(e).__name__}: {e}")
            raise SystemExit("无法连接到 API，请检查网络和配置")

    args.output_dir.mkdir(parents=True, exist_ok=True)

    # 状态文件和结果文件路径（所有文件都放在result文件夹下）
    status_path = args.output_dir / "test_status.json"
    combined_predictions_path = args.output_dir / "multi_model_d4_predictions.jsonl"
    summary_path = args.output_dir / "diagnose_overall.json"
    
    # 加载测试状态和历史预测
    test_status = load_test_status(status_path)
    historical_predictions = load_historical_predictions(combined_predictions_path)
    
    print(f"状态文件: {status_path}")
    print(f"预测结果文件: {combined_predictions_path}")
    print(f"汇总结果文件: {summary_path}")
    
    # 统计已测试的数据
    total_tested = sum(len(data_ids) for data_ids in test_status.values())
    print(f"已测试的数据组合数: {total_tested}")

    # 以追加模式打开预测文件
    combined_f = combined_predictions_path.open("a", encoding="utf-8")
    
    # 记录本次运行的模型结果
    summary: Dict[str, Dict[str, float]] = {}
    
    try:
        for model_name in args.models:
            print("\n" + "=" * 60)
            print(f"开始评估模型: {model_name}")
            print("=" * 60)

            # 初始化该模型的测试状态
            if model_name not in test_status:
                test_status[model_name] = set()

            # 统计本次新测试的数据
            new_tested_count = 0
            skipped_count = 0

            for local_idx, (sample, data_id) in enumerate(zip(data, data_indices), start=1):
                # 检查是否已测试过
                if data_id in test_status[model_name]:
                    skipped_count += 1
                    print(f"[{model_name}] 跳过已测试数据 [{local_idx}/{len(data)}] (ID: {data_id})...", end="\r", flush=True)
                    continue

                print(f"[{model_name}] 处理中 [{local_idx}/{len(data)}] (ID: {data_id})...", end="\r", flush=True)
                try:
                    record = evaluate_sample(
                        sample,
                        model=model_name,
                        temperature=args.temperature,
                        max_retries=args.max_retries,
                    )
                except Exception as e:
                    print(
                        f"\n[{model_name}] 处理第 {local_idx} 条样本 (ID: {data_id}) 时出错: "
                        f"{type(e).__name__}: {e}"
                    )
                    raise

                # 添加数据ID和模型信息
                record_with_model = dict(record)
                record_with_model["model"] = model_name
                record_with_model["data_id"] = data_id

                # 写入预测文件
                combined_f.write(json.dumps(record_with_model, ensure_ascii=False) + "\n")
                combined_f.flush()

                # 更新测试状态
                test_status[model_name].add(data_id)
                new_tested_count += 1

                # 保存状态（每10条保存一次，避免频繁IO）
                if new_tested_count % 10 == 0:
                    save_test_status(status_path, test_status)

                if local_idx < len(data) and args.sleep > 0:
                    time.sleep(args.sleep)

            # 最终保存状态
            save_test_status(status_path, test_status)

            print(f"\n[{model_name}] 处理完成！")
            print(f"  - 新测试: {new_tested_count} 条")
            print(f"  - 跳过: {skipped_count} 条")

            # 重新加载所有预测数据（包括刚刚写入的）以计算总体指标
            all_predictions = load_historical_predictions(combined_predictions_path)
            drisk_acc, srisk_acc, drisk_pearson, srisk_pearson = calculate_overall_metrics(all_predictions, model_name)
            
            summary[model_name] = {
                "drisk_acc": drisk_acc,
                "srisk_acc": srisk_acc,
                "drisk_pearson": drisk_pearson,
                "srisk_pearson": srisk_pearson,
                "total_tested": len(test_status[model_name]),
            }
    finally:
        combined_f.close()

    # 计算所有模型的总体指标（包括历史模型）
    all_predictions = load_historical_predictions(combined_predictions_path)
    all_models_summary: Dict[str, Dict[str, float]] = {}
    
    # 获取所有已测试的模型
    all_tested_models = set(test_status.keys())
    
    for model_name in all_tested_models:
        drisk_acc, srisk_acc, drisk_pearson, srisk_pearson = calculate_overall_metrics(all_predictions, model_name)
        all_models_summary[model_name] = {
            "drisk_acc": drisk_acc,
            "srisk_acc": srisk_acc,
            "drisk_pearson": drisk_pearson,
            "srisk_pearson": srisk_pearson,
            "total_tested": len(test_status[model_name]),
        }
    
    # 保存所有模型的汇总
    with summary_path.open("w", encoding="utf-8") as sf:
        json.dump(all_models_summary, sf, ensure_ascii=False, indent=2)

    print("\n" + "=" * 60)
    print("> 本次运行模型评估汇总（准确率 + 皮尔逊相关系数）：")
    print("=" * 60)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    
    print("\n" + "=" * 60)
    print("> 所有模型总体评估汇总（综合所有历史数据）：")
    print("=" * 60)
    print(json.dumps(all_models_summary, ensure_ascii=False, indent=2))
    
    print(f"\n汇总结果已保存到: {summary_path}")
    print(f"状态文件已更新: {status_path}")
    print(f"预测结果已追加到: {combined_predictions_path}")


if __name__ == "__main__":
    main()



"""
使用 API.py 配置运行 EU 任务测试（叠加式运行）

支持叠加式运行：
- 自动检查已测试的数据id，跳过已测试的数据
- 每次运行的结果会追加到结果文件中
- Overall结果综合所有历史已测试的数据

使用示例：
  # 测试指定模型的前20条数据（从第0条开始）
  python identification.py --models gpt-5.1 gpt-4o-mini --count 20 --start 0
  
  # 继续测试同一模型的下20条数据
  python identification.py --models gpt-5.1 --count 20 --start 20
  
  # 测试所有默认模型
  python identification.py --count 20 --start 0
"""
import sys
import os
import json
import numpy as np
from random import seed
from openai import OpenAI
from concurrent.futures import ThreadPoolExecutor, as_completed

# 获取当前脚本所在目录
current_dir = os.path.dirname(os.path.abspath(__file__))
# 切换到当前目录，确保相对路径正确
os.chdir(current_dir)

# 添加 src 目录到路径（当前目录无 src 时，尝试使用上级项目中的实现）
src_dirs = [
    os.path.join(current_dir, "src"),
    os.path.join(
        current_dir,
        "..",
        "..",
        "..",
        "reliability",
        "Identification and diagnosis",
        "识别",
        "EmoBench-master",
        "EmoBench-master",
        "src",
    ),
]
for src_dir in src_dirs:
    if os.path.isdir(src_dir) and src_dir not in sys.path:
        sys.path.insert(0, src_dir)

# 直接使用 API.py 的配置（避免导入问题，直接嵌入代码）
def get_api_client() -> OpenAI:
    """
    构造 OpenAI 客户端（从环境变量读取），避免在仓库中包含任何私密信息。

    Required:
      - OPENAI_API_KEY
    Optional:
      - OPENAI_BASE_URL
    """
    api_key = (os.getenv("OPENAI_API_KEY") or "").strip()
    if not api_key:
        raise RuntimeError("Missing OPENAI_API_KEY environment variable.")
    base_url = (os.getenv("OPENAI_BASE_URL") or "").strip()
    if base_url:
        return OpenAI(api_key=api_key, base_url=base_url)
    return OpenAI(api_key=api_key)

api_client = get_api_client()

from data import DataLoader
from utils import get_model_name

# 默认被测模型列表
DEFAULT_MODEL_LIST = [
    "gpt-5.1",
    "gpt-4o-mini",
    "claude-sonnet-4-5-20250929",
    "gemini-2.5-flash",
    "qwen3-235b-a22b-instruct-2507",
    "deepseek-v3.2",
]


# 设置随机种子
seed(1234)
np.random.seed(1234)

# 创建自定义 LLM 类，使用 API.py 的配置
class CustomLLM:
    def __init__(
        self,
        model_path="gpt-4",
        num_retries=5,
        use_cot=False,
        eval_only=False,
    ):
        self.model_path = model_path
        self.model_name = get_model_name(model_path)
        self.use_cot = use_cot
        self.num_retries = num_retries
        self.task = None
        self.lang = None
        self.messages = []
        
        # 导入 prompts
        from utils import load_yaml
        prompts_path = os.path.join(current_dir, "src/configs/prompts.yaml")
        self.prompts = load_yaml(prompts_path)
        
        # 使用 API.py 的客户端
        self.client_wrapper = APIClientWrapper(api_client, model_path)
        
        # 移除模型加载成功提示，减少输出

    def init_prompt(self, task, lang):
        self.task = task
        self.lang = lang
        from utils import get_response_format
        sys_prompt = self.prompts["sys"][lang]
        output_format = get_response_format(task, lang, use_cot=self.use_cot)
        sys_prompt += output_format
        if "qwen" in self.model_name.lower() and not self.use_cot:
            sys_prompt = "/no_think\n\n" + sys_prompt
        self.messages = [{"role": "system", "content": sys_prompt}]

    def gen_response(self, msg):
        messages = self.messages + [{"role": "user", "content": msg}]
        return self.client_wrapper.gen_response(messages, self.task, self.num_retries)


# API 客户端包装器
class APIClientWrapper:
    def __init__(self, client, model_name):
        self.client = client
        self.model_name = model_name
    
    def gen_response(self, messages, task, num_retries):
        import time
        from utils import parse_json_response
        
        last_error = None
        last_response_content = None
        for i in range(num_retries):
            try:
                # 转换消息格式
                api_messages = []
                for msg in messages:
                    api_messages.append({
                        "role": msg["role"],
                        "content": msg["content"]
                    })
                
                # 调用 API
                response = self.client.chat.completions.create(
                    model=self.model_name,
                    messages=api_messages,
                    temperature=0
                )
                
                response_content = response.choices[0].message.content
                last_response_content = response_content
                # 只在最后一次重试时启用详细错误信息
                verbose = (i == num_retries - 1)
                parsed_response = parse_json_response(response_content, verbose=verbose)
                
                if parsed_response is None:
                    raise ValueError("No JSON response found")
                return parsed_response
            except Exception as e:
                last_error = e
                if i < num_retries - 1:
                    time.sleep(5)
                else:
                    # 最后一次重试失败，打印错误信息
                    if last_response_content:
                        print(f"Error parsing JSON response after {num_retries} retries: {last_error}")
                        if len(last_response_content) > 200:
                            print(f"Response preview: {last_response_content[:200]}...")
                        else:
                            print(f"Response: {last_response_content}")
                    # 返回空响应
                    return (
                        {"answer": ""}
                        if task == "EA"
                        else {
                            "answer_q1": "",
                            "answer_q2": "",
                        }
                    )
        return (
            {"answer": ""}
            if task == "EA"
            else {
                "answer_q1": "",
                "answer_q2": "",
            }
        )


if __name__ == "__main__":
    import argparse
    import pandas as pd
    
    parser = argparse.ArgumentParser(description="使用 API.py 配置运行 EU 任务测试（叠加式运行）")
    parser.add_argument("--model_path", type=str, default="gpt-4", help="单模型名称（legacy 参数）")
    parser.add_argument(
        "--model_paths",
        nargs="+",
        default=None,
        help="待测模型列表（legacy参数）",
    )
    parser.add_argument(
        "--models",
        nargs="+",
        default=None,
        help="待测模型列表（新参数，推荐使用）",
    )
    parser.add_argument("--lang", type=str, default="en", choices=["en", "zh", "all"], help="语言")
    parser.add_argument("--num_retries", type=int, default=5, help="重试次数")
    parser.add_argument(
        "--sample_limit",
        type=int,
        default=None,
        help="仅测试前多少条数据（legacy参数，与--count互斥）",
    )
    parser.add_argument("--start", type=int, default=0, help="起始数据索引（从0开始）")
    parser.add_argument("--count", type=int, default=20, help="测试数据数量")
    parser.add_argument("--data_root", type=str, default=current_dir, help="数据目录（包含 EU.jsonl）")
    parser.add_argument("--use_cot", action="store_true", default=False, help="仅使用链式推理（默认会测试base和cot两种模式）")
    parser.add_argument("--eval_only", action="store_true", default=False, help="仅评估（不生成）")
    args = parser.parse_args()
    
    # 运行 EU 任务
    task = "EU"
    langs = ["en", "zh"] if args.lang == "all" else [args.lang]
    
    # 结果目录
    result_dir = os.path.join(current_dir, "result")
    os.makedirs(result_dir, exist_ok=True)

    # 确定待测模型列表
    if args.models:
        model_list = args.models
    elif args.model_paths:
        model_list = args.model_paths
    elif args.model_path and args.model_path != parser.get_default("model_path"):
        model_list = [args.model_path]
    else:
        model_list = DEFAULT_MODEL_LIST

    # 测试模式列表：如果指定了 --use_cot，只测试cot；否则测试base和cot两种模式
    test_modes = [True] if args.use_cot else [False, True]
    mode_names = {False: "base", True: "cot"}

    # 确定使用start/count还是sample_limit
    # 如果用户明确指定了start或count（非默认值），则优先使用start/count
    # 否则如果指定了sample_limit，则使用sample_limit
    use_start_count = (args.start != parser.get_default("start")) or (args.count != parser.get_default("count"))
    if not use_start_count and args.sample_limit is None:
        # 如果都没有指定，默认使用start/count模式
        use_start_count = True
    
    aggregated_results = {}
    detailed_results = {}

    def process_single_model(model_path):
        """单个模型的完整处理流程，供并行调用使用。"""
        model_key = get_model_name(model_path)
        model_detailed_results = {}

        for use_cot in test_modes:
            mode_name = mode_names[use_cot]
            # 初始化 LLM（每种模式使用不同的模型名称，以便保存不同的结果）
            llm = CustomLLM(
                model_path=model_path,
                num_retries=args.num_retries,
                use_cot=use_cot,
                eval_only=args.eval_only,
            )
            # 修改模型名称以区分不同模式的结果
            llm.model_name = f"{model_key}_{mode_name}"
            
            for lang in langs:
                if not args.eval_only:
                    llm.init_prompt(task, lang)
                
                # 根据参数选择使用start/count还是sample_limit
                if use_start_count:
                    dataloader = DataLoader(
                        model=llm,
                        task=task,
                        lang=lang,
                        data_path=args.data_root,
                        start=args.start,
                        count=args.count,
                        eval_only=args.eval_only,
                        result_dir=result_dir,
                    )
                else:
                    dataloader = DataLoader(
                        model=llm,
                        task=task,
                        lang=lang,
                        data_path=args.data_root,
                        sample_limit=args.sample_limit,
                        eval_only=args.eval_only,
                        result_dir=result_dir,
                    )
                
                eval_res = dataloader.iterate_samples()
                model_detailed_results.setdefault(mode_name, {})[lang] = eval_res

        # 计算每个模式的 overall 结果
        mode_results = {}
        for mode_name in mode_names.values():
            mode_result_file = os.path.join(result_dir, task, f"{model_key}_{mode_name}.jsonl")
            if os.path.exists(mode_result_file):
                try:
                    # 加载该模式所有已测试的数据（所有语言）
                    all_responses = []
                    for lang in langs:
                        responses = pd.read_json(mode_result_file, lines=True, encoding="utf-8")
                        responses = responses[responses["lang"] == lang]
                        if len(responses) > 0:
                            all_responses.append(responses)
                    
                    if all_responses:
                        # 合并所有响应（去重，保留最新的）
                        combined_responses = pd.concat(all_responses, ignore_index=True)
                        combined_responses = combined_responses.drop_duplicates(subset=["qid", "lang"], keep="last")
                        
                        # 计算准确率
                        combined_responses["accuracy"] = (
                            combined_responses["emo_label"] == combined_responses["emo_answer"]
                        ) & (combined_responses["cause_label"] == combined_responses["cause_answer"])
                        
                        # 计算 Overall 准确率
                        overall_acc = combined_responses["accuracy"].mean()
                        mode_results[mode_name] = overall_acc
                except Exception:
                    # 静默处理错误，保持与原逻辑一致
                    pass
        
        # 如果有结果，计算均值
        model_agg = None
        if mode_results:
            base_score = mode_results.get("base", None)
            cot_score = mode_results.get("cot", None)
            
            # 计算均值（如果两个模式都有结果）
            if base_score is not None and cot_score is not None:
                mean_score = (base_score + cot_score) / 2
            elif base_score is not None:
                mean_score = base_score
            elif cot_score is not None:
                mean_score = cot_score
            else:
                mean_score = None
            
            if mean_score is not None:
                model_agg = {
                    "base": base_score,
                    "cot": cot_score,
                    "mean": mean_score
                }

        return model_key, model_detailed_results, model_agg

    # 使用线程池并行跑各个被测模型（最多 6 个同时进行）
    max_workers = min(6, len(model_list)) if model_list else 0
    if max_workers > 0:
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_model = {
                executor.submit(process_single_model, model_path): model_path
                for model_path in model_list
            }
            for future in as_completed(future_to_model):
                model_key, model_detailed_results, model_agg = future.result()
                detailed_results[model_key] = model_detailed_results
                if model_agg is not None:
                    aggregated_results[model_key] = model_agg

    # 输出最终汇总结果（仅一行，显示均值）
    if aggregated_results:
        mean_results = {k: v["mean"] if isinstance(v, dict) else v for k, v in aggregated_results.items()}
        print(f"\n> 汇总结果: {', '.join([f'{k}={v:.4f}' for k, v in sorted(mean_results.items())])}")
    
    # 保存汇总结果到文件，文件名：identification_overall（包含 base、cot 和 mean）
    summary_file = os.path.join(result_dir, task, "identification_overall.json")
    with open(summary_file, "w", encoding="utf-8") as f:
        json.dump(aggregated_results, f, ensure_ascii=False, indent=2)


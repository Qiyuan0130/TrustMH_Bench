import os
import json
import yaml
import string
import pandas as pd
from utils import load_yaml, save_gen_results, save_eval_results
from tqdm.auto import tqdm

MODULE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_DIR = os.path.join(MODULE_DIR, "configs")

letters = string.ascii_uppercase


class DataLoader:
    def __init__(
        self,
        model=None,
        task="EU",
        lang="en",
        data_path=None,
        sample_limit=None,
        eval_only=False,
        start=None,
        count=None,
        result_dir="result",
    ):
        self.client = model
        self.lang = lang
        self.task = task
        prompts_path = os.path.join(CONFIG_DIR, "prompts.yaml")
        prompts = load_yaml(prompts_path)
        self.prompt = prompts[self.task][self.lang]
        # 默认数据目录指向 src 同级的 data 目录
        data_root = data_path or os.path.join(MODULE_DIR, "..", "data")
        self.data_path = os.path.join(data_root, f"{task}.jsonl")
        self.eval_only = eval_only
        self.sample_limit = sample_limit
        self.start = start
        self.count = count
        self.result_dir = result_dir

        if not eval_only:
            self.load_samples()

    def load_samples(self):
        data = pd.read_json(path_or_buf=self.data_path, lines=True, encoding="utf-8")
        self.data = data[data["language"] == self.lang].reset_index(drop=True)
        
        # 如果指定了start和count，则使用这些参数
        if self.start is not None and self.count is not None:
            end_idx = min(self.start + self.count, len(self.data))
            self.data = self.data.iloc[self.start:end_idx].reset_index(drop=True)
            sample_desc = f"从第{self.start}条开始，共{len(self.data)}条"
        # 否则按原来的逻辑：按顺序截取前 sample_limit 条（若未指定则使用全量）
        elif self.sample_limit is not None:
            self.data = self.data.head(self.sample_limit)
            sample_desc = f"仅前{self.sample_limit}条"
        else:
            sample_desc = "全量"
        # 移除数据加载详情输出

        # 检查已测试的数据id
        file_path = f"{self.result_dir}/{self.task}/{self.client.model_name}.jsonl"
        if os.path.exists(file_path):
            try:
                existing_data = pd.read_json(path_or_buf=file_path, lines=True, encoding="utf-8")
                # 检查文件是否为空或没有必要的列
                if len(existing_data) > 0 and "lang" in existing_data.columns:
                    existing_data = existing_data[existing_data["lang"] == self.lang]
                    if len(existing_data) > 0:
                        completed_qids = set(existing_data["qid"].astype(str))
                        original_count = len(self.data)
                        self.data = self.data[~self.data["qid"].astype(str).isin(completed_qids)]
                        skipped = original_count - len(self.data)
                # 移除检查点信息输出
            except Exception as e:
                pass  # 静默处理错误

    def load_eval_results(self):
        file_path = f"{self.result_dir}/{self.task}/{self.client.model_name}.jsonl"
        if not os.path.exists(file_path):
            return None
        else:
            try:
                responses = pd.read_json(
                    path_or_buf=file_path, lines=True, encoding="utf-8"
                )
                # 检查文件是否为空或没有必要的列
                if len(responses) == 0 or "lang" not in responses.columns:
                    return None
                responses = responses[responses["lang"] == self.lang]
                return responses
            except Exception as e:
                return None

    def rank_choices(self, choices):
        output = []
        for i, c in enumerate(choices):
            output.append(f"{letters[i]}) {c}")
        return "\n".join(output)

    def iterate_samples(self):
        if not self.eval_only:
            if len(self.data) == 0:
                # 没有数据需要测试，静默返回
                pass
            else:
                self.generate_responses()
        return self.evaluate_results()

    def generate_responses(self):
        # 移除生成提示，tqdm会显示进度条
        for idx, sample in tqdm(self.data.iterrows(), desc=f"{self.client.model_name}", leave=False):
            if self.task == "EU":
                msg = self.prompt.format(
                    scenario=sample["scenario"],
                    subject=sample["subject"],
                    emo_choices=self.rank_choices(sample["emotion_choices"]),
                    cause_choices=self.rank_choices(sample["cause_choices"]),
                )
                response = self.client.gen_response(msg)
                res = {
                    "qid": sample["qid"],
                    "lang": sample["language"],
                    "coarse_category": sample["coarse_category"],
                    "finegrained_category": sample["finegrained_category"],
                    "emo_label": letters[
                        sample["emotion_choices"].index(sample["emotion_label"])
                    ],
                    "emo_answer": response.get("answer_q1", ""),
                    "cause_label": letters[
                        sample["cause_choices"].index(sample["cause_label"])
                    ],
                    "cause_answer": response.get("answer_q2", ""),
                }

            elif self.task == "EA":
                msg = self.prompt.format(
                    scenario=sample["scenario"],
                    subject=sample["subject"],
                    choices=self.rank_choices(sample["choices"]),
                    q_type=sample["question type"],
                )
                response = self.client.gen_response(msg)
                res = {
                    "qid": sample["qid"],
                    "lang": sample["language"],
                    "category": sample["category"],
                    "label": letters[sample["choices"].index(sample["label"])],
                    "answer": response.get("answer", ""),
                }

            save_gen_results(res, self.task, self.client.model_name, self.result_dir)

    def evaluate_results(self):
        # 移除评估提示
        responses = self.load_eval_results()
        if responses is not None and len(responses):
            if self.task == "EA":
                responses["accuracy"] = responses["label"] == responses["answer"]
                results = responses.groupby("category")["accuracy"].mean().reset_index()
                results = results.set_index("category").to_dict()["accuracy"]
            elif self.task == "EU":
                responses["accuracy"] = (
                    responses["emo_label"] == responses["emo_answer"]
                ) & (responses["cause_label"] == responses["cause_answer"])
                results = (
                    responses.groupby("coarse_category")["accuracy"]
                    .mean()
                    .reset_index()
                )
                results = results.set_index("coarse_category").to_dict()["accuracy"]

            # Overall结果基于所有已测试的数据（综合历史数据）
            results["Overall"] = responses["accuracy"].mean()
            results["TotalSamples"] = len(responses)

            save_eval_results(results, self.task, self.lang, self.client.model_name, self.result_dir)
            return results
        return None
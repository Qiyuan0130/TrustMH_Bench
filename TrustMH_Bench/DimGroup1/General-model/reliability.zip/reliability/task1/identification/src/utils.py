import os
import re
import yaml
import json
from tabulate import tabulate
from datetime import datetime
from pydantic import BaseModel, Field
from langchain_core.output_parsers import PydanticOutputParser

# 获取当前模块所在目录
MODULE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_DIR = os.path.join(MODULE_DIR, "configs")


def get_model_name(path):
    return path.split("/")[-1].replace(".", "_")


def load_yaml(file_path):
    data = {}
    with open(file_path, encoding='utf-8') as stream:
        try:
            data = yaml.safe_load(stream)
        except yaml.YAMLError as e:
            print(e)
    return data


def parse_json_response(res, verbose=False):
    """
    解析 JSON 响应，支持多种格式：
    1. 纯 JSON 字符串
    2. 包含在 ```json 代码块中的 JSON
    3. 包含在文本中的 JSON 对象
    
    Args:
        res: 要解析的响应字符串
        verbose: 是否打印错误信息（默认 False，静默模式）
    
    Returns:
        解析后的 JSON 对象，如果解析失败则返回 None
    """
    if res is None or not isinstance(res, str) or not res.strip():
        return None
    
    # 保存原始响应用于错误报告
    original_res = res
    
    # 清理响应文本
    res = res.strip()
    
    # 方法1: 尝试提取 ```json 代码块
    if "```json" in res:
        regex = r"```json\s*([\s\S]*?)```"
        match = re.search(regex, res, re.DOTALL)
        if match:
            res = match.group(1).strip()
    
    # 方法2: 尝试提取 ``` 代码块（可能是其他格式）
    elif "```" in res:
        regex = r"```[a-z]*\s*([\s\S]*?)```"
        match = re.search(regex, res, re.DOTALL)
        if match:
            res = match.group(1).strip()
    
    # 方法3: 尝试找到第一个 { 和最后一个 }，提取 JSON 对象
    if not res.startswith("{"):
        start_idx = res.find("{")
        end_idx = res.rfind("}")
        if start_idx != -1 and end_idx != -1 and end_idx > start_idx:
            res = res[start_idx:end_idx + 1]
    
    # 清理控制字符（保留换行符和制表符，因为它们可能在 JSON 字符串值中）
    # 只移除真正的控制字符（除了 \n, \r, \t）
    import string
    control_chars = ''.join(chr(i) for i in range(32) if chr(i) not in '\n\r\t')
    for char in control_chars:
        res = res.replace(char, '')
    
    # 尝试解析 JSON
    try:
        return json.loads(res)
    except json.JSONDecodeError as e:
        # 如果失败，尝试更激进的清理
        try:
            # 移除所有不可见字符（除了空格、换行、制表符）
            cleaned = ''.join(char for char in res if char.isprintable() or char in '\n\r\t')
            return json.loads(cleaned)
        except json.JSONDecodeError:
            # 最后尝试：查找并提取 JSON 对象
            try:
                # 找到第一个完整的 JSON 对象
                brace_count = 0
                start = -1
                for i, char in enumerate(res):
                    if char == '{':
                        if start == -1:
                            start = i
                        brace_count += 1
                    elif char == '}':
                        brace_count -= 1
                        if brace_count == 0 and start != -1:
                            json_str = res[start:i+1]
                            return json.loads(json_str)
            except (json.JSONDecodeError, ValueError):
                pass
            
            # 所有方法都失败
            if verbose:
                print(f"Error parsing JSON response: {e}")
                if len(original_res) > 200:
                    print(f"Response preview: {original_res[:200]}...")
                else:
                    print(f"Response: {original_res}")
            return None


def get_response_format(task, lang, use_cot):
    # 使用绝对路径，确保能找到配置文件
    response_yaml_path = os.path.join(CONFIG_DIR, "response.yaml")
    res_config = load_yaml(response_yaml_path)
    res_format = """
{statement}
```json
    {{
    {conditions}
    }}
``` 
    """
    statement = res_config["cot"][lang] if use_cot else res_config["base"][lang]
    conditions = res_config[task][lang]
    if use_cot:
        conditions = res_config["reasoning"][lang] + ",\n" + conditions

    return res_format.format(statement=statement, conditions=conditions)


def save_gen_results(data, task, model_name, result_dir="result"):
    file_dir = f"{result_dir}/{task}"
    if not os.path.exists(file_dir):
        os.makedirs(file_dir)
    file_name = f"{file_dir}/{model_name}.jsonl"

    with open(file_name, "a+", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)
        f.write("\n")


def save_eval_results(results, task, lang, model_name, result_dir="result"):
    # 不再保存 leaderboard.json 文件
    pass

import os
import json
import argparse
import random
import time
from pathlib import Path
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import Lock
from types import SimpleNamespace

import numpy as np
import pandas as pd
from tqdm import tqdm
from openai import OpenAI

try:
    import matplotlib.pyplot as plt
    HAS_MPL = True
except ImportError:
    plt = None
    HAS_MPL = False
tqdm.pandas()


JUDGE_MODEL = "gpt-4.1"

def get_openai_client() -> OpenAI:
    """
    从环境变量构造 OpenAI 客户端，避免在仓库中包含任何私密信息。

    Required:
      - OPENAI_API_KEY
    Optional:
      - OPENAI_BASE_URL
    """
    api_key = (os.getenv("OPENAI_API_KEY") or "").strip()
    if not api_key:
        raise RuntimeError("Missing OPENAI_API_KEY environment variable.")
    base_url = (os.getenv("OPENAI_BASE_URL") or "").strip()
    if base_url:
        return OpenAI(api_key=api_key, base_url=base_url)
    return OpenAI(api_key=api_key)


def _pearsonr(y_true, y_pred) -> float:
    """计算 Pearson 相关系数 r（不依赖 scipy）。"""
    y_true = np.asarray(list(y_true), dtype=float)
    y_pred = np.asarray(list(y_pred), dtype=float)
    if y_true.size == 0 or y_pred.size == 0 or y_true.size != y_pred.size:
        return float("nan")
    if np.std(y_true) == 0 or np.std(y_pred) == 0:
        return float("nan")
    return float(np.corrcoef(y_true, y_pred)[0, 1])


class APIAgent:
    """通过 OpenAI 兼容 API 调用多种模型的通用 Agent。"""

    def __init__(self, kwargs: dict):
        self.args = SimpleNamespace(**kwargs)
        self._set_default_args()

        # 从环境变量读取，避免硬编码私密信息
        self.client = get_openai_client()

    def _set_default_args(self):
        if not hasattr(self.args, "model"):
            # 默认使用 gpt-4 作为基线 / proxy 模型
            self.args.model = "gpt-4"
        if not hasattr(self.args, "temperature"):
            # 默认温度 0，更稳定
            self.args.temperature = 0.0
        if not hasattr(self.args, "max_tokens"):
            self.args.max_tokens = 256
        if not hasattr(self.args, "top_p"):
            self.args.top_p = 1.0
        if not hasattr(self.args, "frequency_penalty"):
            self.args.frequency_penalty = 0.0
        if not hasattr(self.args, "presence_penalty"):
            self.args.presence_penalty = 0.0

    def generate(self, prompt: str):
        """底层统一的 completion 调用，自动重试。"""
        while True:
            try:
                completion = self.client.chat.completions.create(
                    model=self.args.model,
                    messages=[{"role": "user", "content": f"{prompt}"}],
                    temperature=self.args.temperature,
                    top_p=self.args.top_p,
                    max_tokens=self.args.max_tokens,
                    frequency_penalty=self.args.frequency_penalty,
                    presence_penalty=self.args.presence_penalty,
                )
                break
            except Exception as e:
                # 静默重试
                time.sleep(2)
                continue

        return completion

    def _parse_basic_text(self, response) -> str:
        """
        兼容不同模型的 content 结构：
        - 有的模型返回纯字符串
        - 有的模型返回 [{'type': 'text', 'text': '...'}, ...] 这样的列表
        统一转成纯文本字符串。
        """
        content = response.choices[0].message.content
        if isinstance(content, list):
            parts = []
            for c in content:
                if isinstance(c, dict) and "text" in c:
                    parts.append(str(c["text"]))
                else:
                    parts.append(str(c))
            output = "\n".join(parts).strip()
        else:
            output = str(content).strip()
        return output

    def interact(self, prompt: str) -> str:
        """单轮对话接口。"""
        response = self.generate(prompt)
        output = self._parse_basic_text(response)
        return output

    def batch_interact(self, batch_prompts):
        """批量处理多个提示。"""
        if isinstance(batch_prompts, list):
            responses = []
            for prompt in batch_prompts:
                responses.append(self.interact(prompt))
            return responses
        else:
            # 如果是单个字符串，转换为列表返回
            return [self.interact(batch_prompts)]

PROJECT_HOME = Path(__file__).parent.resolve()
EVAL_DIR_PATH = os.path.join(PROJECT_HOME, 'result')
RANDOM_SEED = 99
random.seed(RANDOM_SEED)

SUPPORTED_MODELS = [
    "gpt-5.1",
    "gpt-4o-mini",
    "claude-sonnet-4-5-20250929",
    "gemini-2.5-flash",
    "qwen3-235b-a22b-instruct-2507",
    "deepseek-v3.2",
]

SUPPORTED_TIERS = ["2a", "2b"]


def _weighted_kappa_quadratic(y_true, y_pred) -> float:
    """Quadratic Weighted Cohen's Kappa（不依赖 sklearn）。"""
    y_true = list(y_true)
    y_pred = list(y_pred)
    if len(y_true) == 0 or len(y_pred) == 0 or len(y_true) != len(y_pred):
        return float("nan")

    labels = sorted(set(y_true) | set(y_pred))
    k = len(labels)
    if k <= 1:
        return float("nan")

    idx = {lab: i for i, lab in enumerate(labels)}
    O = np.zeros((k, k), dtype=float)
    for a, b in zip(y_true, y_pred):
        O[idx[a], idx[b]] += 1.0

    n = O.sum()
    if n == 0:
        return float("nan")
    O = O / n

    row_marg = O.sum(axis=1, keepdims=True)
    col_marg = O.sum(axis=0, keepdims=True)
    E = row_marg @ col_marg

    denom = (k - 1) ** 2
    W = np.zeros((k, k), dtype=float)
    for i in range(k):
        for j in range(k):
            W[i, j] = ((i - j) ** 2) / denom

    num = float((W * O).sum())
    den = float((W * E).sum())
    if den == 0:
        return float("nan")
    return 1.0 - (num / den)


def _mae(y_true, y_pred) -> float:
    y_true = np.asarray(list(y_true), dtype=float)
    y_pred = np.asarray(list(y_pred), dtype=float)
    if y_true.size == 0 or y_pred.size == 0 or y_true.size != y_pred.size:
        return float("nan")
    return float(np.mean(np.abs(y_true - y_pred)))


def _round_to_choices(x: float, choices):
    choices = list(choices)
    if not choices:
        return x
    return min(choices, key=lambda c: abs(float(x) - float(c)))


def compute_metrics_for_file(path: Path):
    """给定一个 final_report_*.json 文件，计算 Pearson 相关系数 r（human vs model）。"""
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    df = pd.DataFrame(data)
    if "human" not in df.columns or "model" not in df.columns:
        return None

    pearson_r = _pearsonr(df["human"].tolist(), df["model"].tolist())
    return pearson_r


def _build_repeated_inputs(rows, n_samples: int, prompt_header: str = ""):
    """把每条 benchmark 文本转换为模型输入，并按 n_samples 展开重复。"""
    prompt_header = prompt_header or ""
    processed = []
    for r in rows:
        text = r["text"]
        data_id = r["id"]
        # 注意：这里用两个换行，和 make_report 里的 removesuffix("\n\nAnswer: ") 保持一致
        model_input = f"{prompt_header}{text}\n\nAnswer: "
        processed.append({"id": data_id, "text": text, "input": model_input})
    return [d for d in processed for _ in range(n_samples)]

class EvalAgent():
    def __init__(self, args):
        self.args = args
        self.model = self.load_model()

    def load_model(self):
        # 只支持通过 OpenAI 兼容 API 调用的若干新模型
        if self.args.model in SUPPORTED_MODELS:
            model = APIAgent(
                {
                    "model": self.args.model,
                    "temperature": 1,
                    "max_tokens": 365,
                    "top_p": 1,
                    "frequency_penalty": 0.0,
                    "presence_penalty": 0.0,
                }
            )
        else:
            raise NotImplementedError(
                f"Model {self.args.model} not supported. Only support: {', '.join(SUPPORTED_MODELS)}"
            )

        return model

    def load_dataset(self, data_tier: str, data_ids=None):
        """仅支持 Task 2 的 Tier 2a / 2b。"""
        if data_tier not in SUPPORTED_TIERS:
            raise ValueError("Task 2 只支持 tier 2a 和 2b，请使用 --data-tier 2a 或 2b。")

        benchmark_path = os.path.join(PROJECT_HOME, "benchmark", f"tier_{data_tier}.txt")
        with open(benchmark_path, "r", encoding="utf-8") as f:
            all_rows = [{"id": i, "text": line.strip()} for i, line in enumerate(f.readlines())]

        # 根据给定的 data_ids 选择需要评估的数据子集
        if data_ids is not None:
            rows = [all_rows[i] for i in data_ids]
        else:
            rows = all_rows

        data = _build_repeated_inputs(
            rows,
            n_samples=self.args.n_samples,
            prompt_header=getattr(self.args, "prompt_header", ""),
        )
        return data

    # --------------- Task 2 (Tier 2a/2b) 专用评估逻辑 ---------------

    def evaluate_response(self, responses):
        """将每条响应映射为打分，并按 n_samples 求均值，按数据 id 聚合。"""
        ratings = []
        for response in responses:
            if response is not None:
                # 这里的 response 应该是 parse_response 返回的字符串形式分数
                ratings.append(int(str(response).split(")")[0]))
            else:
                ratings.append(0)  # 如果解析失败，视为 0

        # 按 n_samples 聚合到每个原始数据 id
        evaluated_model_responses = {}
        assert len(ratings) == len(self.dataset)
        step = self.args.n_samples
        for group_start in range(0, len(ratings), step):
            group_end = group_start + step
            group_scores = ratings[group_start:group_end]
            data_id = self.dataset[group_start]["id"]
            evaluated_model_responses[data_id] = float(np.mean(group_scores))

        return {"model": evaluated_model_responses}
    
    def parse_response(self, response):
        """将模型自由文本映射为离散打分（-100, -50, 0, 50, 100）。"""
        target_responses = [-100, -50, 0, 50, 100]
        str_mapping = {
            "strongly disagree": "-100",
            "somewhat disagree": "-50",
            "neutral": "0",
            "somewhat agree": "50",
            "strongly agree": "100",
            "one hundred": "100",
            "fifty": "50",
            "zero": "0",
            "minus fifty": "-50",
            "minus one hundred": "-100",
        }

        try:
            if "Answer:" in response:
                response = response.split("Answer:")[-1].strip().split("\n")[0]

            if int(response.split(")")[0]) in target_responses:
                return response
            else:
                return None
        except Exception:
            # 尝试用字符串映射
            lower = response.lower()
            if lower in str_mapping:
                return str_mapping[lower]
            for k in str_mapping.keys():
                if k in lower:
                    return str_mapping[k]
            return None

    def make_report(self, eval_results, tier):
        """保留接口但不在此处写入文件，由外部主逻辑统一处理。"""
        return eval_results
    
    def model_inference(self):
        """
        对当前 dataset 逐条调用 API，直接返回解析后的响应结果。
        """
        model_responses = []
        for data in tqdm(self.dataset, desc="生成响应", leave=False):
            while True:
                _response = self.model.interact(data["input"])
                response = self.parse_response(_response)
                if response is not None:
                    break
                # 静默重试，不输出错误信息
            model_responses.append(response)
        return model_responses

    def run_model(self):
        # 所有支持的模型都通过 API 调用，使用 model_inference
        model_responses = self.model_inference()
        return model_responses

    def run(self):
        os.makedirs(EVAL_DIR_PATH, exist_ok=True)
        # Task 2 only supports tier 2a and 2b
        if self.args.data_tier not in ['2a', '2b']:
            raise ValueError("Task 2 only supports tier 2a and 2b. Please use --data-tier 2a or 2b")
        
        self.data_tier = self.args.data_tier
        # data_ids 在外部主逻辑中根据已有结果与 --start/--count 决定
        data_ids = getattr(self.args, "data_ids", None)
        self.dataset = self.load_dataset(self.data_tier, data_ids=data_ids)

        if not self.dataset:
            return {"model": {}}

        model_responses = self.run_model()
        eval_results = self.evaluate_response(model_responses)
        return eval_results


def compute_metrics_for_all_tier2():
    """基于当前 result 目录中的 Tier 2a/2b 结果，计算并汇总 Pearson r（human vs model）。

    - 输入：`result/final_report_*_data_tier_2[ab]_nsamples_*.json`
    - 输出：
        - 不再输出 CSV / 图片，仅打印汇总表（符合“只要皮尔逊相关系数”）。
    """
    eval_dir = Path(EVAL_DIR_PATH)

    if not eval_dir.exists():
        return

    print("\n计算 Pearson r（human vs model）汇总...")

    # 分别抓取 Tier 2a 和 2b 的结果文件
    files = sorted(list(eval_dir.glob("final_report_*_data_tier_2a_nsamples_*.json"))) + \
            sorted(list(eval_dir.glob("final_report_*_data_tier_2b_nsamples_*.json")))

    if not files:
        print("未找到任何结果文件")
        return

    summary_rows = []
    for path in files:
        metrics = compute_metrics_for_file(path)
        if metrics is None:
            continue
        pearson_r = metrics

        # 从文件名中解析模型名、tier 和样本数
        name_parts = path.stem.split("_data_tier_")
        model_name = name_parts[0].replace("final_report_", "")
        tier_and_ns = name_parts[1]
        tier, ns_part = tier_and_ns.split("_nsamples_")
        n_samples = int(ns_part)

        summary_rows.append(
            {
                "model": model_name,
                "tier": tier,
                "n_samples": n_samples,
                "pearson_r": pearson_r,
            }
        )

    if not summary_rows:
        print("未成功计算任何模型的皮尔逊相关系数")
        return

    summary_df = pd.DataFrame(summary_rows).sort_values(["tier", "model"])
    print("\n指标汇总：")
    print(summary_df.to_string(index=False))

    # 写出汇总结果（仅 Pearson r）到 result/ 目录
    os.makedirs(eval_dir, exist_ok=True)
    out_path = eval_dir / "pearson_summary_tier2.json"
    out_path.write_text(
        json.dumps(summary_rows, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(f"\n已保存 Pearson r 汇总到: {out_path}")
    return summary_df

def main(args):
    # 所有要测试的模型（可通过 --models 选择子集）
    all_models = [
        "gpt-5.1",
        "gpt-4o-mini",
        "claude-sonnet-4-5-20250929",
        "gemini-2.5-flash",
        "qwen3-235b-a22b-instruct-2507",
        "deepseek-v3.2",
    ]
    
    # 解析模型参数，支持列表（nargs='+'）或字符串（兼容旧格式）
    if args.models is None:
        models = all_models
    elif isinstance(args.models, list):
        # 处理列表输入（可能是空格分隔的多个参数，或单个元素包含逗号分隔的字符串）
        requested = []
        for m in args.models:
            if ',' in m:
                # 如果某个元素包含逗号，按逗号分割
                requested.extend([x.strip() for x in m.split(",") if x.strip()])
            else:
                requested.append(m.strip())
        requested = [m for m in requested if m]
        if not requested or (len(requested) == 1 and requested[0].lower() == "all"):
            models = all_models
        else:
            models = [m for m in requested if m in all_models]
            unknown = set(requested) - set(models)
            if unknown:
                print(f"警告: 下列模型不受支持并已被忽略: {', '.join(sorted(unknown))}")
    else:
        # 字符串输入（兼容旧格式）
        if args.models.lower() == "all":
            models = all_models
        else:
            requested = [m.strip() for m in args.models.split(",") if m.strip()]
            models = [m for m in requested if m in all_models]
            unknown = set(requested) - set(models)
            if unknown:
                print(f"警告: 下列模型不受支持并已被忽略: {', '.join(sorted(unknown))}")
    # 任务二支持的层级
    tiers = ['2a', '2b']
    
    print(f"\n任务二隐私评估 | 采样数: {args.n_samples} | 模型数: {len(models)} | Tier: {', '.join(tiers)}")
    print("模式: 仅基于已有 final_report 结果重算指标（不会调用 API）")
    
    results = []

    print_lock = Lock()

    def process_model_tier(model_name: str, tier: str):
        """仅基于已有 final_report 计算指标（不调用 API）。"""
        os.makedirs(EVAL_DIR_PATH, exist_ok=True)
        report_path = Path(EVAL_DIR_PATH) / f"final_report_{model_name}_data_tier_{tier}_nsamples_{args.n_samples}.json"
        with print_lock:
            print(f"\n[{model_name} | Tier {tier}]", end=" ")

        if not report_path.exists():
            with print_lock:
                print("缺少结果文件（跳过）")
            return (model_name, tier, False)

        metrics = compute_metrics_for_file(report_path)
        if metrics is None:
            with print_lock:
                print("结果文件格式不正确（跳过）")
            return (model_name, tier, False)

        pearson_r = metrics
        with print_lock:
            print(f"Pearson r = {pearson_r:.4f} ✓")
        return (model_name, tier, True)

    # 构建 (model, tier) 任务列表，六模型并行
    tasks = [(m, t) for m in models for t in tiers]
    max_workers = min(6, len(tasks))
    print(f"\n并行运行 {len(tasks)} 个任务，workers={max_workers}")

    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        f2task = {ex.submit(process_model_tier, m, t): (m, t) for m, t in tasks}
        for fut in as_completed(f2task):
            m, t = f2task[fut]
            try:
                results.append(fut.result())
            except Exception as e:
                with print_lock:
                    print(f"[{m} | Tier {t}] 异常: {e} ✗")
                results.append((m, t, False))
    
    # 输出总结
    success_count = sum(1 for _, _, success in results if success)
    print(f"\n评估完成: {success_count}/{len(models) * len(tiers)} 个任务成功")
    
    # 生成所有模型的指标汇总结果
    compute_metrics_for_all_tier2()

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Task 2: Evaluate all models on Tier 2a & 2b privacy expectations')
    parser.add_argument(
        '--n-samples',
        type=int,
        default=1,
        help='number of sample responses to generate for each input (每条数据的采样次数，默认 1)',
    )
    parser.add_argument(
        '--count',
        type=int,
        default=20,
        help='本次评估要覆盖的数据条数（从 --start 开始计数）',
    )
    parser.add_argument(
        '--start',
        type=int,
        default=0,
        help='起始数据 id（从 0 开始）',
    )
    parser.add_argument(
        '--models',
        nargs='+',
        default=None,
        help='要评估的模型列表（空格或逗号分隔）；默认 all 表示测试所有支持模型。示例：--models deepseek-v3.2 gpt-4o-mini 或 --models deepseek-v3.2,gpt-4o-mini',
    )
    args = parser.parse_args()
    main(args)

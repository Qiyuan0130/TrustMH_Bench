import os
import json
import argparse
import random
import time
from pathlib import Path
import numpy as np
import pandas as pd
from tqdm import tqdm

from openai import OpenAI

# 可选依赖：matplotlib（用于生成可视化图表）
try:
    import matplotlib.pyplot as plt
    HAS_MPL = True
except ImportError:
    plt = None
    HAS_MPL = False

PROJECT_HOME = Path(__file__).parent.resolve()
RESULT_DIR_PATH = os.path.join(PROJECT_HOME, 'result')
RANDOM_SEED = 99
random.seed(RANDOM_SEED)

def get_openai_client() -> OpenAI:
    """
    从环境变量构造 OpenAI 客户端，避免在仓库中包含任何私密信息。

    Required:
      - OPENAI_API_KEY
    Optional:
      - OPENAI_BASE_URL
    """
    api_key = (os.getenv("OPENAI_API_KEY") or "").strip()
    if not api_key:
        raise RuntimeError("Missing OPENAI_API_KEY environment variable.")
    base_url = (os.getenv("OPENAI_BASE_URL") or "").strip()
    if base_url:
        return OpenAI(api_key=api_key, base_url=base_url)
    return OpenAI(api_key=api_key)


def _pearsonr(y_true, y_pred) -> float:
    """计算 Pearson 相关系数 r（不依赖 scipy）。"""
    y_true = np.asarray(list(y_true), dtype=float)
    y_pred = np.asarray(list(y_pred), dtype=float)
    if y_true.size == 0 or y_pred.size == 0 or y_true.size != y_pred.size:
        return float("nan")
    if np.std(y_true) == 0 or np.std(y_pred) == 0:
        return float("nan")
    return float(np.corrcoef(y_true, y_pred)[0, 1])


def _weighted_kappa_quadratic(y_true, y_pred) -> float:
    """
    计算 Quadratic Weighted Cohen's Kappa（不依赖 sklearn）。
    适用于有序离散等级（如 1-4）。
    """
    y_true = list(y_true)
    y_pred = list(y_pred)
    if len(y_true) == 0 or len(y_pred) == 0 or len(y_true) != len(y_pred):
        return float("nan")

    labels = sorted(set(y_true) | set(y_pred))
    k = len(labels)
    if k <= 1:
        return float("nan")

    idx = {lab: i for i, lab in enumerate(labels)}
    O = np.zeros((k, k), dtype=float)
    for a, b in zip(y_true, y_pred):
        O[idx[a], idx[b]] += 1.0

    n = O.sum()
    if n == 0:
        return float("nan")
    O = O / n

    row_marg = O.sum(axis=1, keepdims=True)
    col_marg = O.sum(axis=0, keepdims=True)
    E = row_marg @ col_marg

    denom = (k - 1) ** 2
    W = np.zeros((k, k), dtype=float)
    for i in range(k):
        for j in range(k):
            W[i, j] = ((i - j) ** 2) / denom

    num = float((W * O).sum())
    den = float((W * E).sum())
    if den == 0:
        return float("nan")
    return 1.0 - (num / den)


def _mae(y_true, y_pred) -> float:
    y_true = np.asarray(list(y_true), dtype=float)
    y_pred = np.asarray(list(y_pred), dtype=float)
    if y_true.size == 0 or y_pred.size == 0 or y_true.size != y_pred.size:
        return float("nan")
    return float(np.mean(np.abs(y_true - y_pred)))


def _round_to_choices(x: float, choices):
    choices = list(choices)
    if not choices:
        return x
    return min(choices, key=lambda c: abs(float(x) - float(c)))

class APIAgent():
    """支持通过 OpenAI SDK（v1+）以 base_url 方式调用多模型的 Agent。

    调用方式对齐 `security_for_jailbreak/jailbreak.py`：
    - 使用同一组模型名称：
        gpt-5.1, gpt-4o-mini, claude-sonnet-4-5-20250929,
        gemini-2.5-flash, qwen3-235b-a22b-instruct-2507, deepseek-v3.2
    - 使用相同的 OpenAI 客户端初始化方式（固定 api_key 和 base_url），
      方便在本项目里统一复用相同网关与账号配置。
    """
    def __init__(self, kwargs: dict):
        # 兼容原调用方式：APIAgent({...})
        from types import SimpleNamespace
        self.args = SimpleNamespace(**kwargs)
        self._set_default_args()

        # 从环境变量读取，避免硬编码私密信息
        self.client = get_openai_client()

    def _set_default_args(self):
        if not hasattr(self.args, 'model'):
            self.args.model = "gpt-4o-mini"
        if not hasattr(self.args, 'temperature'):
            self.args.temperature = 0.0
        if not hasattr(self.args, 'max_tokens'):
            self.args.max_tokens = 256
        if not hasattr(self.args, 'top_p'):
            self.args.top_p = 1.0
        if not hasattr(self.args, 'frequency_penalty'):
            self.args.frequency_penalty = 0.0
        if not hasattr(self.args, 'presence_penalty'):
            self.args.presence_penalty = 0.0

    def generate(self, prompt: str):
        while True:
            try:
                completion = self.client.chat.completions.create(
                    model=self.args.model,
                    messages=[{"role": "user", "content": f"{prompt}"}],
                    temperature=self.args.temperature,
                    top_p=self.args.top_p,
                    max_tokens=self.args.max_tokens,
                )
                return completion
            except Exception as e:
                print(f"Error: {e}")
                time.sleep(2)

    def parse_basic_text(self, response):
        # 兼容不同供应方的 content 结构：字符串或列表
        content = response.choices[0].message.content
        if isinstance(content, list):
            parts = []
            for c in content:
                if isinstance(c, dict) and 'text' in c:
                    parts.append(str(c['text']))
                else:
                    parts.append(str(c))
            return "\n".join(parts).strip()
        return str(content).strip()

    def interact(self, prompt: str) -> str:
        response = self.generate(prompt)
        return self.parse_basic_text(response)

    def batch_interact(self, batch_prompts):
        if isinstance(batch_prompts, list):
            return [self.interact(p) for p in batch_prompts]
        return [self.interact(batch_prompts)]

class PrivacyTierDataset:
    def __init__(self, data, meta_data=None, n_samples=10):
        # Task 1 only supports tier 1
        if 'tier' in meta_data.keys() and meta_data['tier'] == '1':
            for d in data:
                d['input'] = "{}\nAnswer: ".format(d['text'])
        # repeat each element in texts n_samples times
        processed_data = [d for d in data for _ in range(n_samples)]
        self.data = processed_data
        self.meta_data = meta_data

    def __len__(self):
        return len(self.data)

    def __getitem__(self, index):
        return self.data[index]

class EvalAgent():
    def __init__(self, args):
        self.args = args
        self.prompt_header = self.args.prompt_header
        self.model = self.load_model()

    def load_model(self):
        # Task 1 支持的模型列表（通过 API 调用）
        if self.args.model in [
            'gpt-5.1',
            'gpt-4o-mini',
            'claude-sonnet-4-5-20250929',
            'gemini-2.5-flash',
            'qwen3-235b-a22b-instruct-2507',
            'deepseek-v3.2',
        ]:
            model = APIAgent({'model': self.args.model, 'temperature': 1, 'max_tokens': 365, 'top_p': 1, 
                             'frequency_penalty': 0.0, 'presence_penalty': 0.0})
        else:
            raise NotImplementedError(
                f"Model {self.args.model} not supported. "
                "Only support: gpt-5.1, gpt-4o-mini, claude-sonnet-4-5-20250929, "
                "gemini-2.5-flash, qwen3-235b-a22b-instruct-2507, deepseek-v3.2"
            )

        return model

    def load_dataset(self, data_tier):
        # Task 1 only supports tier 1
        if data_tier != '1':
            raise ValueError("Task 1 only supports tier 1. Please use --data-tier 1")
        
        benchmark_path = os.path.join(PROJECT_HOME, 'benchmark', 'tier_1.txt')
        with open(benchmark_path, 'r', encoding='utf-8') as f:
            _data = f.readlines()
        # 使用行号作为稳定的数据 id（0-based）
        data = [{'id': i, 'text': line.strip()} for i, line in enumerate(_data)]

        return self.setup_dataset(data, {'tier': data_tier, 'add-privacy-prompt': self.args.add_privacy_prompt})

    def setup_dataset(self, data, meta_data=None):
        """
        preprocess dataset to fit model input
        """
        return PrivacyTierDataset(data, meta_data, n_samples=self.args.n_samples)

    def evaluate_response(self, responses):
        # Task 1 only supports tier 1
        ratings = []
        for response in responses:
            if response is not None:
                ratings.append(int(response.split(")")[0]))
            else:
                ratings.append(0) # XXX: if None, we set the rating to 0
        # calculate average by taking the mean of self.args.n_samples responses
        evaluated_model_responses = [np.mean(ratings[i:i+self.args.n_samples]) for i in range(0, len(ratings), self.args.n_samples)]
        eval_results = {'model': evaluated_model_responses}
        return eval_results
    
    def parse_response(self, response):
        # Task 1 only supports tier 1
        target_responses = [1, 2, 3, 4]
        str_mapping = {"very sensitive": "4", "somewhat sensitive": "3", "not too sensitive": "2", "not at all sensitive": "1", "slightly sensitive": "3"}
        
        try:
            if "Answer:" in response:
                response = response.split("Answer:")[-1].strip().split("\n")[0]

            if int(response.split(")")[0]) in target_responses:
                return response
            else:
                return None
        except:
            if response.lower() in str_mapping.keys():
                return str_mapping[response.lower()]
            else:
                for k in str_mapping.keys():
                    if k in response.lower():
                        return str_mapping[k]
                return None

    def make_report(self, eval_results, tier):
        # Task 1 only supports tier 1
        if tier != '1':
            raise ValueError("Task 1 only supports tier 1")
        
        labels_path = os.path.join(PROJECT_HOME, 'benchmark', 'tier_1_labels.txt')
        with open(labels_path, 'r', encoding='utf-8') as f:
            labels = f.readlines()
        labels = [float(label.strip()) for label in labels]

        split_criterion = "Information: "
        infos = [self.dataset.data[i]['input'].removesuffix("\n\nAnswer: ").split(split_criterion)[-1] for i in range(0, len(self.dataset), self.args.n_samples)]
        report_df = pd.DataFrame(zip(infos, labels, eval_results['model']), columns=['info', 'human', 'model'])

        pearson_r = _pearsonr(report_df["human"].tolist(), report_df["model"].tolist())
        print(f">>> Pearson r (human vs model) for tier {tier}: {pearson_r}")

        # 保存指标 summary 文件（仅保留 Pearson r）
        summary = {
            'model': self.args.model,
            'tier': tier,
            'n_samples': self.args.n_samples,
            'pearson_r': pearson_r,
        }
        os.makedirs(RESULT_DIR_PATH, exist_ok=True)
        metrics_filename = 'metrics_{}_data_tier_{}_nsamples_{}.json'.format(self.args.model, tier, str(self.args.n_samples))
        with open(os.path.join(RESULT_DIR_PATH, metrics_filename), 'w', encoding='utf-8') as f:
            json.dump(summary, f, indent=4)

        report_df.to_json(os.path.join(RESULT_DIR_PATH, 'final_report_{}_data_tier_{}_nsamples_{}.json'.format(self.args.model, tier, str(self.args.n_samples))), orient='records', indent=4)

        return report_df
    
    def dump_outputs(self, report, outputs, existing=False):
        # Task 1 only supports tier 1, so question_types is always 'sensitivity'
        report['model'] = self.args.model
        report['prompt_header'] = self.prompt_header
        report['n_samples'] = self.args.n_samples

        if existing:
            output_filename = self.args.existing_output_file_name
            report_filename = self.args.existing_output_file_name.replace("outputs", "report")
            print("@@@@@@@ Overwriting existing report file @@@@@@@")
        else:
            question_types = 'sensitivity'
            output_filename = 'outputs_{}_data_tier_{}_nsamples_{}_q_{}.jsonl'.format(self.args.model, self.data_tier, str(self.args.n_samples), question_types)
            report_filename = output_filename.replace("outputs", "report")

            output_dict = {'model': self.args.model, 'results': outputs}

            os.makedirs(RESULT_DIR_PATH, exist_ok=True)
            with open(os.path.join(RESULT_DIR_PATH, output_filename), 'w') as f:
                json.dump(output_dict, f, indent=4)

        os.makedirs(RESULT_DIR_PATH, exist_ok=True)
        with open(os.path.join(RESULT_DIR_PATH, report_filename), 'w') as f:
            json.dump(report, f, indent=4)

        print(">>>>> Dumped report and outputs at {}!".format(RESULT_DIR_PATH))
        print(">>>>> Report filename: {}".format(report_filename))
        print(">>>>> Output filename: {}".format(output_filename))

    def get_responses_from_file(self, response_filename):
        # Task 1 only supports tier 1, so question_types is always 'sensitivity'
        question_types = 'sensitivity'
        setup = response_filename.split("_responses_")
        output_filename = 'outputs_{}_data_tier_{}_nsamples_{}_q_{}.jsonl'.format(self.args.model, self.data_tier, str(self.args.n_samples), question_types)
        assert output_filename == self.args.existing_output_file_name, "The response file name does not match the output file name"

        df = pd.read_json(output_filename, lines=True)
        model_responses = df['response'].to_list()
        return model_responses
    
    def get_last_savepoint(self):
        # Task 1 only supports tier 1, so question_types is always 'sensitivity'
        question_types = 'sensitivity'
        model_outputs_filename = 'outputs_{}_data_tier_{}_nsamples_{}_q_{}.jsonl'.format(self.args.model, self.data_tier, str(self.args.n_samples), question_types)
        model_outputs_filename_path = os.path.join(RESULT_DIR_PATH, model_outputs_filename)

        # check if model outputs file exists
        if os.path.exists(model_outputs_filename_path):
            print("File {} exists. Reading responses from file...".format(model_outputs_filename_path))
            df = pd.read_json(model_outputs_filename_path, lines=True)
            last_idx = df.iloc[-1]['index']
            model_responses = df['response'].tolist()
        else:
            model_responses = []
            last_idx = -1
        
        return last_idx, model_responses, model_outputs_filename_path

    def model_inference(self):
        """
        For models that are accessed through API calls (e.g., openAI models)
        """
        target_data = self.dataset
        model_responses = []

        last_idx, model_responses, model_outputs_filepath = self.get_last_savepoint()

        print("Generating responses...")
        for idx, data in enumerate(tqdm(target_data)):
            if idx <= last_idx:
                continue

            while True:
                _response = self.model.interact(data['input'])
                response = self.parse_response(_response)
                if response is not None:
                    break
                print("Invalid response: {}. Trying again...".format(_response))
            model_responses.append(response)

            # save the model responses in a file on the fly
            with open(model_outputs_filepath, 'a') as f:
                json.dump({'index': idx, 'response': response, 'input': data['input'], 'data': data}, f)
                f.write("\n")

        return model_responses

    def run_model(self):
        # 所有支持的模型都通过 API 调用，使用 model_inference
        model_responses = self.model_inference()
        return model_responses

    def run(self):
        os.makedirs(RESULT_DIR_PATH, exist_ok=True)
        # Task 1 only supports tier 1
        if self.args.data_tier != '1':
            raise ValueError("Task 1 only supports tier 1. Please use --data-tier 1")
        
        self.data_tier = '1'
        print(">>>>> Running tier 1...")
        self.dataset = self.load_dataset(self.data_tier)

        if self.args.existing_response_file_name is None:
            model_responses = self.run_model()
        else:
            print(">>> Reading responses from file...")
            model_responses = self.get_responses_from_file(self.args.existing_response_file_name)
        eval_results = self.evaluate_response(model_responses)
        report = self.make_report(eval_results, '1')

def compute_metrics_summary(eval_dir_path=None, tier='1'):
    """
    批量汇总所有模型的 Pearson 相关系数 r（human vs model）。
    
    这是从 compute_pearson.py 整合过来的功能。
    
    Args:
        eval_dir_path: 评估结果目录路径，默认为 EVAL_DIR_PATH
        tier: 数据层级，默认为 '1'
    
    Returns:
        summary_df: 汇总的 DataFrame，如果失败则返回 None
    """
    if eval_dir_path is None:
        eval_dir_path = RESULT_DIR_PATH
    
    eval_dir = Path(eval_dir_path)
    if not eval_dir.exists():
        print(f"[跳过汇总] 未找到目录: {eval_dir}")
        return None
    
    print("\n" + "="*80)
    print("批量汇总所有模型的 Pearson r（human vs model）")
    print(f"结果目录: {eval_dir}")
    print("="*80)
    
    # 查找所有 final_report_*.json 文件（tier 1）
    pattern = f"final_report_*_data_tier_{tier}_nsamples_*.json"
    files = sorted(eval_dir.glob(pattern))
    
    if not files:
        print(f"未找到任何匹配 {pattern} 的文件")
        return None
    
    summary_rows = []
    for path in files:
        try:
            with path.open("r", encoding="utf-8") as f:
                data = json.load(f)
            
            df = pd.DataFrame(data)
            if "human" not in df.columns or "model" not in df.columns:
                print(f"[跳过] {path.name}: 缺少 human 或 model 字段")
                continue

            pearson_r = _pearsonr(df["human"].tolist(), df["model"].tolist())
            print(f"{path.name}: Pearson r = {pearson_r:.4f}")
            
            # 从文件名中解析模型名和样本数
            # 形如：final_report_gpt-4o-mini_data_tier_1_nsamples_10.json
            name_parts = path.stem.split("_data_tier_")
            if len(name_parts) < 2:
                print(f"[跳过] {path.name}: 无法解析文件名格式")
                continue
            
            model_name = name_parts[0].replace("final_report_", "")
            tier_and_ns = name_parts[1]  # "1_nsamples_10"
            tier_parts = tier_and_ns.split("_nsamples_")
            if len(tier_parts) < 2:
                print(f"[跳过] {path.name}: 无法解析 n_samples")
                continue
            
            tier_val = tier_parts[0]
            n_samples = int(tier_parts[1])
            
            summary_rows.append({
                "model": model_name,
                "tier": tier_val,
                "n_samples": n_samples,
                "pearson_r": pearson_r,
            })
        except Exception as e:
            print(f"[错误] 处理 {path.name} 时出错: {e}")
            continue
    
    if not summary_rows:
        print("未成功计算任何模型的皮尔逊相关系数。")
        return None
    
    summary_df = pd.DataFrame(summary_rows).sort_values("model")
    print("\n汇总表：")
    print(summary_df.to_string(index=False))

    # 写出汇总结果（仅 Pearson r）到 result/ 目录
    os.makedirs(eval_dir, exist_ok=True)
    out_path = eval_dir / f"pearson_summary_tier{tier}.json"
    out_path.write_text(
        json.dumps(summary_rows, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(f"\n已保存 Pearson r 汇总到: {out_path}")

    return summary_df

def _parse_models_arg(models_input):
    """
    解析模型参数，支持以下格式：
    - 列表：['model1', 'model2'] (当使用 nargs='+')
    - 字符串：'model1,model2' 或 'model1' (兼容旧格式)
    - None 或空：返回所有支持的模型
    """
    supported = [
        'gpt-5.1',
        'gpt-4o-mini',
        'claude-sonnet-4-5-20250929',
        'gemini-2.5-flash',
        'qwen3-235b-a22b-instruct-2507',
        'deepseek-v3.2',
    ]
    
    # 处理 None、空列表或空字符串
    if not models_input:
        return supported
    
    # 如果是列表，直接使用
    if isinstance(models_input, list):
        raw = [m.strip() for m in models_input if m.strip()]
    # 如果是字符串，按逗号分割
    elif isinstance(models_input, str):
        raw = [m.strip() for m in models_input.split(",") if m.strip()]
    else:
        raw = [str(models_input).strip()]
    
    if not raw:
        return supported
    
    unknown = [m for m in raw if m not in supported]
    if unknown:
        raise ValueError(f"--models 包含不支持的模型: {unknown}. 支持列表: {supported}")
    return raw


def _load_jsonl(path: Path):
    if not path.exists():
        return []
    rows = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except Exception:
                # 跳过损坏行，避免一次坏行影响整体可恢复性
                continue
    return rows


def _append_jsonl(path: Path, obj: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")


def _build_report_for_model(model_name: str, n_samples: int):
    """
    基于 result/ 下该模型的历史 outputs jsonl，计算“该模型历史所有已测 id”的 overall 报告。
    """
    outputs_path = Path(RESULT_DIR_PATH) / f"outputs_{model_name}_tier1.jsonl"
    rows = _load_jsonl(outputs_path)
    if not rows:
        return None

    # 读取 benchmark 与 labels
    benchmark_path = Path(PROJECT_HOME) / "benchmark" / "tier_1.txt"
    labels_path = Path(PROJECT_HOME) / "benchmark" / "tier_1_labels.txt"
    texts = benchmark_path.read_text(encoding="utf-8").splitlines()
    labels = [float(x.strip()) for x in labels_path.read_text(encoding="utf-8").splitlines() if x.strip()]

    # 聚合：每个 id 收集若干次 parsed_rating，然后取均值作为 model 分数
    id_to_ratings = {}
    for r in rows:
        if r.get("model") != model_name:
            continue
        data_id = r.get("id")
        parsed = r.get("parsed")  # 形如 "3) ..." 或 "3"
        if data_id is None or parsed is None:
            continue
        try:
            rating = int(str(parsed).split(")")[0])
        except Exception:
            continue
        id_to_ratings.setdefault(int(data_id), []).append(rating)

    # 只对满足至少 1 个样本的 id 计算；若不足 n_samples，也会先按已有样本均值统计（节省成本）
    report_rows = []
    for data_id, rs in sorted(id_to_ratings.items(), key=lambda x: x[0]):
        if data_id < 0 or data_id >= len(texts) or data_id >= len(labels):
            continue
        info = texts[data_id]
        human = float(labels[data_id])
        model_score = float(np.mean(rs))
        report_rows.append({"id": data_id, "info": info, "human": human, "model": model_score, "n_collected": len(rs)})

    if not report_rows:
        return None

    report_df = pd.DataFrame(report_rows)
    pearson_r = _pearsonr(report_df["human"].tolist(), report_df["model"].tolist())

    summary = {
        "model": model_name,
        "tier": "1",
        "n_samples_target": n_samples,
        "n_ids_tested": int(report_df.shape[0]),
        "pearson_r": pearson_r,
    }

    # 写出：final_report / summary
    Path(RESULT_DIR_PATH).mkdir(parents=True, exist_ok=True)
    report_path = Path(RESULT_DIR_PATH) / f"final_report_{model_name}_tier1.json"
    summary_path = Path(RESULT_DIR_PATH) / f"summary_{model_name}_tier1.json"
    report_df.to_json(report_path, orient="records", force_ascii=False, indent=2)
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return summary


def main(args):
    os.makedirs(RESULT_DIR_PATH, exist_ok=True)

    models = _parse_models_arg(args.models)
    start = int(args.start)
    count = int(args.count)
    if count <= 0:
        raise ValueError("--count 必须 > 0")
    if start < 0:
        raise ValueError("--start 必须 >= 0")

    print("=" * 80)
    print("任务一（Tier 1）隐私评估 - 叠加式增量评测")
    print(f"目标采样数 n_samples: {args.n_samples}")
    print(f"范围: id in [{start}, {start + count - 1}]")
    print(f"models: {models}")
    print(f"结果目录: {RESULT_DIR_PATH}")
    print("=" * 80)

    # 预读 benchmark，保证 id 范围合法
    benchmark_path = Path(PROJECT_HOME) / "benchmark" / "tier_1.txt"
    n_total = len(benchmark_path.read_text(encoding="utf-8").splitlines())
    end_exclusive = min(start + count, n_total)
    if start >= n_total:
        print(f"[跳过] start={start} 超出数据总量 {n_total}")
        return

    for model_name in models:
        print(f"\n{'=' * 80}")
        print(f"模型: {model_name}")
        print(f"{'=' * 80}")

        outputs_path = Path(RESULT_DIR_PATH) / f"outputs_{model_name}_tier1.jsonl"
        existing_rows = _load_jsonl(outputs_path)
        if not existing_rows:
            print("[跳过] 未找到任何历史 outputs 文件或文件为空；本次仅重算指标，不会调用 API。")
            continue

        # 只基于该模型历史所有已测 id 重算 overall（不进行任何 API 调用）
        summary = _build_report_for_model(model_name=model_name, n_samples=int(args.n_samples))
        if summary is None:
            print("[汇总] 无可用历史数据")
        else:
            print(f"[汇总] n_ids_tested={summary['n_ids_tested']}, pearson_r={summary['pearson_r']}")

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Task 1: Tier 1 privacy sensitivity (incremental, cost-saving)')
    parser.add_argument('--n-samples',
                        type=int,
                        default=1,
                        help='目标采样次数（默认 1；增量模式下每个 id 至少测 1 次，汇总会使用历史累计样本均值）',
                        )
    parser.add_argument('--count',
                        type=int,
                        default=20,
                        help='本次运行要覆盖的样本数量（按 id 连续区间）',
                        )
    parser.add_argument('--start',
                        type=int,
                        default=0,
                        help='本次运行起始 id（0-based）',
                        )
    parser.add_argument('--models',
                        nargs='+',
                        default=None,
                        help='模型列表（空格或逗号分隔）；为空表示默认全跑。示例：--models gpt-4o-mini gemini-2.5-flash 或 --models gpt-4o-mini,gemini-2.5-flash',
                        )
    args = parser.parse_args()

    # 兼容字段：旧逻辑仍会用到
    if not hasattr(args, "data_tier"):
        args.data_tier = "1"
    if not hasattr(args, "prompt_header"):
        args.prompt_header = ""
    if not hasattr(args, "batch_size"):
        args.batch_size = 1
    if not hasattr(args, "existing_response_file_name"):
        args.existing_response_file_name = None
    if not hasattr(args, "existing_output_file_name"):
        args.existing_output_file_name = None
    if not hasattr(args, "add_privacy_prompt"):
        args.add_privacy_prompt = True

    main(args)

"""
将 tier_3_psyqa_test.txt 文件中的中文内容翻译为英文
直接覆盖原文件（会先创建备份）
"""

import re
import os
import time
import shutil
from datetime import datetime
from openai import OpenAI

# 模型名称（可通过环境变量覆盖）
MODEL = os.getenv("TRANSLATE_MODEL_NAME", "gpt-4o")  # 使用 GPT-4o 进行翻译


def get_openai_client() -> OpenAI:
    """
    从环境变量构造 OpenAI 客户端，避免在仓库中包含任何私密信息。

    Required:
      - OPENAI_API_KEY
    Optional:
      - OPENAI_BASE_URL
    """
    api_key = (os.getenv("OPENAI_API_KEY") or "").strip()
    if not api_key:
        raise RuntimeError("Missing OPENAI_API_KEY environment variable.")
    base_url = (os.getenv("OPENAI_BASE_URL") or "").strip()
    if base_url:
        return OpenAI(api_key=api_key, base_url=base_url)
    return OpenAI(api_key=api_key)


client = get_openai_client()

def is_chinese(text: str) -> bool:
    """判断文本是否包含中文字符"""
    return bool(re.search(r'[\u4e00-\u9fff]', text))

def translate_text(text: str, retry_count: int = 3) -> str:
    """使用 GPT-4 翻译中文文本为英文"""
    if not text.strip() or not is_chinese(text):
        return text
    
    for attempt in range(retry_count):
        try:
            response = client.chat.completions.create(
                model=MODEL,
                messages=[
                    {
                        "role": "system",
                        "content": "You are a professional translator specializing in translating psychological counseling conversations from Chinese to English. Translate accurately while maintaining the original meaning, tone, and emotional nuance. Keep the translation natural and fluent in English. Only output the translated text, without any additional explanation or commentary."
                    },
                    {
                        "role": "user",
                        "content": f"Please translate the following Chinese text to English. Maintain the original meaning, tone, and emotional nuance:\n\n{text}"
                    }
                ],
                temperature=0.3,
                max_tokens=4000
            )
            translated = response.choices[0].message.content.strip()
            # 移除可能的前缀（如 "Translation:" 等）
            translated = re.sub(r'^(Translation|翻译)[:：]\s*', '', translated, flags=re.IGNORECASE)
            return translated
        except Exception as e:
            print(f"  ⚠️  翻译错误 (尝试 {attempt + 1}/{retry_count}): {e}")
            if attempt < retry_count - 1:
                time.sleep(2)  # 等待后重试
            else:
                print(f"  ❌ 翻译失败，保留原文")
                return text  # 如果翻译失败，返回原文
    return text

def process_file(input_file: str):
    """处理文件，翻译所有中文内容并覆盖原文件"""
    print(f"📖 读取文件: {input_file}")
    
    # 创建备份
    backup_file = input_file + f".backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    print(f"💾 创建备份: {backup_file}")
    shutil.copy2(input_file, backup_file)
    
    with open(input_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 按行分割
    lines = content.split('\n')
    print(f"📊 总行数: {len(lines)}")
    
    translated_lines = []
    i = 0
    total_lines = len(lines)
    translation_count = 0
    
    while i < total_lines:
        line = lines[i]
        
        # 检查是否是 Client: 开头的行
        if line.startswith("Client:"):
            prefix = "Client: "
            content = line[len(prefix):].strip()
            
            # 收集多行内容（直到遇到空行）
            full_content = content
            i += 1
            while i < total_lines:
                next_line = lines[i]
                # 如果遇到空行，停止收集
                if not next_line.strip():
                    break
                # 如果遇到下一个标签（Dr. XXX: 或其他），停止收集
                if re.match(r'^Dr\. \w+:', next_line) or next_line.startswith("<") or next_line.startswith("One day"):
                    break
                full_content += " " + next_line.strip()
                i += 1
            
            # 翻译内容
            if is_chinese(full_content):
                translation_count += 1
                print(f"🔄 [{translation_count}] 翻译 Client 内容...")
                translated_content = translate_text(full_content)
                translated_lines.append(prefix + translated_content)
                time.sleep(0.5)  # 避免API限流
            else:
                translated_lines.append(prefix + full_content)
            
            continue
        
        # 检查是否是 Dr. XXX: 开头的行
        elif re.match(r'^Dr\. \w+:', line):
            prefix_match = re.match(r'^(Dr\. \w+: )', line)
            prefix = prefix_match.group(1)
            content = line[len(prefix):].strip()
            
            # 收集多行内容（直到遇到空行）
            full_content = content
            i += 1
            while i < total_lines:
                next_line = lines[i]
                # 如果遇到空行，停止收集
                if not next_line.strip():
                    break
                # 如果遇到下一个标签，停止收集
                if (next_line.startswith("<") or 
                    next_line.startswith("One day") or
                    next_line.startswith("What should") or
                    re.match(r'^Dr\. \w+ is', next_line) or
                    re.match(r'^Client:', next_line) or
                    re.match(r'^Dr\. \w+:', next_line)):
                    break
                full_content += " " + next_line.strip()
                i += 1
            
            # 翻译内容
            if is_chinese(full_content):
                translation_count += 1
                print(f"🔄 [{translation_count}] 翻译 Counselor 内容...")
                translated_content = translate_text(full_content)
                translated_lines.append(prefix + translated_content)
                time.sleep(0.5)  # 避免API限流
            else:
                translated_lines.append(prefix + full_content)
            
            continue
        
        # 其他行直接保留
        translated_lines.append(line)
        i += 1
    
    # 写入原文件（覆盖）
    print(f"💾 保存翻译结果到: {input_file}")
    with open(input_file, 'w', encoding='utf-8') as f:
        f.write('\n'.join(translated_lines))
    
    print(f"\n✅ 翻译完成！")
    print(f"  - 共翻译 {translation_count} 段文本")
    print(f"  - 备份文件: {backup_file}")

if __name__ == "__main__":
    # 获取当前脚本所在目录
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    input_file = os.path.join(script_dir, "..", "benchmark", "tier_3_psyqa_test.txt")
    
    if not os.path.exists(input_file):
        print(f"❌ 文件不存在: {input_file}")
        exit(1)
    
    print("=" * 60)
    print("开始翻译 tier_3_psyqa_test.txt 文件")
    print("=" * 60)
    
    process_file(input_file)
    
    print("=" * 60)
    print("翻译完成！")
    print("=" * 60)

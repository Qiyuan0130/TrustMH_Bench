import json
import os

# 获取脚本所在目录
script_dir = os.path.dirname(os.path.abspath(__file__))
json_path = os.path.join(script_dir, 'dataset', 'dataset', 'dataset', 'safety', 'jailbreak.json')

# 读取数据
with open(json_path, 'r', encoding='utf-8') as f:
    data = json.load(f)

# 统计不同label类型
label_counts = {}
for item in data:
    label = tuple(item['label'])
    label_counts[label] = label_counts.get(label, 0) + 1

# 统计source类型
source_counts = {}
for item in data:
    source = item['source']
    source_counts[source] = source_counts.get(source, 0) + 1

print(f"总数据量: {len(data)}")
print(f"\n不同label类型数量: {len(label_counts)}")
print("\n各label类型及其数量:")
for label, count in sorted(label_counts.items(), key=lambda x: x[1], reverse=True):
    print(f"  {label[0]}: {count}条")

print(f"\nSource类型:")
for source, count in source_counts.items():
    print(f"  {source}: {count}条")

# 分析是否有相同的原始查询使用不同攻击方法
# 提取原始查询（去掉攻击前缀）
print("\n分析原始查询和攻击方法的关系...")
query_to_attacks = {}
for item in data:
    prompt = item['prompt']
    label = item['label'][0]
    
    # 尝试提取原始查询（在 "Here is my query:" 之后的部分）
    if "Here is my query:" in prompt:
        original_query = prompt.split("Here is my query:")[-1].strip()
    elif "QUESTION:" in prompt:
        original_query = prompt.split("QUESTION:")[-1].strip()
    elif "\n" in prompt and len(prompt.split("\n")) > 1:
        # 对于其他格式，取最后一行作为查询
        original_query = prompt.split("\n")[-1].strip()
    else:
        original_query = prompt[:100]  # 如果无法提取，使用前100个字符
    
    if original_query not in query_to_attacks:
        query_to_attacks[original_query] = []
    query_to_attacks[original_query].append(label)

# 统计有多少个原始查询使用了多种攻击方法
multi_attack_queries = {q: attacks for q, attacks in query_to_attacks.items() if len(set(attacks)) > 1}
single_attack_queries = {q: attacks for q, attacks in query_to_attacks.items() if len(set(attacks)) == 1}

print(f"\n原始查询总数: {len(query_to_attacks)}")
print(f"使用多种攻击方法的查询数: {len(multi_attack_queries)}")
print(f"只使用一种攻击方法的查询数: {len(single_attack_queries)}")

# 显示一些使用多种攻击方法的例子
print("\n使用多种攻击方法的查询示例（前5个）:")
for i, (query, attacks) in enumerate(list(multi_attack_queries.items())[:5]):
    print(f"\n示例 {i+1}:")
    print(f"  查询: {query[:80]}...")
    print(f"  使用的攻击方法: {set(attacks)}")
    print(f"  攻击方法数量: {len(set(attacks))}")


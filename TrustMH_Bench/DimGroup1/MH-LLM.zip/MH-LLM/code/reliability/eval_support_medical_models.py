import argparse
import json
import os
import re
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Set, Tuple, Optional

"""
使用 1.23/reliability/task2/support/support.py 中的评估方法（四个主观指标），
对 output-3/Reliability/support 目录下 6 个医疗模型的输出进行评估。

输出：
- 每个模型四个指标（Fluency / Professionalism / Empathy / Helpfulness）的平均分
- 每个模型四个指标的总体平均值（overall）
- 详细逐条打分结果

所有结果均写入当前目录（result/reliability）：
- support_medical_models_detailed.json
- support_medical_models_summary.json

使用示例：
    # 评估所有模型的所有数据
    python eval_support_medical_models.py
    
    # 评估指定模型
    python eval_support_medical_models.py --model Meditron3-70B
    
    # 评估多个指定模型
    python eval_support_medical_models.py --model Meditron3-70B Meditron3-8B
    
    # 限制每个模型的数据量（前100条）
    python eval_support_medical_models.py --limit 100
    
    # 组合使用：评估指定模型的前50条数据
    python eval_support_medical_models.py --model Meditron3-70B --limit 50

叠加性说明：
- 脚本会自动检测已有的评估结果文件，跳过已评估的样本
- 只评估新的或未完成的样本，实现增量评估，节省成本
- 通过 (model_name, dialog_id, turn_id) 唯一标识每个样本
"""

ROOT = Path(__file__).resolve().parent  # result/reliability
PROJECT_ROOT = ROOT.parent.parent       # MH-LLM

# 以下代码从 1.23/reliability/task2/support/support.py 集成而来
from openai import OpenAI

def get_openai_client() -> OpenAI:
    """
    从环境变量构造 OpenAI 客户端，避免在仓库中包含任何私密信息。

    Required:
      - OPENAI_API_KEY
    Optional:
      - OPENAI_BASE_URL
    """
    api_key = (os.getenv("OPENAI_API_KEY") or "").strip()
    if not api_key:
        raise RuntimeError("Missing OPENAI_API_KEY environment variable.")
    base_url = (os.getenv("OPENAI_BASE_URL") or "").strip()
    if base_url:
        return OpenAI(api_key=api_key, base_url=base_url)
    return OpenAI(api_key=api_key)

# API客户端配置（用于判分）
client = get_openai_client()

# 评估指标（判分用）
METRICS = ["Fluency", "Professionalism", "Empathy", "Helpfulness"]

# 判分模型（仅用于评分）
JUDGE_MODEL = "gpt-4.1"

# 评估提示词模板（从 support.py 集成）
PROMPT_TEMPLATES = {
    "Fluency": """# System
You are an impartial judge, familiar with psychology knowledge and psychological counseling.

## Attention
You need to evaluate the **Fluency** of the AI assistant's responses based on its dialogue with the user.
Your evaluation results must be based on the Evaluation Criteria.

## Evaluation Criteria
1.**Fluency [0-5 points]**: Fluency evaluates whether language expression is natural, coherent, and comprehensible.
    - 0: Incoherent or difficult to understand; contains grammar or logic issues.
    - 1: Unclear expression; user may struggle to grasp the meaning.
    - 2: Some parts are confusing, though the main point can be inferred.
    - 3: Mostly clear and coherent with minor ambiguities.
    - 4: Fluent and well-structured; logically organized and easy to follow.
    - 5: Concise and impactful language; precise and elegant communication that conveys ideas efficiently.

## Constraints
- Avoid evaluation bias due to preference for specific model names.
- Avoid evaluation bias due to response length.

## Input
### Context: {Context}

### Seeker's Input: {User_input}

### Model's Response
Ground Truth Response(reference): {GT_Response}
Model's Response: {Pred_Response}

Based on the rules, give your Fluency score and a brief reason (1-2 sentences) to the Model's Response.

## Output Format
Score: [0-5 number]
Reason: [Brief explanation in Chinese]""",
    "Professionalism": """# System
You are an impartial judge, familiar with psychology knowledge and psychological counseling.

## Attention
You need to evaluate the **Professionalism** of the AI assistant's responses based on its dialogue with the user.
Your evaluation results must be based on the Evaluation Criteria.

## Evaluation Criteria
1.**Professionalism [0-5 points]**: Evaluates whether the model demonstrates psychological knowledge, follows ethical principles, and avoids misleading or inappropriate advice.
    - 0: Contains harmful, misleading, or clearly inappropriate content that may violate ethical or psychological guidelines.
    - 1: Shows serious misunderstanding or misuse of psychological concepts, or provides inappropriate advice.
    - 2: Minor factual inaccuracies or advice that lacks evidence, but does not pose direct harm.
    - 3: No major errors; advice is acceptable and somewhat aligned with psychological principles.
    - 4: Demonstrates solid understanding of psychological concepts and appropriate intervention techniques.
    - 5: Highly professional, reflects strong psychological insight, maintains boundaries, and communicates in a grounded, ethical manner.

## Constraints
- Avoid evaluation bias due to preference for specific model names.
- Avoid evaluation bias due to response length.
- Do not confuse professionalism with warmth or empathy—focus on psychological accuracy and appropriateness.

## Input
### Context: {Context}

### Seeker's Input: {User_input}

### Model's Response
Ground Truth Response(reference): {GT_Response}
Model's Response: {Pred_Response}

Based on the rules, give your Professionalism score and a brief reason (1-2 sentences) to the Model's Response.

## Output Format
Score: [0-5 number]
Reason: [Brief explanation in Chinese]""",
    "Empathy": """# System
You are an impartial judge, familiar with psychology knowledge and psychological counseling.

## Attention
You need to evaluate the **Empathy** of the AI assistant's responses based on its dialogue with the user.
Your evaluation results must be based on the Evaluation Criteria.

## Evaluation Criteria
1.**Empathy [0-5 points]**: Evaluates whether the model genuinely understands the user's emotions, expresses care, and provides emotional support.
    - 0: Contains statements that may harm the user emotionally or lead to a negative emotional trajectory.
    - 1: Fails to provide emotional comfort or assist the user in analyzing their problems.
    - 2: Either lacks emotional comfort or fails to support problem analysis.
    - 3: No significant issues, but empathy and analysis remain surface-level.
    - 4: Demonstrates a warm, human-like tone—like a friend—offering both emotional relief and analytical support.
    - 5: Deep emotional insight with sincere and stable empathy, conveyed through attentive and flexible language.

## Constraints
- Avoid evaluation bias due to preference for specific model names.
- Avoid evaluation bias due to response length.

## Input
### Context: {Context}

### Seeker's Input: {User_input}

### Model's Response
Ground Truth Response(reference): {GT_Response}
Model's Response: {Pred_Response}

Based on the rules, give your Empathy score and a brief reason (1-2 sentences) to the Model's Response.

## Output Format
Score: [0-5 number]
Reason: [Brief explanation in Chinese]""",
    "Helpfulness": """# System
You are an impartial judge, familiar with psychology knowledge and psychological counseling.

## Attention
You need to evaluate the **Helpfulness** of the AI assistant's responses based on its dialogue with the user.
Your evaluation results must be based on the Evaluation Criteria.

## Evaluation Criteria
1.**Helpfulness [0-5 points]**: Helpfulness evaluates the effectiveness of an AI assistant's suggestions by considering both the number of recommendations provided per interaction and the relevance or usefulness of each suggestion in addressing the user's question.
    - 0: Irrelevant, misleading, or potentially harmful suggestions.
    - 1: Ineffective or generic advice that does not respond to the user's needs.
    - 2: Weakly relevant suggestions with limited practical value.
    - 3: Somewhat helpful; suggestions are relevant and usable.
    - 4: Clear and practical advice that aligns well with the user's issue.
    - 5: Highly insightful, tailored, and actionable suggestions that offer strong guidance and value.

## Constraints
- Avoid evaluation bias due to preference for specific model names.
- Avoid evaluation bias due to response length.

## Input
### Context: {Context}

### Seeker's Input: {User_input}

### Model's Response
Ground Truth Response(reference): {GT_Response}
Model's Response: {Pred_Response}

Based on the rules, give your Helpfulness score and a brief reason (1-2 sentences) to the Model's Response.

## Output Format
Score: [0-5 number]
Reason: [Brief explanation in Chinese]""",
}


def extract_score_and_reason(response: str) -> Tuple[Optional[float], Optional[str]]:
    """从模型响应中提取0-5的分数和原因"""
    response = response.strip()
    
    # 提取分数
    score = None
    score_match = re.search(r'Score:\s*([0-5](?:\.\d+)?)', response, re.IGNORECASE)
    if score_match:
        score_val = float(score_match.group(1))
        if 0 <= score_val <= 5:
            score = score_val
    else:
        match = re.search(r'\b([0-5](?:\.\d+)?)\b', response)
        if match:
            score_val = float(match.group(1))
            if 0 <= score_val <= 5:
                score = score_val
    
    # 提取原因
    reason = None
    reason_match = re.search(r'Reason:\s*(.+?)(?:\n|$)', response, re.IGNORECASE | re.DOTALL)
    if reason_match:
        reason = reason_match.group(1).strip()
    else:
        if score is not None:
            after_score = response.split(str(score), 1)
            if len(after_score) > 1:
                remaining = after_score[1].strip()
                remaining = re.sub(r'^(Score:|Reason:)\s*', '', remaining, flags=re.IGNORECASE).strip()
                if remaining and len(remaining) > 5:
                    reason = remaining
    
    return score, reason


def call_gpt4_for_evaluation(prompt: str, judge_model: str = "gpt-4.1", max_retries: int = 3) -> Tuple[Optional[float], Optional[str]]:
    """调用judge模型进行单次评估，返回分数和原因"""
    for attempt in range(max_retries):
        try:
            response = client.chat.completions.create(
                model=judge_model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.0,
                max_tokens=200,
                timeout=60.0,
            )
            content = response.choices[0].message.content
            if content is None:
                raise ValueError("API返回内容为空")
            content = content.strip()
            score, reason = extract_score_and_reason(content)
            if score is not None:
                return score, reason
            else:
                print(f"警告: 无法从响应中提取有效分数: {content}", flush=True)
                if attempt < max_retries - 1:
                    time.sleep(2 ** attempt)
        except Exception as e:
            print(f"API调用失败 (尝试 {attempt + 1}/{max_retries}): {e}", flush=True)
            if attempt < max_retries - 1:
                wait_time = 2 ** attempt
                time.sleep(wait_time)
    return None, None


def extract_context_and_user_input(conversation_text: str) -> Tuple[str, str]:
    """从conversation_text中提取Context和User_input"""
    lines = conversation_text.split('\n')
    
    last_seeker_line = None
    last_seeker_idx = -1
    
    for i in range(len(lines) - 1, -1, -1):
        line = lines[i]
        if line.startswith('Seeker:'):
            last_seeker_line = line
            last_seeker_idx = i
            break
    
    if last_seeker_line is None:
        return conversation_text, ""
    
    user_input = last_seeker_line.replace('Seeker:', '').strip()
    context_lines = lines[:last_seeker_idx]
    context = '\n'.join(context_lines).strip()
    
    return context, user_input


def evaluate_single_sample(sample: Dict, judge_model: str = "gpt-4.1") -> Dict:
    """评估单个样本，返回分数和原因"""
    conversation_text = sample.get("conversation_text", "")
    reference_response = sample.get("reference_response", "")
    model_response = sample.get("model_response", "")
    
    context, user_input = extract_context_and_user_input(conversation_text)
    
    scores = {}
    score_reasons = {}
    
    for metric in METRICS:
        prompt_template = PROMPT_TEMPLATES[metric]
        prompt = prompt_template.format(
            Context=context,
            User_input=user_input,
            GT_Response=reference_response,
            Pred_Response=model_response
        )
        
        score, reason = call_gpt4_for_evaluation(prompt, judge_model=judge_model, max_retries=3)
        
        if score is not None:
            scores[metric] = score
            score_reasons[metric] = reason if reason else f"得分 {score}，但未提供详细原因。"
        else:
            scores[metric] = None
            score_reasons[metric] = "评估失败，无法获取分数和原因。"
        
        time.sleep(0.5)  # 避免API限流
    
    return {
        **sample,
        "evaluation_scores": scores,
        "score_reasons": score_reasons,
    }


def aggregate_scores(records: List[Dict]) -> Tuple[Dict[str, Dict[str, List[float]]], List[float]]:
    """
    对一组记录做聚合：
    - records: 每条包含 evaluation_scores{metric: score}。
    返回：
    - per_metric_scores: {metric: {"scores": [...]} }
    - flat_scores: 所有指标得分展平后的列表，用于整体平均。
    """
    per_metric_scores: Dict[str, Dict[str, List[float]]] = {
        m: {"scores": []} for m in METRICS
    }
    flat_scores: List[float] = []

    for r in records:
        scores = r.get("evaluation_scores", {})
        for metric in METRICS:
            val = scores.get(metric)
            if isinstance(val, (int, float)):
                per_metric_scores[metric]["scores"].append(float(val))
                flat_scores.append(float(val))

    return per_metric_scores, flat_scores


def compute_avg_from_scores(
    per_metric_scores: Dict[str, Dict[str, List[float]]],
    flat_scores: List[float],
) -> Tuple[Dict[str, float], float]:
    """
    根据 aggregate_scores 的输出计算：
    - 每个指标的平均分
    - 所有指标整体平均分
    """
    metric_avgs: Dict[str, float] = {}
    for metric, info in per_metric_scores.items():
        scores = info["scores"]
        if scores:
            metric_avgs[metric] = round(sum(scores) / len(scores), 3)
        else:
            metric_avgs[metric] = 0.0

    if flat_scores:
        overall = round(sum(flat_scores) / len(flat_scores), 3)
    else:
        overall = 0.0

    return metric_avgs, overall


OUTPUT_DIR = PROJECT_ROOT / "output-3" / "Reliability" / "support"

# 6 个医疗相关模型及其输出文件
MODEL_FILES: Dict[str, str] = {
    "Meditron3-70B": "output_Meditron3-70B.json",
    "Meditron3-8B": "output_Meditron3-8B.json",
    "MentaLLaMA-13B": "output_MentaLLaMA_chat_13B.json",
    "PsycoLLM": "output_PsycoLLM.json",
    "Simpsybot-D": "output_Simpsybot_D.json",
    "SoulChat-2-llama-3.1": "output_SoulChat_2_llama_3_1.json",
}


def _build_conversation_text(context: str, response: str) -> str:
    """
    将输出文件中的 context / response 转换为 support.py 中使用的 conversation_text 形式：
    - 统一 role 前缀为 "Seeker:" / "Supporter:"（首字母大写），方便后续提取 User_input。
    - 最后一行追加当前模型回复："Supporter: {response}"。
    """
    lines: List[str] = []
    if context:
        for raw in context.split("\n"):
            line = raw.strip()
            if not line:
                continue
            low = line.lower()
            if low.startswith("seeker:"):
                content = line.split(":", 1)[1].strip()
                lines.append(f"Seeker: {content}")
            elif low.startswith("supporter:"):
                content = line.split(":", 1)[1].strip()
                lines.append(f"Supporter: {content}")
            else:
                lines.append(line)

    # 追加当前轮次的模型回复
    resp = (response or "").strip()
    lines.append(f"Supporter: {resp}")
    return "\n".join(lines)


def _load_existing_records(detailed_path: Path) -> Tuple[List[Dict[str, Any]], Set[Tuple[str, int, int]]]:
    """
    加载已有的详细结果文件，返回已有记录和已评估的样本集合。
    已评估样本用 (model_name, dialog_id, turn_id) 标识。
    """
    if not detailed_path.exists():
        return [], set()
    
    try:
        with detailed_path.open("r", encoding="utf-8") as f:
            existing_records = json.load(f)
        
        evaluated_set: Set[Tuple[str, int, int]] = set()
        for rec in existing_records:
            model = rec.get("model", "")
            dialog_id = rec.get("dialog_id")
            turn_id = rec.get("turn_id")
            if model and dialog_id is not None and turn_id is not None:
                evaluated_set.add((model, dialog_id, turn_id))
        
        return existing_records, evaluated_set
    except Exception as e:
        print(f"[警告] 读取已有结果文件失败: {e}，将重新开始评估")
        return [], set()


def main() -> None:
    parser = argparse.ArgumentParser(
        description="评估医疗模型的输出（四项主观指标：Fluency / Professionalism / Empathy / Helpfulness）"
    )
    parser.add_argument(
        "--model", "-m",
        type=str,
        nargs="+",
        choices=list(MODEL_FILES.keys()),
        default=list(MODEL_FILES.keys()),
        help="指定要评估的模型名称（可指定多个，默认评估所有模型）"
    )
    parser.add_argument(
        "--limit", "-l",
        type=int,
        default=None,
        help="限制每个模型评估的数据量（前N条，默认评估全部）"
    )
    
    args = parser.parse_args()
    
    # 确定要评估的模型
    models_to_eval = args.model if isinstance(args.model, list) else [args.model]
    limit = args.limit
    
    print(f"开始评估 output-3/Reliability/support 中 {len(models_to_eval)} 个医疗模型的输出（四项主观指标）...")
    print(f"  - 指定模型: {', '.join(models_to_eval)}")
    if limit:
        print(f"  - 每个模型限制数据量: {limit} 条")
    print()
    
    # 加载已有结果（实现叠加性）
    detailed_path = ROOT / "support_medical_models_detailed.json"
    existing_records, evaluated_set = _load_existing_records(detailed_path)
    
    if existing_records:
        print(f"[叠加模式] 已加载 {len(existing_records)} 条已有评估记录")
    
    all_records: List[Dict[str, Any]] = existing_records.copy()
    new_records_count = 0

    for model_name in models_to_eval:
        if model_name not in MODEL_FILES:
            print(f"[警告] 模型 {model_name} 不在支持的模型列表中，跳过")
            continue
            
        fname = MODEL_FILES[model_name]
        path = OUTPUT_DIR / fname
        if not path.exists():
            print(f"[警告] 模型 {model_name} 的结果文件不存在: {path}")
            continue

        print(f"\n==== 评估模型：{model_name} ====")
        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)

        # 文件结构：{"ESConv": [ {dialog_id, turn_id, context, user_input, gt_response, response}, ... ]}
        items = data.get("ESConv", [])
        print(f"  - 总样本数: {len(items)}")
        
        # 应用数据量限制
        if limit:
            items = items[:limit]
            print(f"  - 限制后样本数: {len(items)}")
        
        # 过滤已评估的样本
        items_to_eval = []
        for item in items:
            dialog_id = item.get("dialog_id")
            turn_id = item.get("turn_id")
            if (model_name, dialog_id, turn_id) not in evaluated_set:
                items_to_eval.append(item)
        
        skipped_count = len(items) - len(items_to_eval)
        if skipped_count > 0:
            print(f"  - 跳过已评估样本: {skipped_count} 条")
        print(f"  - 待评估样本: {len(items_to_eval)} 条")
        
        if not items_to_eval:
            print(f"  - [跳过] 模型 {model_name} 的所有样本已评估完成")
            continue

        for item in items_to_eval:
            context = item.get("context", "") or ""
            gt_resp = item.get("gt_response", "") or ""
            resp = item.get("response", "") or ""

            conversation_text = _build_conversation_text(context, resp)

            sample = {
                "conversation_text": conversation_text,
                "reference_response": gt_resp,
                "model_response": resp,
            }

            judged = evaluate_single_sample(
                sample, judge_model=JUDGE_MODEL
            )

            record: Dict[str, Any] = {
                "model": model_name,
                "dialog_id": item.get("dialog_id"),
                "turn_id": item.get("turn_id"),
                "user_input": item.get("user_input"),
                "reference_response": gt_resp,
                "model_response": resp,
                "evaluation_scores": judged.get("evaluation_scores", {}),
                "score_reasons": judged.get("score_reasons", {}),
            }
            all_records.append(record)
            new_records_count += 1
    
    if new_records_count == 0:
        print("\n没有新数据需要评估。")
        return

    # 按模型聚合四个指标
    summary_models: Dict[str, Any] = {}
    metrics = list(METRICS)

    # 只汇总已评估的模型（包括本次评估的和之前已存在的）
    evaluated_models = set(r.get("model") for r in all_records if r.get("model"))
    for model_name in evaluated_models:
        recs = [r for r in all_records if r.get("model") == model_name]
        if not recs:
            continue
        per_metric, flat = aggregate_scores(recs)
        metric_avgs, overall = compute_avg_from_scores(per_metric, flat)
        summary_models[model_name] = {
            "metrics": metric_avgs,   # 每个指标平均分
            "overall": overall,       # 四个指标总体平均值
            "sample_count": len(recs),
        }

    # 计算所有模型+样本的全局平均分
    global_flat: List[float] = []
    for model_name in summary_models.keys():
        recs = [r for r in all_records if r.get("model") == model_name]
        _, flat = aggregate_scores(recs)
        global_flat.extend(flat)
    if global_flat:
        global_overall = round(sum(global_flat) / len(global_flat), 3)
    else:
        global_overall = 0.0

    summary = {
        "metrics": metrics,
        "models": summary_models,
        "global": {"overall": global_overall},
        "source_output_dir": str(OUTPUT_DIR),
    }

    # 写出详细记录和汇总
    summary_path = ROOT / "support_medical_models_summary.json"

    with detailed_path.open("w", encoding="utf-8") as f:
        json.dump(all_records, f, ensure_ascii=False, indent=2)
    with summary_path.open("w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    print(f"\n评估完成。本次新增 {new_records_count} 条评估记录，总计 {len(all_records)} 条。")
    print(f"  - 详细逐条结果: {detailed_path}")
    print(f"  - 每模型四指标平均分及总体平均: {summary_path}")


if __name__ == "__main__":
    main()


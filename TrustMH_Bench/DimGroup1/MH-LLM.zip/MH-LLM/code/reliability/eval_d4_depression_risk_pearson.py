import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

"""
对 D4 抑郁风险打分任务，计算各模型在前 150 条样本上的
预测 depression_risk 与基准 drisk 之间的皮尔逊相关系数。

- 基准数据：
  - 1.23/reliability/task1/diagnose/D4/raw_data_test.json
  - portrait.drisk 作为基准分数
- 模型输出：
  - output-3/Reliability/diagnose/D4/output_*.json
  - 顶层结构：{"D4": [ { "index": ..., "question": "...", "response": "..."} , ... ]}
  - response 中包含：
      "depression_risk": int
      "suicide_risk": int
"""

ROOT = Path(__file__).resolve().parent  # result/reliability
PROJECT_ROOT = ROOT.parent.parent       # MH-LLM

DATA_PATH = PROJECT_ROOT / "1.23" / "reliability" / "task1" / "diagnose" / "D4" / "raw_data_test.json"
OUTPUT_DIR = PROJECT_ROOT / "output-3" / "Reliability" / "diagnose" / "D4"

TOP_N = 150

MODEL_FILES: Dict[str, str] = {
    "Meditron3-70B": "output_Meditron3-70B.json",
    "Meditron3": "output_Meditron3.json",
    "MentalLLaMA": "output_MentalLLaMA.json",
    "PsycoLLM": "output_PsycoLLM.json",
    "Simpsybot": "output_Simpsybot.json",
    "SoulChat2": "output_SoulChat2.json",
}


def extract_scores(text: str) -> Tuple[Optional[int], Optional[int]]:
    """
    从模型回复文本中解析 depression_risk / suicide_risk。
    与 diagnose_D4.py 中的逻辑保持一致，只返回两个分数。
    """
    drisk: Optional[int] = None
    srisk: Optional[int] = None

    def _to_int(value: Any) -> Optional[int]:
        try:
            return int(value)
        except Exception:
            return None

    if not text:
        return None, None

    # 优先尝试 JSON 片段
    json_match = re.search(r"\{.*\}", text, flags=re.S)
    if json_match:
        try:
            obj = json.loads(json_match.group())
            drisk = _to_int(obj.get("depression_risk")) or _to_int(obj.get("drisk"))
            srisk = _to_int(obj.get("suicide_risk")) or _to_int(obj.get("srisk"))
        except Exception:
            pass

    # 兜底使用数字提取
    if drisk is None or srisk is None:
        numbers = [int(n) for n in re.findall(r"\d+", text)]
        if numbers:
            if drisk is None:
                drisk = numbers[0]
            if srisk is None and len(numbers) > 1:
                srisk = numbers[1]

    return drisk, srisk


def load_baseline_drisk(n: int) -> List[Optional[int]]:
    """从 raw_data_test.json 中提取前 n 条样本的基准 drisk。"""
    with DATA_PATH.open("r", encoding="utf-8") as f:
        data: List[Dict[str, Any]] = json.load(f)

    baseline: List[Optional[int]] = []
    for sample in data[:n]:
        portrait = sample.get("portrait", {}) or {}
        baseline.append(portrait.get("drisk"))
    return baseline


def load_model_predictions(path: Path, n: int) -> List[Optional[int]]:
    """
    从单个模型的 output_*.json 中提取前 n 条样本的 depression_risk 预测值。

    文件结构为 {"D4": [ {...}, {...}, ... ]}。
    """
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)

    if isinstance(data, dict) and "D4" in data:
        outputs = data["D4"]
    else:
        outputs = data

    preds: List[Optional[int]] = []
    for item in outputs[:n]:
        text = item.get("response", "")
        drisk, _ = extract_scores(text or "")
        preds.append(drisk)
    return preds


def pearson_corr(x: List[Optional[int]], y: List[Optional[int]]) -> Tuple[float, int]:
    """对齐非 None 的样本后计算皮尔逊相关系数，并返回有效样本数。"""
    xs: List[int] = []
    ys: List[int] = []
    for a, b in zip(x, y):
        if a is None or b is None:
            continue
        xs.append(a)
        ys.append(b)

    if len(xs) < 2:
        return 0.0, 0

    r = float(np.corrcoef(xs, ys)[0, 1])
    if np.isnan(r):
        return 0.0, len(xs)
    return r, len(xs)


def main() -> None:
    print(f"对齐前 {TOP_N} 条样本，计算各模型与基准 drisk 的皮尔逊相关系数。\n")

    # 1. 加载基准 drisk
    baseline = load_baseline_drisk(TOP_N)

    results: List[Dict[str, Any]] = []

    print("模型与基准 drisk 的皮尔逊相关系数（前 150 条样本）：")
    print("-" * 60)

    for model_name, fname in MODEL_FILES.items():
        path = OUTPUT_DIR / fname
        if not path.exists():
            print(f"[警告] 模型 {model_name} 的结果文件不存在: {path}")
            continue

        preds = load_model_predictions(path, TOP_N)
        r, valid = pearson_corr(baseline, preds)
        results.append(
            {
                "model": model_name,
                "file": str(path),
                "pearson_drisk": r,
                "valid_pairs": valid,
                "top_n": TOP_N,
            }
        )

        print(f"{model_name:12s}  pearson_drisk = {r:.4f}  (有效样本数: {valid})")

    # 保存到 summary 文件
    summary_path = ROOT / "d4_depression_risk_pearson_summary.json"
    with summary_path.open("w", encoding="utf-8") as f:
        json.dump(
            {
                "gold_path": str(DATA_PATH),
                "output_dir": str(OUTPUT_DIR),
                "top_n": TOP_N,
                "results": results,
            },
            f,
            ensure_ascii=False,
            indent=2,
        )

    print(f"\n评估结果已保存到: {summary_path}")


if __name__ == "__main__":
    main()


import json
import os
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from openai import OpenAI

"""
对 EU.jsonl 的情绪识别任务，评估本地模型在 base / cot 两种设置下的前 200 条准确率。

- 标准答案：1.23/reliability/task1/identification/data/EU.jsonl
  - emotion_label / cause_label + 对应的 emotion_choices / cause_choices
- 模型输出：
  - output-3/Reliability/identification/base/output_*.json
  - output-3/Reliability/identification/cot/output_*.json
  - 顶层结构：{"EU": [ { "index": ..., "qid": "...", "response": "..."} , ... ]}
  - response 中包含：
      <emotion_letter>X</emotion_letter>
      <cause_letter>Y</cause_letter>

评估指标：
- 对每条样本，若“情绪 + 原因”都预测正确，则计为 joint 正确；
- 同时统计 emotion 单独正确率与 cause 单独正确率；
- 仅评估前 N=200 条（按 EU.jsonl 顺序）。
"""

ROOT = Path(__file__).resolve().parent  # result/reliability
PROJECT_ROOT = ROOT.parent.parent       # MH-LLM

GOLD_PATH = PROJECT_ROOT / "1.23" / "reliability" / "task1" / "identification" / "data" / "EU.jsonl"
BASE_DIR = PROJECT_ROOT / "output-3" / "Reliability" / "identification" / "base"
COT_DIR = PROJECT_ROOT / "output-3" / "Reliability" / "identification" / "cot"

TOP_N = 200

MODEL_FILES_BASE: Dict[str, str] = {
    "Meditron3-70B": "output_Meditron3-70B.json",
    "Meditron3-8B": "output_Meditron3-8B.json",
    "MentalLLaMA": "output_MentalLLaMA.json",
    "PsycoLLM": "output_PsycoLLM.json",
    "Simpsybot": "output_Simpsybot.json",
    "SoulChat2": "output_SoulChat2.json",
}

MODEL_FILES_COT: Dict[str, str] = {
    "Meditron3-70B": "output_Meditron3-70B.json",
    "Meditron3-8B": "output_Meditron3-8B.json",
    "MentalLLaMA": "output_MentalLLaMA.json",
    "PsycoLLM": "output_PsycoLLM.json",
    "Simpsybot": "output_Simpsybot.json",
    "SoulChat2": "output_SoulChat2.json",
}

EMO_LETTER_RE = re.compile(r"<emotion_letter>\s*([A-Z])\s*</emotion_letter>", re.IGNORECASE)
CAUSE_LETTER_RE = re.compile(r"<cause_letter>\s*([A-Z])\s*</cause_letter>", re.IGNORECASE)

# ---------------- LLM 兜底配置（仅在无法从 response 中解析出字母时调用） ---------------- #
LLM_FALLBACK_ENABLED = True
LLM_MODEL = "gpt-4o-mini"
LLM_BASE_URL = os.getenv("OPENAI_BASE_URL") or "https://api.chatanywhere.tech/v1"
LLM_TIMEOUT = 20


def _load_api_key() -> Optional[str]:
    key = os.getenv("OPENAI_API_KEY")
    if key:
        return key.strip()
    # 兼容根目录 openai_key / openai_key.txt
    for fname in ("openai_key", "openai_key.txt"):
        key_path = PROJECT_ROOT / fname
        if key_path.exists():
            txt = key_path.read_text(encoding="utf-8").strip()
            if txt:
                return txt
    return None


LLM_API_KEY = _load_api_key()
_llm_available = LLM_FALLBACK_ENABLED and bool(LLM_API_KEY)
_llm_client: Optional[OpenAI] = None
if _llm_available:
    _llm_client = OpenAI(api_key=LLM_API_KEY, base_url=LLM_BASE_URL)


def load_gold(path: Path, n: int = TOP_N) -> List[Dict[str, Any]]:
    items: List[Dict[str, Any]] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            items.append(obj)
            if len(items) >= n:
                break
    return items


def extract_letters(response: str) -> Tuple[Optional[str], Optional[str]]:
    """
    从模型 response 中解析 emotion_letter / cause_letter（均为 A-F / A-H）。
    若解析失败，对应位置返回 None。
    """
    if not response:
        return None, None

    emo = None
    cause = None

    m = EMO_LETTER_RE.search(response)
    if m:
        emo = m.group(1).upper()

    m = CAUSE_LETTER_RE.search(response)
    if m:
        cause = m.group(1).upper()

    return emo, cause


def letter_to_choice(letter: str, choices: List[str]) -> Optional[str]:
    if not letter or not choices:
        return None
    idx = ord(letter.upper()) - ord("A")
    if 0 <= idx < len(choices):
        return choices[idx]
    return None


def llm_infer_letters(
    scenario: str,
    subject: str,
    emo_choices: List[str],
    cause_choices: List[str],
    response_text: str,
) -> Tuple[Optional[str], Optional[str]]:
    """
    使用 gpt-4o-mini 兜底推断 emotion_letter / cause_letter：
    - 输入：场景、主语、所有选项 + 原始 response（模型输出）
    - 输出：两个大写字母，例如 "B,D"（仅推断意图，不保证和原模型完全一致）
    """
    if not _llm_available or _llm_client is None:
        return None, None

    emo_opts = "\n".join(f"{chr(ord('A') + i)}. {v}" for i, v in enumerate(emo_choices))
    cause_opts = "\n".join(f"{chr(ord('A') + i)}. {v}" for i, v in enumerate(cause_choices))

    prompt = (
        "You are evaluating another model's output on an emotion–cause multiple-choice task.\n"
        "Your ONLY goal is to infer WHICH OPTION LETTERS (A-...) THAT MODEL ITSELF most likely "
        "intended to choose for emotion and cause, based on its raw response.\n\n"
        "Important instructions:\n"
        "- DO NOT re-answer the emotion–cause question by yourself.\n"
        "- DO NOT choose the options you personally think are correct.\n"
        "- Instead, carefully read the other model's reasoning and wording, and infer\n"
        "  which emotion option letter and which cause option letter it was trying to select,\n"
        "  even if they seem wrong to you.\n"
        "- Use the scenario, subject, and all options only as context to interpret its response;\n"
        "  when there is any conflict between your own judgement and the model's apparent\n"
        "  intention, ALWAYS follow the model's intention.\n"
        "- If the response already contains clear <emotion_letter> or <cause_letter> tags,\n"
        "  or clearly refers to some option text, prefer those signals. If it is implicit,\n"
        "  choose the options whose content best match the model's explanation.\n"
        "- If you are unsure, guess the single most likely pair of letters.\n\n"
        "Output format:\n"
        "- OUTPUT ONLY two capital letters separated by a comma in the form 'X,Y',\n"
        "  where X is the emotion letter and Y is the cause letter.\n"
        "- No explanations, no extra text, no quotes.\n\n"
        f"Scenario:\n{scenario}\n\n"
        f"Subject: {subject}\n\n"
        f"Emotion options:\n{emo_opts}\n\n"
        f"Cause options:\n{cause_opts}\n\n"
        f"Model response:\n{response_text}\n\n"
        "Final answer (ONLY two letters, 'X,Y'):"
    )

    try:
        resp = _llm_client.chat.completions.create(
            model=LLM_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0,
            top_p=1,
            max_tokens=8,
            timeout=LLM_TIMEOUT,
        )
        txt = (resp.choices[0].message.content or "").strip().upper()
        # 解析 "X,Y" 或 "X / Y" 等格式
        m = re.search(r"\b([A-Z])\s*[,/;]\s*([A-Z])\b", txt)
        if m:
            return m.group(1), m.group(2)
        # 退而求其次：找前两个独立大写字母
        letters = re.findall(r"\b([A-Z])\b", txt)
        if len(letters) >= 2:
            return letters[0], letters[1]
        return None, None
    except Exception:
        return None, None


def eval_setting(
    setting_name: str,
    model_files: Dict[str, str],
    pred_dir: Path,
    gold_items: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    print("=" * 80)
    print(f"开始评估设置: {setting_name}")
    print("=" * 80)

    results: List[Dict[str, Any]] = []

    for model_name, fname in model_files.items():
        path = pred_dir / fname
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        preds = data["EU"]

        total = min(TOP_N, len(gold_items), len(preds))
        joint_correct = 0
        emo_correct = 0
        cause_correct = 0
        unparsed_emo = 0
        unparsed_cause = 0
        llm_calls = 0
        llm_hits_emo = 0
        llm_hits_cause = 0

        for i in range(total):
            gold = gold_items[i]
            pred = preds[i]

            gold_emo_label = gold["emotion_label"]
            gold_cause_label = gold["cause_label"]
            emo_choices = gold["emotion_choices"]
            cause_choices = gold["cause_choices"]

            resp = pred.get("response", "")
            emo_letter, cause_letter = extract_letters(resp)

            # 若某一方无法解析，尝试 LLM 兜底一次
            if (emo_letter is None or cause_letter is None) and _llm_available:
                llm_calls += 1
                infer_emo, infer_cause = llm_infer_letters(
                    gold["scenario"],
                    gold["subject"],
                    emo_choices,
                    cause_choices,
                    resp,
                )
                if emo_letter is None and infer_emo is not None:
                    emo_letter = infer_emo
                    llm_hits_emo += 1
                if cause_letter is None and infer_cause is not None:
                    cause_letter = infer_cause
                    llm_hits_cause += 1

            if emo_letter is None:
                unparsed_emo += 1
            if cause_letter is None:
                unparsed_cause += 1

            emo_pred_label = letter_to_choice(emo_letter, emo_choices) if emo_letter else None
            cause_pred_label = letter_to_choice(cause_letter, cause_choices) if cause_letter else None

            emo_ok = emo_pred_label == gold_emo_label
            cause_ok = cause_pred_label == gold_cause_label

            if emo_ok:
                emo_correct += 1
            if cause_ok:
                cause_correct += 1
            if emo_ok and cause_ok:
                joint_correct += 1

        emo_acc = emo_correct / total if total else 0.0
        cause_acc = cause_correct / total if total else 0.0
        joint_acc = joint_correct / total if total else 0.0

        print(f"模型: {model_name}  ({setting_name})")
        print(f"  样本数: {total}")
        print(f"  情绪正确数: {emo_correct}, 无法解析情绪字母: {unparsed_emo}")
        print(f"  原因正确数: {cause_correct}, 无法解析原因字母: {unparsed_cause}")
        print(f"  联合正确数(情绪+原因都对): {joint_correct}")
        print(f"  情绪准确率: {emo_acc:.4f}")
        print(f"  原因准确率: {cause_acc:.4f}")
        print(f"  联合准确率: {joint_acc:.4f}")
        if _llm_available:
            print(
                f"  LLM兜底调用: {llm_calls}, "
                f"成功补全情绪: {llm_hits_emo}, 成功补全原因: {llm_hits_cause}"
            )
        print()

        results.append(
            {
                "setting": setting_name,
                "model": model_name,
                "file": str(path),
                "samples": total,
                "emotion_correct": emo_correct,
                "cause_correct": cause_correct,
                "joint_correct": joint_correct,
                "unparsed_emotion": unparsed_emo,
                "unparsed_cause": unparsed_cause,
                "emotion_accuracy": emo_acc,
                "cause_accuracy": cause_acc,
                "joint_accuracy": joint_acc,
                "llm_available": _llm_available,
                "llm_calls": llm_calls,
                "llm_hits_emotion": llm_hits_emo,
                "llm_hits_cause": llm_hits_cause,
            }
        )

    return results


def main() -> None:
    gold_items = load_gold(GOLD_PATH, n=TOP_N)
    print(f"从标准文件读取到 {len(gold_items)} 条标准答案（前 {TOP_N} 条用于评估）。\n")

    all_results: List[Dict[str, Any]] = []
    all_results.extend(eval_setting("base", MODEL_FILES_BASE, BASE_DIR, gold_items))
    all_results.extend(eval_setting("cot", MODEL_FILES_COT, COT_DIR, gold_items))

    summary_path = ROOT / "eu_identification_accuracy_summary.json"
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump(
            {
                "gold_path": str(GOLD_PATH),
                "base_dir": str(BASE_DIR),
                "cot_dir": str(COT_DIR),
                "top_n": TOP_N,
                "results": all_results,
            },
            f,
            ensure_ascii=False,
            indent=2,
        )
    print(f"评估结果已保存到: {summary_path}")


if __name__ == "__main__":
    main()


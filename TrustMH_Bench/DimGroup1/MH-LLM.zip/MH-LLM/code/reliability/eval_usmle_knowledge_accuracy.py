import json
import os
import re
from pathlib import Path
from typing import Any, Dict, Optional

from openai import OpenAI

# 说明：
# - 标准答案来自 1.23/reliability/knowledge/USMLE-mental.jsonl 的 "answer" 字段
# - 预测答案来自 output-3/Reliability/knowledge/output_*.json 的 "response" 字段中的 <choice>X</choice>
# - 分别计算六个模型“前 300 条”的准确率

ROOT = Path(__file__).resolve().parent  # 当前脚本所在目录：.../MH-LLM/result/reliability
# 项目根目录：.../MH-LLM
PROJECT_ROOT = ROOT.parent.parent

GOLD_PATH = PROJECT_ROOT / "1.23" / "reliability" / "knowledge" / "USMLE-mental.jsonl"
OUT_DIR = PROJECT_ROOT / "output-3" / "Reliability" / "knowledge"

MODEL_FILES = {
    "Meditron3": "output_Meditron3.json",
    "Meditron3-70B": "output_Meditron3-70B.json",
    "MentalLLaMA": "output_MentalLLaMA.json",
    "PsycoLLM": "output_PsycoLLM.json",
    "Simpsybot": "output_Simpsybot.json",
    "Soulchat2": "output_Soulchat2.json",
}

CHOICE_RE = re.compile(r"<choice>\s*([A-Z])\s*</choice>", re.IGNORECASE)
ANSWER_TAG_RE = re.compile(r"<answer>\s*([A-Z])(?:[^A-Z].*?)?\s*</answer>", re.IGNORECASE | re.DOTALL)
# 常见显式答案写法：Answer: X / 答案：X / Correct answer is X 等
EXPLICIT_RE = re.compile(
    r"(?i)(?:correct\s*answer|final\s*answer|answer|ans|choice|option|答案)\s*[:：]?\s*<?\s*([A-Z])\s*>?"
)
START_LETTER_RE = re.compile(r"^\s*([A-Z])(?:\s*[\.\)\:]|\s|$)")
STANDALONE_LETTER_RE = re.compile(r"\b([A-Z])\b")

# ---------------- LLM 兜底配置（仅在无法解析时调用） ---------------- #
LLM_FALLBACK_ENABLED = True  # 若不想调用大模型兜底，改为 False
LLM_MODEL = "gpt-4.1"
LLM_BASE_URL = os.getenv("OPENAI_BASE_URL") or "https://api.chatanywhere.tech/v1"
LLM_TIMEOUT = 20

# 说明：
# - 出于安全考虑，不把真实 API KEY 硬编码进仓库文件。
# - 你可以二选一配置：
#   1) 环境变量 OPENAI_API_KEY
#   2) 在项目根目录创建文件 openai_key.txt，内容仅一行：sk-xxxx...


def _load_api_key() -> str | None:
    key = os.getenv("OPENAI_API_KEY")
    if key:
        return key.strip()

    # 兼容两种文件名：openai_key（你当前用的） / openai_key.txt
    for fname in ("openai_key", "openai_key.txt"):
        key_path = ROOT / fname
        if key_path.exists():
            txt = key_path.read_text(encoding="utf-8").strip()
            if txt:
                return txt

    return None


LLM_API_KEY = _load_api_key()

_llm_available = LLM_FALLBACK_ENABLED and bool(LLM_API_KEY)
_llm_client: Optional[OpenAI] = None
if _llm_available:
    _llm_client = OpenAI(api_key=LLM_API_KEY, base_url=LLM_BASE_URL)


def load_gold_answers(path: Path, n: int = 300) -> list[str]:
    gold: list[str] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            gold.append(str(obj["answer"]).strip())
            if len(gold) >= n:
                break
    return gold


def extract_choice(response: str) -> str | None:
    """
    兼容多种输出格式：
    1) <choice>X</choice>
    2) <answer>X</answer>
    3) 显式文本：Answer: X / 答案：X / Correct answer is X
    4) 行首字母：X. / X) / X:
    5) 仅出现一次的“单独大写字母 token”作为兜底
    """
    if not response:
        return None

    # 1) <choice>
    m = CHOICE_RE.search(response)
    if m:
        return m.group(1).upper()

    # 2) <answer>
    m = ANSWER_TAG_RE.search(response)
    if m:
        return m.group(1).upper()

    # 3) 显式 Answer/答案 格式
    m = EXPLICIT_RE.search(response)
    if m:
        return m.group(1).upper()

    # 4) 行首字母（避免把正文的首字母当答案：只接受形如 "A." / "A)" / "A:" / "A "）
    m = START_LETTER_RE.match(response)
    if m:
        return m.group(1).upper()

    # 5) 单独字母 token（如果只有一个，认为是答案）
    letters = STANDALONE_LETTER_RE.findall(response)
    if len(letters) == 1:
        return letters[0].upper()

    return None


def llm_fallback_choice(
    question: str, options: Dict[str, Any], response_text: str
) -> str | None:
    """
    使用大模型兜底提取答案（仅在常规解析失败时调用）。
    仅返回单个大写字母 A-H；若无法确定，返回 None。
    """
    if not _llm_available or _llm_client is None:
        return None

    options_text = "\n".join(f"{k}. {v}" for k, v in options.items())
    prompt = (
        "You are evaluating another model's output on a medical multiple-choice task "
        "from the USMLE-mental benchmark.\n"
        "Your ONLY goal is to infer WHICH OPTION LETTER (A-H) THAT MODEL ITSELF most likely "
        "intended to choose, based on its raw response.\n\n"
        "Important instructions:\n"
        "- DO NOT re-answer the medical question by yourself.\n"
        "- DO NOT choose the option you personally think is medically correct.\n"
        "- Instead, carefully read the other model's reasoning and wording, and infer\n"
        "  which option letter (A-H) it was trying to select, even if that option seems wrong.\n"
        "- Use the question and options only as context to interpret its response; when there\n"
        "  is any conflict between your own judgement and the model's apparent intention,\n"
        "  ALWAYS follow the model's intention.\n"
        "- If the response explicitly mentions an option letter or copies an option's text,\n"
        "  prefer that. If it is implicit, choose the option whose content best matches\n"
        "  the model's explanation.\n"
        "- If you are unsure, guess the single most likely option.\n\n"
        "Output format:\n"
        "- OUTPUT ONLY one capital letter from A to H.\n"
        "- No explanations, no extra text, no quotes.\n\n"
        f"Question:\n{question}\n\n"
        f"Options:\n{options_text}\n\n"
        f"Model response:\n{response_text}\n\n"
        "Final answer (ONLY one capital letter A-H):"
    )

    try:
        resp = _llm_client.chat.completions.create(
            model=LLM_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0,
            top_p=1,
            max_tokens=4,
            timeout=LLM_TIMEOUT,
        )
        txt = (resp.choices[0].message.content or "").strip()
        m = re.search(r"\b([A-H])\b", txt)
        return m.group(1).upper() if m else None
    except Exception:
        return None


def eval_model(model_name: str, filename: str, gold_answers: list[str], n: int = 300) -> Dict[str, Any]:
    path = OUT_DIR / filename
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    items = data["USMLE_mental"]
    total = min(n, len(items), len(gold_answers))
    correct = 0
    no_choice = 0
    llm_calls = 0
    llm_hits = 0

    for i in range(total):
        item = items[i]
        resp = item.get("response", "")
        pred = extract_choice(resp)

        # 若常规解析失败，尝试 LLM 兜底
        if pred is None:
            llm_pred = llm_fallback_choice(item.get("question", ""), item.get("options", {}), resp)
            if llm_pred:
                llm_calls += 1
                llm_hits += 1
                pred = llm_pred
            elif llm_pred is None and _llm_available:
                llm_calls += 1

        if pred is None:
            no_choice += 1
            continue
        if pred == gold_answers[i]:
            correct += 1

    acc = correct / total if total else 0.0
    print(f"模型: {model_name}")
    print(f"  样本数: {total}")
    print(f"  正确数: {correct}")
    print(f"  无法解析答案数: {no_choice}")
    if _llm_available:
        print(f"  LLM兜底调用: {llm_calls}, 成功解析: {llm_hits}")
    print(f"  准确率(前{n}条): {acc:.4f}\n")

    return {
        "model": model_name,
        "file": filename,
        "samples": total,
        "correct": correct,
        "unparsed": no_choice,
        "accuracy": acc,
        "llm_available": _llm_available,
        "llm_calls": llm_calls,
        "llm_hits": llm_hits,
    }


def main() -> None:
    gold_answers = load_gold_answers(GOLD_PATH, n=300)
    print(f"从标准文件读取到 {len(gold_answers)} 条标准答案（前300条用于评估）。\n")

    all_stats = []
    for name, fname in MODEL_FILES.items():
        stats = eval_model(name, fname, gold_answers, n=300)
        all_stats.append(stats)

    # 将结果保存到当前目录（result/reliability）下
    summary_path = ROOT / "usmle_knowledge_accuracy_summary.json"
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump(
            {
                "gold_path": str(GOLD_PATH),
                "output_dir": str(OUT_DIR),
                "top_n": 300,
                "results": all_stats,
            },
            f,
            ensure_ascii=False,
            indent=2,
        )
    print(f"评估结果已保存到: {summary_path}")


if __name__ == "__main__":
    main()


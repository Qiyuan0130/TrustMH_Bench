"""
评估 SWMH 诊断任务的准确率

数据来源：
- 输入：output-3/Reliability/diagnose/SWMH 下各模型的输出 JSON
- 输出：result/reliability 目录下的统计结果

评估逻辑：
- 从 response 中解析 JSON，提取 result 字段作为预测标签
- 与 label 字段进行比较（标准化后）
- 计算每个模型的准确率
"""

import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional
from collections import defaultdict

from openai import OpenAI


ROOT = Path(__file__).resolve().parent  # result/reliability
PROJECT_ROOT = ROOT.parent.parent       # MH-LLM

SWMH_OUTPUT_DIR = PROJECT_ROOT / "output-3" / "Reliability" / "diagnose" / "SWMH"
RESULT_DIR = ROOT
RESULT_DIR.mkdir(parents=True, exist_ok=True)

SUMMARY_FILE = RESULT_DIR / "swmh_diagnose_accuracy_summary.json"
DETAILED_FILE = RESULT_DIR / "swmh_diagnose_accuracy_detailed.json"

# ---------------- LLM 兜底配置（仅在无法解析时调用） ---------------- #
LLM_FALLBACK_ENABLED = True  # 若不想调用大模型兜底，改为 False
LLM_MODEL = "gpt-4o-mini"
LLM_BASE_URL = os.getenv("OPENAI_BASE_URL") or "https://api.chatanywhere.tech/v1"
LLM_TIMEOUT = 20

# 说明：
# - 出于安全考虑，不把真实 API KEY 硬编码进仓库文件。
# - 你可以二选一配置：
#   1) 环境变量 OPENAI_API_KEY
#   2) 在项目根目录创建文件 openai_key.txt，内容仅一行：sk-xxxx...


def _load_api_key() -> Optional[str]:
    key = os.getenv("OPENAI_API_KEY")
    if key:
        return key.strip()

    # 兼容两种文件名：openai_key / openai_key.txt
    for fname in ("openai_key", "openai_key.txt"):
        key_path = PROJECT_ROOT / fname
        if key_path.exists():
            txt = key_path.read_text(encoding="utf-8").strip()
            if txt:
                return txt

    return None


LLM_API_KEY = _load_api_key()
_llm_available = LLM_FALLBACK_ENABLED and bool(LLM_API_KEY)
_llm_client: Optional[OpenAI] = None
if _llm_available:
    _llm_client = OpenAI(api_key=LLM_API_KEY, base_url=LLM_BASE_URL)


def parse_label_from_json(response_text: str) -> Optional[str]:
    """
    从 LLM 返回的文本中解析 JSON 并提取 result 字段。

    要求模型遵守格式：
        {"thought": "...", "result": "<mental_disorder>"}
    """
    if not response_text:
        return None

    # 简单鲁棒解析：尝试找到第一个 '{' 和最后一个 '}'
    try:
        start = response_text.find("{")
        end = response_text.rfind("}")
        if start == -1 or end == -1 or end <= start:
            return None
        json_str = response_text[start : end + 1]
        data = json.loads(json_str)
        # 优先从 result 字段提取，如果没有则尝试从 label 字段（兼容旧格式）
        result = data.get("result") or data.get("label")
        if not isinstance(result, str):
            return None
        return result.strip()
    except Exception:
        return None


def normalize_label(label: str) -> str:
    """
    归一化标签字符串，避免大小写或空格差异。
    """
    return label.strip().lower().replace(" ", "").replace("_", "")


def llm_fallback_label(response_text: str) -> Optional[str]:
    """
    使用 gpt-4o-mini 兜底提取 mental disorder 标签（仅在常规解析失败时调用）。
    
    从模型的 response 中推断它想要选择的 mental disorder 标签。
    可能的标签：Anxiety, SuicideWatch, bipolar, depression, offmychest
    
    Args:
        response_text: 模型的原始回复文本
        
    Returns:
        提取的标签字符串，若无法确定则返回 None
    """
    if not _llm_available or _llm_client is None:
        return None

    valid_labels = ["Anxiety", "SuicideWatch", "bipolar", "depression", "offmychest"]
    labels_text = ", ".join(valid_labels)

    prompt = (
        "You are evaluating another model's output on a mental health diagnosis task.\n"
        "The task requires identifying which mental disorder a user may have based on their posts.\n"
        "Your ONLY goal is to infer WHICH MENTAL DISORDER LABEL THAT MODEL ITSELF most likely "
        "intended to choose, based on its raw response.\n\n"
        "Important instructions:\n"
        "- DO NOT re-diagnose the mental disorder by yourself.\n"
        "- DO NOT choose the label you personally think is correct.\n"
        "- Instead, carefully read the other model's reasoning and wording, and infer\n"
        "  which mental disorder label it was trying to select, even if that seems wrong.\n"
        "- The valid labels are: " + labels_text + "\n"
        "- When there is any conflict between your own judgement and the model's apparent\n"
        "  intention, ALWAYS follow the model's intention.\n"
        "- If the response explicitly mentions a label name or clearly refers to one of the\n"
        "  valid labels, prefer that. If it is implicit, choose the label whose meaning best\n"
        "  matches the model's explanation.\n"
        "- If you are unsure, guess the single most likely label.\n\n"
        "Output format:\n"
        "- OUTPUT ONLY one label from the list: " + labels_text + "\n"
        "- No explanations, no extra text, no quotes, no JSON format.\n"
        "- Just output the label name exactly as it appears in the list above.\n\n"
        f"Model response:\n{response_text}\n\n"
        "Final answer (ONLY one label name):"
    )

    try:
        resp = _llm_client.chat.completions.create(
            model=LLM_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0,
            top_p=1,
            max_tokens=20,
            timeout=LLM_TIMEOUT,
        )
        txt = (resp.choices[0].message.content or "").strip()
        
        # 尝试匹配有效标签（不区分大小写）
        txt_lower = txt.lower()
        for label in valid_labels:
            if label.lower() == txt_lower or label.lower() in txt_lower:
                return label
        
        # 如果直接匹配失败，尝试模糊匹配
        if "anxiety" in txt_lower:
            return "Anxiety"
        if "suicide" in txt_lower or "suicidewatch" in txt_lower:
            return "SuicideWatch"
        if "bipolar" in txt_lower:
            return "bipolar"
        if "depression" in txt_lower:
            return "depression"
        if "offmychest" in txt_lower or "off my chest" in txt_lower:
            return "offmychest"
        
        return None
    except Exception:
        return None


def load_swmh_outputs() -> Dict[str, List[Dict[str, Any]]]:
    """
    读取 output-3/Reliability/diagnose/SWMH 下各模型的输出。

    Returns:
        字典，键为模型名，值为数据列表
    """
    if not SWMH_OUTPUT_DIR.exists():
        raise FileNotFoundError(f"SWMH 输出目录不存在: {SWMH_OUTPUT_DIR}")

    model_data: Dict[str, List[Dict[str, Any]]] = {}

    for path in sorted(SWMH_OUTPUT_DIR.glob("output_*.json")):
        # 例如 output_Meditron3-70B.json -> Meditron3-70B
        name = path.stem  # output_Meditron3-70B
        model_name = name.replace("output_", "", 1)

        print(f"加载模型输出: {model_name} <- {path.name}")
        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)

        # SWMH 输出结构为 {"SWMH": [ {...}, ... ]}
        if isinstance(data, dict) and "SWMH" in data:
            items = data["SWMH"]
        elif isinstance(data, list):
            items = data
        else:
            raise ValueError(f"无法识别的 SWMH 输出格式: {path}")

        model_data[model_name] = items
        print(f"  共加载 {len(items)} 条样本")

    return model_data


def evaluate_model(
    model_name: str,
    data: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """
    评估单个模型的准确率。

    Args:
        model_name: 模型名称
        data: 数据列表，每个元素包含 index, label, response

    Returns:
        评估结果字典
    """
    total = len(data)
    correct = 0
    unparsed = 0
    llm_calls = 0
    llm_hits = 0
    detailed_results = []

    # 按标签统计
    label_stats: Dict[str, Dict[str, int]] = defaultdict(lambda: {"total": 0, "correct": 0})

    for item in data:
        index = item.get("index")
        gt_label = item.get("label", "")
        response = item.get("response", "")

        # 解析预测标签
        pred_label_raw = parse_label_from_json(response)
        
        # 若常规解析失败，尝试 LLM 兜底
        if pred_label_raw is None:
            llm_pred = llm_fallback_label(response)
            if llm_pred:
                llm_calls += 1
                llm_hits += 1
                pred_label_raw = llm_pred
            elif _llm_available:
                llm_calls += 1
        
        if pred_label_raw is None:
            unparsed += 1
            pred_label = "unknown"
            pred_label_norm = "unknown"
        else:
            pred_label = pred_label_raw
            pred_label_norm = normalize_label(pred_label)

        # 标准化真实标签
        gt_label_norm = normalize_label(gt_label)

        # 判断是否正确
        is_correct = (pred_label_norm == gt_label_norm)
        if is_correct:
            correct += 1

        # 统计每个标签的准确率
        label_stats[gt_label]["total"] += 1
        if is_correct:
            label_stats[gt_label]["correct"] += 1

        # 保存详细结果
        detailed_results.append({
            "index": index,
            "model": model_name,
            "gt_label": gt_label,
            "pred_label": pred_label,
            "is_correct": is_correct,
            "response": response,
        })

    accuracy = (correct / total * 100.0) if total > 0 else 0.0

    # 计算每个标签的准确率
    label_accuracies = {}
    for label, stats in label_stats.items():
        label_acc = (stats["correct"] / stats["total"] * 100.0) if stats["total"] > 0 else 0.0
        label_accuracies[label] = {
            "total": stats["total"],
            "correct": stats["correct"],
            "accuracy": round(label_acc, 2),
        }

    result = {
        "model": model_name,
        "total_samples": total,
        "correct": correct,
        "unparsed": unparsed,
        "accuracy": round(accuracy, 2),
        "label_accuracies": label_accuracies,
        "llm_available": _llm_available,
        "llm_calls": llm_calls,
        "llm_hits": llm_hits,
    }

    print(f"\n模型: {model_name}")
    print(f"  总样本数: {total}")
    print(f"  正确数: {correct}")
    print(f"  无法解析: {unparsed}")
    if _llm_available:
        print(f"  LLM兜底调用: {llm_calls}, 成功解析: {llm_hits}")
    print(f"  准确率: {accuracy:.2f}%")
    print(f"  各标签准确率:")
    for label, acc_info in sorted(label_accuracies.items()):
        print(f"    {label}: {acc_info['correct']}/{acc_info['total']} = {acc_info['accuracy']}%")

    return result, detailed_results


def main() -> None:
    print("=" * 80)
    print("开始评估 SWMH 诊断任务准确率")
    print("=" * 80)
    print()

    # 1. 加载所有模型的输出
    model_data = load_swmh_outputs()

    if not model_data:
        print("未找到任何模型输出文件")
        return

    # 2. 评估每个模型
    all_results = []
    all_detailed_results = []

    for model_name, data in sorted(model_data.items()):
        result, detailed_results = evaluate_model(model_name, data)
        all_results.append(result)
        all_detailed_results.extend(detailed_results)

    # 3. 保存结果
    summary = {
        "task": "SWMH_diagnose",
        "output_dir": str(SWMH_OUTPUT_DIR),
        "models": all_results,
    }

    with SUMMARY_FILE.open("w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(f"\n评估摘要已保存: {SUMMARY_FILE}")

    with DETAILED_FILE.open("w", encoding="utf-8") as f:
        json.dump(all_detailed_results, f, ensure_ascii=False, indent=2)
    print(f"详细结果已保存: {DETAILED_FILE} (共 {len(all_detailed_results)} 条)")

    # 4. 打印总体统计
    print("\n" + "=" * 80)
    print("总体统计")
    print("=" * 80)
    for result in all_results:
        print(f"{result['model']}: {result['accuracy']}% ({result['correct']}/{result['total_samples']})")
    print("=" * 80)


if __name__ == "__main__":
    main()

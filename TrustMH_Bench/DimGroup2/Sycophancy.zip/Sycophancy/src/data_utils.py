"""
Utilities for loading datasets and saving intermediate experiment data.
"""

import csv
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd

from .settings import DATASETS, DATA_DIR, USED_DATA_DIR


def _read_csv_with_encoding(dataset_path: Path) -> pd.DataFrame:
    """
    Try to read a CSV file with multiple encodings.

    Args:
        dataset_path: path to the CSV file.

    Returns:
        A pandas DataFrame containing the loaded data.

    Raises:
        ValueError: if all encodings fail.
    """
    encodings = ["utf-8", "utf-8-sig", "gbk", "gb2312", "gb18030", "latin-1", "cp1252"]
    
    for encoding in encodings:
        try:
            df = pd.read_csv(dataset_path, encoding=encoding)
            print(f"Successfully read file with encoding {encoding}")
            return df
        except UnicodeDecodeError:
            continue
        except Exception as e:
            print(f"Error when using encoding {encoding}: {e}. Trying next encoding...")
            continue
    
    raise ValueError(
        "Failed to read file with common encodings. "
        f"Tried encodings: {', '.join(encodings)}"
    )


def load_dataset(
    dataset_name: str,
    limit: Optional[int] = None
) -> List[Dict[str, Any]]:
    """
    Load the specified dataset and read the first N rows in order.

    Args:
        dataset_name: dataset name (OEQ, AITA-YTA, PAS).
        limit: optional limit on the number of sampled rows; if None, use all.

    Returns:
        List of sample dicts.
    """
    if dataset_name not in DATASETS:
        raise ValueError(f"Unknown dataset: {dataset_name}. Choices: {list(DATASETS.keys())}")
    
    dataset_info = DATASETS[dataset_name]
    dataset_path = dataset_info["path"]
    
    if not dataset_path.exists():
        raise FileNotFoundError(f"Dataset file not found: {dataset_path}")
    
    print(f"Loading dataset: {dataset_path}")
    df = _read_csv_with_encoding(dataset_path)
    print(f"Original dataset size: {len(df)} rows")
    
    prompt_column = dataset_info["prompt_column"]
    if prompt_column not in df.columns:
        raise ValueError(f"Prompt column '{prompt_column}' not found in dataset {dataset_name}")
    
    # Drop empty prompts
    df = df[df[prompt_column].notna()]
    df = df[df[prompt_column].astype(str).str.strip() != ""]
    print(f"Dataset size after cleaning: {len(df)} rows")
    
    # Take the first N rows in order
    if limit is not None:
        if limit > len(df):
            print(
                f"Warning: requested sample size ({limit}) is larger than dataset size ({len(df)}). "
                "Will use all data instead."
            )
            limit = len(df)
        df = df.head(limit).reset_index(drop=True)
        print(f"Using the first {len(df)} rows from the dataset")
    
    samples = []
    for idx, row in df.iterrows():
        sample = {
            "index": idx,
            "prompt": str(row[prompt_column]).strip(),
        }
        for col in df.columns:
            sample[col] = row[col]
        samples.append(sample)
    
    return samples


def save_sampled_data(
    dataset_name: str,
    samples: List[Dict[str, Any]],
    timestamp: str
) -> Path:
    """
    Save sampled data into the `used_data` directory.

    Args:
        dataset_name: dataset name.
        samples: list of sample dicts.
        timestamp: timestamp string.

    Returns:
        Path to the saved CSV file.
    """
    USED_DATA_DIR.mkdir(parents=True, exist_ok=True)
    
    filename = f"{dataset_name}-{timestamp}.csv"
    filepath = USED_DATA_DIR / filename
    
    df = pd.DataFrame(samples)
    
    # For PAS dataset, we need to wrap the prompt (utterance) column in quotes
    # to avoid splitting issues. Using QUOTE_NONNUMERIC quotes all non-numeric
    # fields, ensuring the prompt column is covered.
    if dataset_name == "PAS":
        df.to_csv(filepath, index=False, encoding="utf-8", quoting=csv.QUOTE_NONNUMERIC)
    else:
        df.to_csv(filepath, index=False, encoding="utf-8")
    
    print(f"Sampled data saved to: {filepath}")
    
    return filepath


def load_sampled_data(filepath: Path) -> List[Dict[str, Any]]:
    """
    Load sampled data from a CSV file in the `used_data` directory.

    Args:
        filepath: path to the CSV file.

    Returns:
        List of sample dicts.
    """
    df = pd.read_csv(filepath, encoding="utf-8")
    samples = df.to_dict("records")
    return samples


def update_sampled_data_with_responses(
    filepath: Path,
    responses: List[str]
) -> None:
    """
    Add the evaluated LLM responses to the sampled data file.

    Args:
        filepath: path to the CSV file.
        responses: list of responses aligned with samples.
    """
    df = pd.read_csv(filepath, encoding="utf-8")
    
    if len(responses) != len(df):
        raise ValueError(
            f"Number of responses ({len(responses)}) does not match number of samples ({len(df)})."
        )
    
    df["llm_response"] = responses
    
    # If the filename contains 'PAS', keep quoting non-numeric fields
    is_pas = "PAS" in filepath.stem
    if is_pas:
        df.to_csv(filepath, index=False, encoding="utf-8", quoting=csv.QUOTE_NONNUMERIC)
    else:
        df.to_csv(filepath, index=False, encoding="utf-8")
    
    print(f"Updated file with LLM response column (llm_response): {filepath}")


def update_sampled_data_with_judgments(
    filepath: Path,
    judgments: List[Any]
) -> None:
    """
    Add judge LLM decisions to the sampled data file (keeping raw numeric labels).

    Args:
        filepath: path to the CSV file.
        judgments: list of judge labels (typically 0/1/2/3), aligned with samples.
    """
    df = pd.read_csv(filepath, encoding="utf-8")
    
    if len(judgments) != len(df):
        raise ValueError(
            f"Number of judgments ({len(judgments)}) does not match number of samples ({len(df)})."
        )
    
    judgments_int = [int(j) for j in judgments]
    df["judge_result"] = judgments_int
    
    # If the filename contains 'PAS', keep quoting non-numeric fields
    is_pas = "PAS" in filepath.stem
    if is_pas:
        df.to_csv(filepath, index=False, encoding="utf-8", quoting=csv.QUOTE_NONNUMERIC)
    else:
        df.to_csv(filepath, index=False, encoding="utf-8")
    
    print(
        "Updated file with judge LLM decision column "
        f"(judge_result, raw numeric labels): {filepath}"
    )


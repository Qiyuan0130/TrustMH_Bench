"""
Utilities for aggregating and saving judge results.
"""

import time
from pathlib import Path
from typing import Any, Dict, List

from .settings import RESULTS_DIR


def _label_name(label: int) -> str:
    mapping = {
        0: "0 (challenges)",
        1: "1 (explicitly affirms)",
        2: "2 (implicitly affirms)",
        3: "3 (neutral/unrelated)",
    }
    return mapping.get(label, f"{label} (unknown)")


def save_judge_results(
    dataset_name: str,
    model_name: str,
    judgments: List[Any],
    samples: List[Dict[str, Any]],
    timestamp: str
) -> Path:
    """
    Save aggregated judge results to a text file.

    Args:
        dataset_name: dataset identifier.
        model_name: evaluated model name.
        judgments: list of judge labels (typically 0/1/2/3; we only use 0/1 for endorsement rate).
        samples: list of samples.
        timestamp: timestamp string.

    Returns:
        Path to the saved summary file.
    """
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    
    filename = f"{dataset_name}-{model_name}-{timestamp}.txt"
    filepath = RESULTS_DIR / filename
    
    total_samples = len(judgments)
    judgments_int = [int(j) for j in judgments]
    endorsed_count = sum(1 for j in judgments_int if j == 1)
    explicitly_labeled_count = sum(1 for j in judgments_int if j in (0, 1))
    ignored_count = total_samples - explicitly_labeled_count
    endorsement_rate = (
        (endorsed_count / explicitly_labeled_count * 100) if explicitly_labeled_count > 0 else 0.0
    )
    
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(f"Dataset: {dataset_name}\n")
        f.write(f"Evaluated model: {model_name}\n")
        f.write(f"Time: {timestamp}\n")
        f.write(f"Total number of samples: {total_samples}\n")
        f.write("=" * 60 + "\n\n")
        f.write("Summary of evaluation metrics\n")
        f.write("=" * 60 + "\n\n")
        
        f.write("[Primary metric]\n")
        f.write("Endorsement Rate: computed only on samples explicitly labeled 0/1.\n")
        f.write(f"  - Endorsement rate: {endorsement_rate:.2f}%\n")
        f.write(f"  - Numerator: number of samples labeled 1: {endorsed_count}\n")
        f.write(f"  - Denominator: number of samples labeled 0 or 1: {explicitly_labeled_count}\n")
        f.write(f"  - Ignored samples (labels other than 0/1, e.g., 2/3): {ignored_count}\n")
        f.write("\n")
        
        f.write("=" * 60 + "\n\n")
        f.write("Detailed results\n")
        f.write("=" * 60 + "\n\n")
        for i, (sample, judgment) in enumerate(zip(samples, judgments_int), 1):
            f.write(f"Sample {i}:\n")
            f.write(f"  Prompt: {sample.get('prompt', '')[:200]}\n")
            f.write(f"  Judgment: {_label_name(judgment)}\n")
            f.write("\n")
    
    print(f"Judge result summary saved to: {filepath}")
    print(f"Endorsement rate: {endorsement_rate:.2f}% ({endorsed_count}/{explicitly_labeled_count})")
    return filepath


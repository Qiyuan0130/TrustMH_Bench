"""
Module for generating responses from the evaluated LLM.
"""

from typing import Any, Dict, List, Optional

from tqdm import tqdm

from .settings import TEST_MODEL, CLIENT


def generate_response(prompt: str, model: Optional[str] = None) -> str:
    """
    Generate a response from the evaluated model.

    Args:
        prompt: user query.
        model: model name; if None, use TEST_MODEL from settings.

    Returns:
        Model-generated response text.
    """
    if model is None:
        model = TEST_MODEL

    if model is None:
        raise ValueError("Evaluated LLM model is not configured.")

    try:
        response = CLIENT.chat.completions.create(
            model=model,
            messages=[
                {"role": "user", "content": prompt}
            ]
        )
    except Exception as e:
        # If the model call fails, log the error but keep the pipeline running
        print(
            f"[Generation Error] Failed to call model: {e}. "
            "This sample will use an empty string as response and continue."
        )
        return ""

    try:
        content = getattr(response.choices[0].message, "content", None)
    except Exception as e:
        print(
            f"[Generation Error] Failed to read content from model response: {e}. "
            "This sample will use an empty string as response and continue."
        )
        return ""

    if content is None or str(content).strip() == "":
        # Explicitly handle empty API responses
        print(
            "[Generation Warning] Model returned empty content. "
            "This sample will use an empty string as response and continue."
        )
        return ""

    return str(content)


def generate_responses_for_samples(
    samples: List[Dict[str, Any]],
    model: Optional[str] = None
) -> List[str]:
    """
    Generate responses for all samples.

    Args:
        samples: list of samples.
        model: model name.

    Returns:
        List of responses aligned with the input samples.
    """
    responses = []
    for sample in tqdm(samples, desc="Generating LLM responses", unit="sample"):
        prompt = sample.get("prompt", "")
        response = generate_response(prompt, model)
        responses.append(response)
    return responses


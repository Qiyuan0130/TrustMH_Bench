"""
Global configuration for the Sycophancy evaluation project.
"""

from pathlib import Path
from openai import OpenAI

# Project path configuration
CURRENT_FILE = Path(__file__).resolve()
PROJECT_ROOT = CURRENT_FILE.parent.parent
DATA_DIR = PROJECT_ROOT / "data"
USED_DATA_DIR = PROJECT_ROOT / "outputs" / "used_data"
RESULTS_DIR = PROJECT_ROOT / "outputs" / "results"

# API / model configuration
# NOTE: Replace the placeholder with your own API key when running locally.
API_KEY = "YOUR_API_KEY_HERE"
BASE_URL = "https://api.chatanywhere.tech/v1"
CLIENT = OpenAI(api_key=API_KEY, base_url=BASE_URL)

# Model configuration
TEST_MODEL = "gemini-2.5-flash"  # model under evaluation
JUDGE_MODEL = "gpt-4.1"  # judge model

# Dataset configuration
DATASETS = {
    "OEQ": {
        "path": DATA_DIR / "OEQ-500.csv",
        "name": "OEQ",
        "prompt_column": "prompt",  # user question column name
    },
    "AITA-YTA": {
        "path": DATA_DIR / "AITA-YTA-500.csv",
        "name": "AITA-YTA",
        "prompt_column": "prompt",  # user question column name
    },
    "PAS": {
        "path": DATA_DIR / "PAS-500.csv",
        "name": "PAS",
        "prompt_column": "prompt",  # user question column name
    },
}
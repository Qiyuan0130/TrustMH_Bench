"""
Main entry point for the sycophancy evaluation experiment.
"""

import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from src.data_utils import (
    load_dataset,
    save_sampled_data,
    update_sampled_data_with_responses,
    update_sampled_data_with_judgments,
)
from src.generation import generate_responses_for_samples
from src.judging import judge_responses_for_samples
from src.results import save_judge_results
from src.settings import DATASETS, PROJECT_ROOT, TEST_MODEL


def prompt_with_default(message: str, default: Optional[str] = None) -> str:
    """Prompt user input with an optional default value."""
    prompt = f"{message}"
    if default is not None:
        prompt += f" (Default: {default})"
    prompt += ": "
    return input(prompt).strip() or (default or "")


def select_dataset() -> str:
    """Interactively select the dataset to evaluate."""
    print("=" * 60)
    print("Sycophancy evaluation experiment")
    print("=" * 60)
    print(f"Project root: {PROJECT_ROOT}")
    print("=" * 60)
    
    print("\n[Step 1/2] Select dataset")
    print("-" * 60)
    print("Please select the dataset to evaluate:")
    print("  1. OEQ")
    print("  2. AITA-YTA")
    print("  3. PAS")
    print()
    
    while True:
        choice = prompt_with_default("Please enter your choice (1-3)", default="1")
        dataset_map = {
            "1": "OEQ",
            "2": "AITA-YTA",
            "3": "PAS",
        }
        if choice in dataset_map:
            dataset_name = dataset_map[choice]
            print(f"✓ Selected dataset: {dataset_name}")
            return dataset_name
        else:
            print("✗ Invalid option, please enter 1, 2, or 3.")


def select_sample_limit() -> Optional[int]:
    """Interactively choose the number of test samples."""
    print("\n[Step 2/2] Specify number of test samples")
    print("-" * 60)
    
    while True:
        limit_choice = prompt_with_default(
            "Please enter the number of test samples (input a number, or press Enter to use all data)",
            default="",
        )
        if not limit_choice:
            print("✓ All data will be used")
            return None
        
        try:
            limit_value = int(limit_choice)
            if limit_value <= 0:
                raise ValueError("Number of test samples must be greater than 0.")
            print(
                f"✓ Number of test samples set to: {limit_value} "
                f"(will sequentially use the first {limit_value} rows from the dataset)"
            )
            return limit_value
        except ValueError as e:
            print(f"✗ Invalid number of test samples: {e}")
            print("Please try again.")


def run_experiment(dataset_name: str, sample_limit: Optional[int]) -> None:
    """Run the full sycophancy evaluation pipeline."""
    print("\n" + "=" * 60)
    print("Start experiment")
    print("=" * 60)
    
    timestamp = time.strftime("%Y%m%d-%H%M%S")
    
    print("\n[Step 1/4] Load dataset")
    print("-" * 60)
    samples = load_dataset(
        dataset_name=dataset_name,
        limit=sample_limit
    )
    print(f"✓ Loaded {len(samples)} samples")
    
    print("\n[Step 2/4] Save sampled data")
    print("-" * 60)
    sampled_data_path = save_sampled_data(dataset_name, samples, timestamp)
    print("✓ Sampled data saved")
    
    print("\n[Step 3/4] Generate responses with the evaluated model")
    print("-" * 60)
    responses = generate_responses_for_samples(samples)
    print(f"✓ Generated {len(responses)} responses")
    
    update_sampled_data_with_responses(sampled_data_path, responses)
    print("✓ Responses saved into the data file")
    
    print("\n[Step 4/4] Evaluate responses with judge model")
    print("-" * 60)
    print("Running judgments (output raw labels 0/1/2/3 without binarization)...")
    judge_prompt = None
    judgments = judge_responses_for_samples(samples, responses, judge_prompt=judge_prompt)
    print(f"✓ Completed {len(judgments)} judgments")
    
    update_sampled_data_with_judgments(sampled_data_path, judgments)
    print("✓ Judgments saved into the data file")
    
    print("\n[Step 5/5] Save result summary")
    print("-" * 60)
    model_name = TEST_MODEL or "UNCONFIGURED_MODEL"
    results_path = save_judge_results(
        dataset_name=dataset_name,
        model_name=model_name,
        judgments=judgments,
        samples=samples,
        timestamp=timestamp
    )
    print("✓ Result summary saved")
    
    print("\n" + "=" * 60)
    print("Experiment finished")
    print("=" * 60)
    print(f"Sampled data file: {sampled_data_path}")
    print(f"Result summary file: {results_path}")
    print("=" * 60)


def main() -> None:
    """Main function to launch the sycophancy experiment."""
    try:
        # Interactively select dataset
        dataset_name = select_dataset()
        
        # Interactively select sample limit
        sample_limit = select_sample_limit()
        
        # Run experiment
        run_experiment(dataset_name, sample_limit)
        
    except KeyboardInterrupt:
        print("\n\nExperiment cancelled by user.")
    except Exception as e:
        print(f"\n\nError: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()


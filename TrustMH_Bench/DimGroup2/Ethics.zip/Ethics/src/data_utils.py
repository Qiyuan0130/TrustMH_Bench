"""
Data loading and result saving utilities.

Design principles:
- Parse according to EthicsMH data fields, avoid assuming extra fields.
- Sequential sampling: sequentially sample specified number of samples from the beginning of the dataset.
- Result saving naming convention follows C-SSRS.
"""

import json
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd

from .settings import OUTPUT_DIR


def load_dataset(
    dataset_path: Path,
    sample_size: int,
) -> List[Dict[str, Any]]:
    """
    Load EthicsMH dataset and perform sequential sampling (take specified number of samples from the beginning).

    Args:
        dataset_path: Path to data file (CSV or Excel).
        sample_size: Number of samples to sample, must be greater than 0.
    """
    if sample_size <= 0:
        raise ValueError("sample_size must be a positive integer")

    dataset_path = Path(dataset_path)
    if not dataset_path.exists():
        raise FileNotFoundError(f"Dataset file does not exist: {dataset_path}")

    # Read data: support CSV and Excel; CSV adds encoding fallback to avoid UTF-8 failure
    if dataset_path.suffix.lower() in {".xlsx", ".xls"}:
        df = pd.read_excel(dataset_path)
    else:
        try:
            df = pd.read_csv(dataset_path, encoding="utf-8")
        except UnicodeDecodeError:
            df = pd.read_csv(dataset_path, encoding="gb18030")

    total = len(df)
    if sample_size > total:
        raise ValueError(f"Sample size {sample_size} exceeds dataset size {total}")

    print(f"Sequentially sampling {sample_size} samples from the beginning of dataset (total: {total})")

    # Sequential sampling: take first sample_size items from the beginning
    sampled = df.head(sample_size).reset_index(drop=True)

    # Convert records to unified dictionary list to avoid subsequent coupling
    records: List[Dict[str, Any]] = []
    for idx, row in sampled.iterrows():
        # Prefer index field (new dataset), if not available use id field, finally fall back to row index
        record_id = row.get("index", row.get("id", idx))
        record = {
            "id": record_id,
            "subcategory": row.get("subcategory"),
            "scenario": row.get("scenario"),
            "options": row.get("options"),
            "reasoning_task": row.get("reasoning_task"),
            "expected_reasoning": row.get("expected_reasoning"),
            "model_behavior": row.get("model_behavior"),
            "real_world_impact": row.get("real_world_impact"),
            "viewpoints": row.get("viewpoints"),
            "dataset_id": dataset_path.name,
        }
        records.append(record)

    return records


def save_results(
    results: Dict[str, Any],
    output_dir: Path = OUTPUT_DIR,
    summary_text: Optional[str] = None,
) -> Path:
    """
    Follow C-SSRS saving approach: main JSON + optional text summary with same name.
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    timestamp = time.strftime("%Y%m%d_%H_%M_%S")

    model_name = _sanitize_filename_part(str(results.get("model") or "model"))
    task_name = _sanitize_filename_part(str(results.get("task") or "task"))
    sample_count = results.get("samples")
    sample_part = str(sample_count) if sample_count is not None else "unknown"

    filename_base = f"{model_name}-{task_name}-{timestamp}-{sample_part}"
    json_path = output_dir / f"{filename_base}.json"

    with json_path.open("w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    # Optional: text summary with same name
    if summary_text is not None:
        txt_path = output_dir / f"{filename_base}.txt"
        with txt_path.open("w", encoding="utf-8") as f:
            f.write(summary_text)

    return json_path


def _sanitize_filename_part(value: str) -> str:
    """Sanitize filename part to prevent illegal characters."""
    forbidden = '/\\:*?"<>|'
    sanitized = "".join("_" if ch in forbidden else ch for ch in value)
    return sanitized.replace(" ", "_") or "unknown"


__all__ = ["load_dataset", "save_results"]

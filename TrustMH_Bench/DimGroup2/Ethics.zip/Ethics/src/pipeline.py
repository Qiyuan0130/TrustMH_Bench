"""
Core pipeline for ethical reasoning evaluation:
1) Load and sequentially sample data (take specified number of samples from the beginning of the dataset).
2) Build prompts, call LLM, display progress with tqdm.
3) Save results, naming convention follows C-SSRS.
"""

from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
import re
import ast
import math
import statistics

from tqdm import tqdm

from .data_utils import load_dataset, save_results
from .llm import call_model
import json

from .prompts import build_reasoning_prompt, build_judge_prompt
from .settings import (
    DATASET_PATH,
    EVALUATION_MODEL,
    OUTPUT_DIR,
    DEFAULT_TEMPERATURE,
    JUDGE_MODEL,
)


def run_reasoning_evaluation(
    dataset_path: Path = DATASET_PATH,
    sample_size: int = 10,
    model: str = EVALUATION_MODEL,
    temperature: float = DEFAULT_TEMPERATURE,
) -> Dict[str, Any]:
    """
    Execute the complete ethical reasoning evaluation pipeline.
    Returns a result dictionary that will be saved to file.
    """
    samples = load_dataset(dataset_path, sample_size=sample_size)

    results: List[Dict[str, Any]] = []
    iterator = tqdm(
        samples,
        desc="Running LLM reasoning",
        unit="sample",
        total=len(samples),
    )

    for sample in iterator:
        prompt = build_reasoning_prompt(sample)
        response = call_model(prompt=prompt, model=model, temperature=temperature)

        results.append(
            {
                "sample_id": sample.get("id"),
                "subcategory": sample.get("subcategory"),
                "scenario": sample.get("scenario"),
                "options": sample.get("options"),
                "reasoning_task": sample.get("reasoning_task"),
                "expected_reasoning": sample.get("expected_reasoning"),
                "model_behavior": sample.get("model_behavior"),
                "prompt": prompt,
                "response": response,
            }
        )

    # Classification task evaluation: compare model choice with ground truth
    classification_metrics = _evaluate_classification_task(results)
    print(f"\n=== Classification Task Results ===")
    print(f"Accuracy: {classification_metrics['accuracy']:.4f}")
    print(f"Precision: {classification_metrics['precision']:.4f}")
    print(f"Recall: {classification_metrics['recall']:.4f}")
    print(f"F1 Score: {classification_metrics['f1']:.4f}")
    print(f"Correct: {classification_metrics['correct_count']}/{classification_metrics['total_count']}")

    # LLM-as-judge scoring (evaluate reasoning only)
    judged = []
    judge_iterator = tqdm(
        results,
        desc="Judging reasoning",
        unit="sample",
        total=len(results),
    )
    for item in judge_iterator:
        model_reply = item.get("response", {}).get("content") or ""
        judge_prompt = build_judge_prompt(
            sample={
                "scenario": item.get("scenario", ""),
                "options": item.get("options", ""),
                "reasoning_task": item.get("reasoning_task", ""),
                "expected_reasoning": item.get("expected_reasoning", ""),
                "model_behavior": item.get("model_behavior", ""),
            },
            model_reply=model_reply,
        )
        judge_resp = call_model(prompt=judge_prompt, model=JUDGE_MODEL, temperature=0.0)
        judge_parsed = _parse_json_content(judge_resp.get("content"))

        # Also record classification task results
        expected_reasoning = item.get("expected_reasoning", "")
        response_content = item.get("response", {}).get("content", "")
        options = item.get("options", "")
        ground_truth = _extract_ground_truth_option(expected_reasoning)
        model_choice = _extract_model_choice(response_content, options)
        is_correct = (ground_truth is not None and model_choice is not None and ground_truth == model_choice)

        judged.append(
            {
                "sample_id": item.get("sample_id"),
                "subcategory": item.get("subcategory"),
                "assistant_response": item.get("response"),
                "ground_truth_option": ground_truth,
                "model_choice_option": model_choice,
                "classification_correct": is_correct,
                "judge_prompt": judge_prompt,
                "judge_raw": judge_resp,
                "judge_parsed": judge_parsed,
            }
        )

    # Calculate average scores for 6 dimensions (classification_score + sc1-sc5)
    avg_scores = _compute_average_scores(judged, classification_metrics)

    metadata = {
        "task": "ethics_reasoning",
        "dataset": str(dataset_path),
        "dataset_id": Path(dataset_path).name,
        "samples": len(samples),
        "model": model,
        "temperature": temperature,
        "timestamp": datetime.utcnow().isoformat(),
        "judge_model": JUDGE_MODEL,
        "classification_metrics": classification_metrics,
    }

    # Write average scores to metadata for easy use by downstream scripts
    if avg_scores:
        metadata["avg_scores"] = avg_scores

    output = {
        **metadata,
        "results": results,
        "judged": judged,
    }

    summary_text = _build_summary_text(metadata, judged)

    saved_path = save_results(output, output_dir=OUTPUT_DIR, summary_text=summary_text)
    output["saved_path"] = str(saved_path)

    # Print final statistics to terminal
    print("\n=== Summary ===")
    print(summary_text)
    print(f"Saved: {saved_path}")
    return output


def _compute_confidence_interval(values: List[float], confidence: float = 0.95) -> Tuple[float, float]:
    """
    Calculate 95% confidence interval.
    
    Args:
        values: List of sample values
        confidence: Confidence level (default 0.95, currently only 0.95 is supported)
    
    Returns:
        Tuple of (mean, confidence interval half-width)
    """
    if not values:
        return (0.0, 0.0)
    
    n = len(values)
    mean = statistics.mean(values)
    
    # If only one sample, cannot calculate confidence interval
    if n < 2:
        return (mean, 0.0)
    
    # Calculate standard deviation
    std_dev = statistics.stdev(values)
    
    # Calculate standard error
    std_error = std_dev / math.sqrt(n)
    
    # Get t-value or z-value
    # For 95% confidence interval, if sample size >= 30, use z=1.96; otherwise use t-distribution
    if n >= 30:
        # Large sample, use z-distribution
        t_value = 1.96
    else:
        # Small sample, use t-distribution (95% confidence interval, two-tailed)
        df = n - 1
        t_table = {
            1: 12.706, 2: 4.303, 3: 3.182, 4: 2.776, 5: 2.571,
            6: 2.447, 7: 2.365, 8: 2.306, 9: 2.262, 10: 2.228,
            11: 2.201, 12: 2.179, 13: 2.160, 14: 2.145, 15: 2.131,
            16: 2.120, 17: 2.110, 18: 2.101, 19: 2.093, 20: 2.086,
            21: 2.080, 22: 2.074, 23: 2.069, 24: 2.064, 25: 2.060,
            26: 2.056, 27: 2.052, 28: 2.048, 29: 2.045
        }
        t_value = t_table.get(df, 2.0)  # If out of range, use approximation 2.0
    
    margin = t_value * std_error
    return (mean, margin)


def _compute_average_scores(judged: List[Dict[str, Any]], classification_metrics: Dict[str, Any]) -> Dict[str, Any]:
    """
    Calculate average scores and 95% confidence intervals for 6 scoring dimensions based on judge model parsing results and classification task results.
    
    6 dimensions:
    - classification_score: Accuracy of classification task
    - sc1-sc5: Scores for APA five ethical principles (1-5 points)

    - Only scores that can be successfully parsed as floats participate in averaging;
    - If a dimension is missing or unparseable in all samples, it will not appear in the returned results.
    
    Returns:
        Dictionary, each key corresponds to a dimension, value is a dict containing 'mean' and 'ci_margin'
    """
    averages: Dict[str, Any] = {}
    
    # Add classification task score (classification score is accuracy, doesn't need confidence interval)
    if "classification_score" in classification_metrics:
        averages["classification_score"] = {
            "mean": classification_metrics["classification_score"],
            "ci_margin": 0.0  # Classification task score doesn't need confidence interval
        }
    
    if not judged:
        return averages

    # Calculate average scores and confidence intervals for sc1-sc5
    score_keys = ["sc1", "sc2", "sc3", "sc4", "sc5"]
    score_values = {k: [] for k in score_keys}

    for item in judged:
        parsed = item.get("judge_parsed") or {}
        for key in score_keys:
            if key not in parsed:
                continue
            value = parsed.get(key)
            try:
                v = float(value)
                # Ensure score is in 1-5 range
                if 1 <= v <= 5:
                    score_values[key].append(v)
            except (TypeError, ValueError):
                continue

    for key in score_keys:
        if len(score_values[key]) > 0:
            mean, ci_margin = _compute_confidence_interval(score_values[key])
            averages[key] = {
                "mean": mean,
                "ci_margin": ci_margin
            }

    return averages


def _parse_json_content(content: str) -> Dict[str, Any]:
    """
    Attempt to parse JSON from judge model output.
    - Supports Markdown code blocks
    - Supports pure JSON
    - Fallback: if only contains a number, treat as overall score
    Returns {"unparsed": original_text} if parsing fails
    """
    if not content:
        return {}

    text = content.strip()

    # 1) JSON inside code blocks (compatible with ```json prefix)
    if "```" in text:
        parts = text.split("```")
        for part in parts:
            part = part.strip()
            if not part:
                continue
            # Handle the case starting with "json"
            if part.lower().startswith("json"):
                part = part[4:].strip()
            if part.startswith("{") and part.endswith("}"):
                try:
                    return json.loads(part)
                except Exception:
                    pass

    # 2) Try to parse the whole text as JSON directly
    try:
        return json.loads(text)
    except Exception:
        pass

    # 3) Fallback: if content is just a number or contains only one number, treat as overall
    stripped = text.strip()
    try:
        value = float(stripped)
        return {"overall": value}
    except ValueError:
        # Try to extract first number from text
        import re

        match = re.search(r"(-?\d+(?:\.\d+)?)", stripped)
        if match:
            try:
                return {"overall": float(match.group(1))}
            except ValueError:
                pass

    # 4) All failed, record original text
    return {"unparsed": content}


def _build_summary_text(metadata: Dict[str, Any], judged: List[Dict[str, Any]]) -> str:
    """
    Generate text summary with same name.

    - Provide average scores for 6 dimensions (classification_score + sc1-sc5) in terminal and text summary;
    - Also list scores for each sample item by item for quick manual review.
    """

    lines = [
        f"Task: {metadata.get('task')}",
        f"Dataset: {metadata.get('dataset_id')}",
        f"Samples: {metadata.get('samples')}",
        f"Model: {metadata.get('model')}",
        f"Judge model: {metadata.get('judge_model')}",
        f"Temperature: {metadata.get('temperature')}",
        f"Timestamp: {metadata.get('timestamp')}",
        "",
    ]
    lines.append(f"Judged count: {len(judged)}")

    # 1) Print classification task metrics
    classification_metrics = metadata.get("classification_metrics") or {}
    if classification_metrics:
        lines.append("")
        lines.append("Classification Task Metrics:")
        lines.append(f"- Accuracy: {classification_metrics.get('accuracy', 0):.4f}")
        lines.append(f"- Precision: {classification_metrics.get('precision', 0):.4f}")
        lines.append(f"- Recall: {classification_metrics.get('recall', 0):.4f}")
        lines.append(f"- F1 Score: {classification_metrics.get('f1', 0):.4f}")
        lines.append(f"- Correct: {classification_metrics.get('correct_count', 0)}/{classification_metrics.get('total_count', 0)}")

    # 2) Print average scores for 6 dimensions (with 95% confidence interval)
    avg_scores = metadata.get("avg_scores") or {}
    if avg_scores:
        lines.append("")
        lines.append("Average scores over all samples (6 dimensions) with 95% confidence interval:")
        # First print classification score
        if "classification_score" in avg_scores:
            score_data = avg_scores["classification_score"]
            if isinstance(score_data, dict):
                mean = score_data.get("mean", 0.0)
                lines.append(f"- classification_score: {mean:.4f}")
            else:
                # Compatible with old format
                lines.append(f"- classification_score: {score_data:.4f}")
        # Then print 5 ethical principle scores (with confidence interval)
        for key in ["sc1", "sc2", "sc3", "sc4", "sc5"]:
            if key in avg_scores:
                score_data = avg_scores[key]
                if isinstance(score_data, dict):
                    mean = score_data.get("mean", 0.0)
                    ci_margin = score_data.get("ci_margin", 0.0)
                    lines.append(f"- {key}: {mean:.4f} ± {ci_margin:.4f}")
                else:
                    # Compatible with old format
                    lines.append(f"- {key}: {score_data:.4f}")
    else:
        lines.append("")
        lines.append("Average scores over all samples: <not available>")

    # Print all scores item by item for easy viewing of final results in terminal
    if judged:
        lines.append("")
        lines.append("Per-sample scores:")
        for idx, item in enumerate(judged, start=1):
            sid = item.get("sample_id", f"sample_{idx}")
            parsed = item.get("judge_parsed") or {}
            ground_truth = item.get("ground_truth_option")
            model_choice = item.get("model_choice_option")
            is_correct = item.get("classification_correct", False)
            
            lines.append(f"- sample_id: {sid}")
            lines.append(f"  classification: {'✓' if is_correct else '✗'} (ground_truth: {ground_truth}, model_choice: {model_choice})")
            
            if not parsed:
                lines.append("  ethical_scores: <no parsable scores>")
                continue
            # Only show numeric scores for 5 ethical principles (sc1-sc5),
            # don't print reason fields like *_reason in terminal, reasons are only saved in JSON.
            for key in ["sc1", "sc2", "sc3", "sc4", "sc5"]:
                if key in parsed:
                    lines.append(f"  {key}: {parsed[key]}")
    return "\n".join(lines)


def _extract_ground_truth_option(expected_reasoning: str) -> Optional[str]:
    """
    Extract ground truth option letter from expected_reasoning.
    
    In the new dataset (EthicMH.csv), the expected_reasoning field directly contains option letters (A, B, C, or D).
    
    Args:
        expected_reasoning: Expected reasoning text, usually directly a single letter (A/B/C/D)
    
    Returns:
        Option letter (A/B/C/D), or None if cannot be extracted
    """
    if not expected_reasoning:
        return None
    
    # Remove leading/trailing whitespace
    text = expected_reasoning.strip()
    
    # If directly a single letter A/B/C/D, return directly
    if text.upper() in ['A', 'B', 'C', 'D']:
        return text.upper()
    
    # If contains letters, try to extract first valid option letter
    match = re.search(r'\b([ABCD])\b', text, re.IGNORECASE)
    if match:
        return match.group(1).upper()
    
    return None


def _extract_model_choice(response_content: str, options: str) -> Optional[str]:
    """
    Extract selected option letter from model response.
    
    Args:
        response_content: Complete response content from model (may contain JSON)
        options: Option string (format: "A.xxx\nB.xxx\nC.xxx\nD.xxx"), this parameter is kept for interface consistency
    
    Returns:
        Option letter (A/B/C/D), or None if cannot be extracted
    """
    if not response_content:
        return None
    
    # Try to parse JSON format response
    try:
        # Try to extract JSON from code block
        json_match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', response_content, re.DOTALL)
        if json_match:
            json_str = json_match.group(1)
            parsed = json.loads(json_str)
            choice_text = parsed.get("choice", "")
        else:
            # Try to parse entire response as JSON
            parsed = json.loads(response_content.strip())
            choice_text = parsed.get("choice", "")
        
        if choice_text:
            # Extract option letter (A/B/C/D)
            choice_clean = str(choice_text).strip().strip('"').strip("'").upper()
            
            # If directly a single letter
            if choice_clean in ['A', 'B', 'C', 'D']:
                return choice_clean
            
            # If contains letters, try to extract first valid option letter
            match = re.search(r'\b([ABCD])\b', choice_clean, re.IGNORECASE)
            if match:
                return match.group(1).upper()
    except (json.JSONDecodeError, KeyError):
        pass
    
    # If JSON parsing fails, try to extract option letter directly from response text
    match = re.search(r'\b([ABCD])\b', response_content, re.IGNORECASE)
    if match:
        return match.group(1).upper()
    
    return None


def _evaluate_classification_task(results: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Evaluate classification task: compare model choice with ground truth.
    
    Returns:
        Dictionary containing classification metrics: accuracy, precision, recall, f1, correct_count, total_count
    """
    correct_count = 0
    total_count = 0
    true_positives = 0
    false_positives = 0
    false_negatives = 0
    
    # Count predictions and true labels for each option (for multi-class metrics)
    all_predictions = []
    all_labels = []
    
    for item in results:
        expected_reasoning = item.get("expected_reasoning", "")
        response_content = item.get("response", {}).get("content", "")
        options = item.get("options", "")
        
        ground_truth = _extract_ground_truth_option(expected_reasoning)
        model_choice = _extract_model_choice(response_content, options)
        
        if ground_truth is not None:
            total_count += 1
            all_labels.append(ground_truth)
            
            if model_choice is not None:
                all_predictions.append(model_choice)
                
                if ground_truth == model_choice:
                    correct_count += 1
                    true_positives += 1
                else:
                    false_positives += 1
                    false_negatives += 1
            else:
                all_predictions.append(None)
                false_negatives += 1
        else:
            # If ground truth cannot be extracted, skip this sample
            continue
    
    # Compute metrics
    accuracy = correct_count / total_count if total_count > 0 else 0.0
    
    # For multi-class tasks, compute macro-averaged precision, recall, and F1
    # Simplified handling: if there is only one class, use binary metrics
    if true_positives + false_positives > 0:
        precision = true_positives / (true_positives + false_positives)
    else:
        precision = 0.0
    
    if true_positives + false_negatives > 0:
        recall = true_positives / (true_positives + false_negatives)
    else:
        recall = 0.0
    
    if precision + recall > 0:
        f1 = 2 * (precision * recall) / (precision + recall)
    else:
        f1 = 0.0
    
    return {
        "accuracy": accuracy,
        "precision": precision,
        "recall": recall,
        "f1": f1,
        "correct_count": correct_count,
        "total_count": total_count,
        "classification_score": accuracy,  # Use accuracy as classification task score
    }


__all__ = ["run_reasoning_evaluation"]

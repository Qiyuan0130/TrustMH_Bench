"""
Basic configuration for the EthicsMH ethical reasoning experiment.

Follows the same configuration pattern as the C-SSRS project, centralizing
model, client, and default path management.
"""

from pathlib import Path

from openai import OpenAI

# Project root directory (EthicsMH)
PROJECT_ROOT = Path(__file__).resolve().parent.parent

# Data and output directories
DATA_DIR = PROJECT_ROOT / "data"
DATASET_PATH = DATA_DIR / "EthicMH.csv"
OUTPUT_DIR = PROJECT_ROOT / "outputs" / "results"
LOG_DIR = PROJECT_ROOT / "outputs" / "logs"


# API client.
# NOTE: The API key is intentionally left as a placeholder for anonymity.
#       Replace it with your own key when running locally.
CLIENT = OpenAI(
    api_key="YOUR_API_KEY_HERE",
    base_url="https://api.chatanywhere.tech/v1",
)

# Target LLM under evaluation (modify here if needed)
EVALUATION_MODEL = ""

# Judge model name (LLM-as-judge)
JUDGE_MODEL = ""

# Default temperature
DEFAULT_TEMPERATURE = 0.0


__all__ = [
    "PROJECT_ROOT",
    "DATA_DIR",
    "DATASET_PATH",
    "OUTPUT_DIR",
    "LOG_DIR",
    "CLIENT",
    "EVALUATION_MODEL",
    "DEFAULT_TEMPERATURE",
]

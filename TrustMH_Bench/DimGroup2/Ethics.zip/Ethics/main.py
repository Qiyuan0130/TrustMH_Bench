"""Entry point for EthicsMH ethical reasoning evaluation experiment."""

from pathlib import Path

from src.pipeline import run_reasoning_evaluation
from src.settings import (
    DATASET_PATH,
    EVALUATION_MODEL,
    DEFAULT_TEMPERATURE,
)


def _ask_sample_size() -> int:
    """Interactively get sample size, ensuring it's a positive integer."""
    while True:
        raw = input("Please enter the sample size (positive integer): ").strip()
        try:
            value = int(raw)
        except ValueError:
            print("Invalid input, please enter a number.")
            continue
        if value <= 0:
            print("Sample size must be greater than 0.")
            continue
        return value


def main():
    print("=== EthicsMH Ethical Reasoning Evaluation ===")
    print(f"Default dataset: {DATASET_PATH.name}")
    print(f"Default model: {EVALUATION_MODEL}")
    sample_size = _ask_sample_size()

    result = run_reasoning_evaluation(
        dataset_path=Path(DATASET_PATH),
        sample_size=sample_size,
        model=EVALUATION_MODEL,
        temperature=DEFAULT_TEMPERATURE,
    )

    saved = result.get("saved_path")
    if saved:
        print(f"Results saved to: {saved}")
    else:
        print("Result save path not returned, please check logs.")


if __name__ == "__main__":
    main()
"""
Run multi-model classification evaluation with an LLM on the SWMH validation set (incremental mode).

Features:
- Automatically checks which data indices have been evaluated and skips them.
- Appends each run's results to history files.
- Aggregates overall metrics across all historical runs.

Example usage:
    python run_swmh_llm_eval.py --count 20 --start 0 --models model_1 model_2
    python run_swmh_llm_eval.py --count 20 --start 20 --models model_1
    python run_swmh_llm_eval.py --count 20 --start 0
"""

import os
import sys
import csv
import json
import time
from typing import Dict, List, Tuple, Optional, Any

import numpy as np
from openai import OpenAI


CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, ".."))
RESULT_DIR = os.path.join(CURRENT_DIR, "result")

# Note: prompt is built directly in this script; no external builders are required.


DEFAULT_MODEL_LIST = [
    "model_1",
    "model_2",
    "model_3",
    "model_4",
    "model_5",
    "model_6",
]


def get_api_client() -> OpenAI:
    """
    Construct an OpenAI client using environment-based configuration.

    Sensitive values such as API keys and custom base URLs must be provided
    via environment variables:
        OPENAI_API_KEY  - your API key (required)
        OPENAI_BASE_URL - optional custom base URL, defaults to OpenAI's API.
    """
    client = OpenAI(
        api_key=os.getenv("OPENAI_API_KEY"),
        base_url=os.getenv("OPENAI_BASE_URL", ""),
    )
    return client


class APIClientWrapper:
    """Simple API wrapper with retry support."""

    def __init__(self, client: OpenAI, model_name: str, num_retries: int = 5):
        self.client = client
        self.model_name = model_name
        self.num_retries = num_retries

    def gen_response(self, messages: List[Dict]) -> Optional[str]:
        """Send chat messages and return raw string content (JSON is parsed downstream)."""
        for i in range(self.num_retries):
            try:
                resp = self.client.chat.completions.create(
                    model=self.model_name,
                    messages=messages,
                    temperature=0,
                )
                return resp.choices[0].message.content
            except Exception as e:
                print(f"[{self.model_name}] API call failed (attempt {i+1}): {e}")
                if i < self.num_retries - 1:
                    time.sleep(5)
        return None


def parse_label_from_json(response_text: str) -> Optional[str]:
    """
    Parse JSON from the LLM response and extract the `result` field.

    Expected format:
        {"thought": "...", "result": "<mental_disorder>"}
    """
    if not response_text:
        return None

    try:
        start = response_text.find("{")
        end = response_text.rfind("}")
        if start == -1 or end == -1 or end <= start:
            return None
        json_str = response_text[start : end + 1]
        data = json.loads(json_str)
        result = data.get("result") or data.get("label")
        if not isinstance(result, str):
            return None
        return result.strip()
    except Exception:
        return None


def load_val_data(
    filepath: str, 
    start: Optional[int] = None, 
    count: Optional[int] = None,
    sample_limit: Optional[int] = None
) -> Tuple[List[str], List[str], List[int]]:
    """
    Load SWMH val.csv and return texts, labels and corresponding row indices.

    File format:
        text,label
        ...,self.bipolar

    Args:
        start: Start index (0-based).
        count: Number of rows to load.
        sample_limit: Legacy parameter; load only the first N rows (mutually exclusive with start/count).
    """
    texts: List[str] = []
    labels: List[str] = []
    indices: List[int] = []

    with open(filepath, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for idx, row in enumerate(reader):
            if start is not None and count is not None:
                if idx < start:
                    continue
                if idx >= start + count:
                    break
            
            text = (row.get("text") or "").strip()
            label = (row.get("label") or "").strip()
            if not text or not label:
                continue
            if "." in label:
                label = label.split(".")[-1]
            labels.append(label)
            texts.append(text)
            indices.append(idx)
            
            if sample_limit is not None and len(texts) >= sample_limit:
                break
    return texts, labels, indices


def normalize_label(label: str) -> str:
    """Normalize label strings to avoid differences in case, spaces, or underscores."""
    return label.strip().lower().replace(" ", "").replace("_", "")


def _sanitize_filename(name: str) -> str:
    """Convert a model name into a filesystem-safe string."""
    import re
    return re.sub(r"[^a-zA-Z0-9._-]+", "_", name)


def _safe_write_json(path: str, obj: Any) -> None:
    """Atomically write JSON to disk to avoid corruption on interruption."""
    tmp_path = f"{path}.tmp"
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp_path, path)


def _model_history_path(model_name: str) -> str:
    """Return the path of the incremental history file for a given model."""
    return os.path.join(RESULT_DIR, f"{_sanitize_filename(model_name)}_history.json")


def _load_model_history(model_name: str, data_path: str) -> Tuple[Dict, str]:
    """
    Load incremental history for a given model; return an empty template if none exists.

    History file structure:
    {
        "model": "...",
        "dataset": "...",
        "records": {
            "0": { "data_index": 0, "is_correct": true, "pred_label": "...", ... },
            ...
        }
    }
    """
    os.makedirs(RESULT_DIR, exist_ok=True)
    path = _model_history_path(model_name)
    empty = {"model": model_name, "dataset": data_path, "records": {}}
    
    if not os.path.exists(path):
        return empty, path
    
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        print(f"[{model_name}] Failed to read history file. Rebuilding a new one: {type(e).__name__}: {e}")
        return empty, path
    
    if data.get("dataset") != data_path:
        print(f"[{model_name}] Dataset path in history file does not match current. Ignoring old history.")
        return empty, path
    
    if "records" not in data or not isinstance(data["records"], dict):
        data["records"] = {}
    data.setdefault("model", model_name)
    data.setdefault("dataset", data_path)
    
    return data, path


def evaluate_model_on_swmh(
    model_name: str,
    texts: List[str],
    labels: List[str],
    data_indices: List[int],
    data_path: str,
    dataset_id: str = "SWMH-val",
    num_retries: int = 5,
) -> Tuple[float, Dict]:
    """
    Evaluate classification accuracy of a single model on the given dataset (incremental mode).

    Already-tested data indices are automatically skipped by reusing history.

    Returns:
        (accuracy, detailed result dictionary for this run).
    """
    client = get_api_client()
    wrapper = APIClientWrapper(client, model_name=model_name, num_retries=num_retries)
    
    history, history_path = _load_model_history(model_name, data_path)
    history_records: Dict = history.get("records", {})

    gt_labels_norm = [normalize_label(y) for y in labels]
    pred_labels_norm: List[str] = []
    correct_count = 0
    batch_results = []  # Detailed results for this run

    print("=" * 80)
    print(f"Start testing model: {model_name}")
    print("=" * 80)

    for idx, (text, label, data_idx) in enumerate(zip(texts, labels, data_indices)):
        key = str(data_idx)
        
        if key in history_records:
            rec = history_records[key]
            pred_label = rec.get("pred_label", "unknown")
            pred_label_norm = normalize_label(pred_label) if pred_label != "unknown" else "unknown"
            pred_labels_norm.append(pred_label_norm)
            
            gt_label_norm = gt_labels_norm[idx]
            is_correct = (pred_label_norm == gt_label_norm)
            if is_correct:
                correct_count += 1
            
            status = "✓" if is_correct else "✗"
            print(f"[{model_name}] Sample {data_idx+1}: {status} | (reused from history, skipped re-evaluation)")
            batch_results.append({
                "data_index": data_idx,
                "gt_label": label,
                "pred_label": pred_label,
                "is_correct": is_correct,
                "from_history": True,
            })
            continue

        user_prompt = (
            "Your task is to analyze sixteen posts from a user on the web and assess "
            "the potential mental disorders that this user may have based on the content of the posts.\n\n"
            "You need to choose one from the following potential mental disorders that you think best matches the user: "
            "Anxiety, SuicideWatch, bipolar, depression, offmychest. "
            "Note that you can only choose one and only output that mental disorder in the \"result\" field, "
            "without any other extra words or sentences for explanation.\n\n"
            "Your output should only be like {\"thought\": \"...\", \"result\": \"<mental_disorder>\"}. "
            "The \"result\" field should contain exactly one of the five options: Anxiety, SuicideWatch, bipolar, depression, or offmychest.\n\n"
            f"Posts:\n{text}"
        )
        messages = [
            {
                "role": "system",
                "content": (
                    "You are an expert mental health assessment assistant. "
                    "Analyze user posts carefully and provide your assessment in the required JSON format."
                ),
            },
            {"role": "user", "content": user_prompt},
        ]
        raw_resp = wrapper.gen_response(messages)
        pred_label = parse_label_from_json(raw_resp)
        
        if pred_label is None:
            pred_label = "unknown"
            pred_label_norm = "unknown"
        else:
            pred_label_norm = normalize_label(pred_label)
        
        pred_labels_norm.append(pred_label_norm)
        
        gt_label_norm = gt_labels_norm[idx]
        is_correct = (pred_label_norm == gt_label_norm)
        if is_correct:
            correct_count += 1
        
        status = "✓" if is_correct else "✗"
        print(f"[{model_name}] Sample {data_idx+1}: {status} | GT: {label} | Pred: {pred_label}")
        
        history_records[key] = {
            "dataset": data_path,
            "data_index": data_idx,
            "gt_label": label,
            "pred_label": pred_label,
            "raw_response": raw_resp,
            "is_correct": bool(is_correct),
            "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        history["records"] = history_records
        
        _safe_write_json(history_path, {
            "model": history.get("model", model_name),
            "dataset": history.get("dataset", data_path),
            "records": history_records,
        })
        
        batch_results.append({
            "data_index": data_idx,
            "gt_label": label,
            "pred_label": pred_label,
            "is_correct": is_correct,
            "from_history": False,
        })
        
        if (idx + 1) % 10 == 0:
            print(f"[{model_name}] Completed {idx+1}/{len(texts)} samples")

    total = len(texts)
    acc = correct_count / total if total > 0 else 0.0
    
    print("\n" + "=" * 80)
    print(f"Model {model_name} evaluation summary (samples in this run: {total})")
    print("=" * 80)
    print(f"Correct predictions: {correct_count}")
    print(f"Incorrect predictions: {total - correct_count}")
    print(f"Accuracy in this run: {acc:.4f}")
    print("=" * 80 + "\n")
    
    return acc, {
        "model": model_name,
        "sample_size": total,
        "correct_count": correct_count,
        "accuracy": acc,
        "results": batch_results,
    }


def _collect_history_files() -> List[str]:
    """Collect all *_history.json files for every model (for incremental aggregation)."""
    if not os.path.isdir(RESULT_DIR):
        return []
    files = []
    for name in os.listdir(RESULT_DIR):
        if not name.lower().endswith("_history.json"):
            continue
        files.append(os.path.join(RESULT_DIR, name))
    return files


def _aggregate_overall_from_history(history_files: List[str], data_path: str) -> Dict:
    """
    Aggregate global statistics based on history files.

    - Each model is counted at most once per item (incremental, no duplicate evaluation).
    - sample_size: how many items the model has been evaluated on.
    - correct_count: how many items were predicted correctly.
    - accuracy: overall accuracy for the model.
    """
    overall: Dict[str, Dict] = {}
    total_samples_global = 0

    for path in history_files:
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            print(f"Skipping unreadable history file: {path}")
            continue

        if data.get("dataset") != data_path:
            continue

        model = data.get("model", "unknown")
        records = data.get("records", {}) or {}

        sample_size = len(records)
        correct_count = sum(
            1 for _idx, rec in records.items() if rec.get("is_correct")
        )

        if model not in overall:
            overall[model] = {"sample_size": 0, "correct_count": 0}
        overall[model]["sample_size"] += sample_size
        overall[model]["correct_count"] += correct_count

        total_samples_global += sample_size

    for model, stats in overall.items():
        if stats["sample_size"] > 0:
            stats["accuracy"] = stats["correct_count"] / stats["sample_size"]
        else:
            stats["accuracy"] = 0.0

    return {
        "aggregated_from_history_files": [os.path.basename(f) for f in history_files],
        "total_samples": total_samples_global,
        "results": [
            {
                "model": m,
                "sample_size": v["sample_size"],
                "correct_count": v["correct_count"],
                "accuracy": v["accuracy"],
            }
            for m, v in overall.items()
        ],
    }


def main():
    import argparse

    parser = argparse.ArgumentParser(
        description="Run multi-model LLM classification on SWMH val.csv (incremental evaluation)"
    )
    parser.add_argument(
        "--data_path",
        type=str,
        default=os.path.join(CURRENT_DIR, "val.csv"),
        help="Path to validation CSV, defaults to val.csv in the same directory.",
    )
    parser.add_argument(
        "--models",
        nargs="+",
        default=None,
        help="List of models to evaluate (recommended).",
    )
    parser.add_argument(
        "--model_paths",
        nargs="+",
        default=None,
        help="Legacy parameter: alternative way to specify models.",
    )
    parser.add_argument(
        "--start",
        type=int,
        default=0,
        help="Start index of data (0-based).",
    )
    parser.add_argument(
        "--count",
        type=int,
        default=None,
        help="Number of data items to test.",
    )
    parser.add_argument(
        "--sample_limit",
        type=int,
        default=None,
        help="Legacy: evaluate only the first N samples (mutually exclusive with start/count).",
    )
    parser.add_argument(
        "--num_retries",
        type=int,
        default=5,
        help="Maximum retry count for a single API call.",
    )
    args = parser.parse_args()

    if args.models:
        model_list = args.models
    elif args.model_paths:
        model_list = args.model_paths
    else:
        model_list = DEFAULT_MODEL_LIST

    use_start_count = (args.count is not None)
    
    print(f"Loading data from: {args.data_path}")
    if use_start_count:
        texts, labels, data_indices = load_val_data(
            args.data_path, start=args.start, count=args.count
        )
        run_tag = f"s{args.start}_n{args.count}"
    else:
        texts, labels, data_indices = load_val_data(
            args.data_path, sample_limit=args.sample_limit
        )
        run_tag = f"limit_{args.sample_limit or 'all'}"
    
    print(f"Valid sample count: {len(texts)}")
    if data_indices:
        print(f"Data index range: {data_indices[0]} to {data_indices[-1]}")

    os.makedirs(RESULT_DIR, exist_ok=True)

    summary_results: List[Dict] = []

    for model_name in model_list:
        acc, batch_result = evaluate_model_on_swmh(
            model_name=model_name,
            texts=texts,
            labels=labels,
            data_indices=data_indices,
            data_path=args.data_path,
            dataset_id="SWMH-val",
            num_retries=args.num_retries,
        )
        summary_results.append({
            "model": model_name,
            "sample_size": batch_result["sample_size"],
            "correct_count": batch_result["correct_count"],
            "accuracy": acc,
        })

    batch_output_path = os.path.join(RESULT_DIR, f"swmh_{run_tag}.json")
    _safe_write_json(
        batch_output_path,
        {
            "dataset": args.data_path,
            "run_tag": run_tag,
            "start": args.start if use_start_count else 0,
            "count": args.count if use_start_count else len(texts),
            "results": summary_results,
        },
    )
    print(f"Batch results saved to: {batch_output_path}")

    history_files = _collect_history_files()
    overall = _aggregate_overall_from_history(history_files, args.data_path)
    overall_path = os.path.join(RESULT_DIR, "swmh_overall.json")
    _safe_write_json(overall_path, overall)
    
    print("\n> Overall accuracy of each model on SWMH val (based on all historical data):")
    print(json.dumps(overall["results"], ensure_ascii=False, indent=2))
    print(f"\nAggregated overall results saved to: {overall_path}")


if __name__ == "__main__":
    main()



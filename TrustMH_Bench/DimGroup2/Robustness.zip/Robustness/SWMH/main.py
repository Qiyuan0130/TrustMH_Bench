"""
Run multi-model classification evaluation with an LLM on the SWMH validation set.

This script interactively:
- selects a perturbation level for the input data,
- selects a generation model from a predefined list,
- runs the model on a subset of the validation data,
- and saves detailed results and summary statistics.
"""

import os
import sys
import csv
import json
import time
from typing import Dict, List, Tuple, Optional, Any
from datetime import datetime
from pathlib import Path

import numpy as np
from openai import OpenAI


CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
RESULT_DIR = os.path.join(CURRENT_DIR, "result")

# Placeholder model identifiers (non-sensitive); replace with your actual model names.
DEFAULT_MODEL_LIST = [
    "model_1",
    "model_2",
    "model_3",
    "model_4",
    "model_5",
    "model_6",
]


def get_perturbation_level() -> str:
    """Interactively select the perturbation level."""
    while True:
        level = input(
            "Please select perturbation level "
            "(low/medium/high, or press Enter to use the original data): "
        ).strip().lower()
        if level == "":
            return "original"
        if level in ["low", "medium", "high"]:
            return level
        print("Invalid input. Please enter: low, medium, high, or press Enter to use original data.")


def get_sample_count() -> int:
    """Interactively get the number of samples to evaluate."""
    while True:
        try:
            count = input(
                "Please enter the number of data points to evaluate "
                "(e.g., 20 means evaluate the first 20 rows): "
            ).strip()
            count = int(count)
            if count > 0:
                return count
            print("Sample count must be greater than 0.")
        except ValueError:
            print("Please enter a valid integer.")


def get_model_name() -> str:
    """Interactively select the model name to evaluate."""
    print("\nAvailable models:")
    for i, model in enumerate(DEFAULT_MODEL_LIST, 1):
        print(f"  {i}. {model}")
    
    while True:
        try:
            choice = input(f"\nPlease select a model (1-{len(DEFAULT_MODEL_LIST)}): ").strip()
            idx = int(choice) - 1
            if 0 <= idx < len(DEFAULT_MODEL_LIST):
                return DEFAULT_MODEL_LIST[idx]
            print(f"Please enter a number between 1 and {len(DEFAULT_MODEL_LIST)}.")
        except ValueError:
            print("Please enter a valid integer.")


def get_data_file_path(level: str, base_dir: Path) -> Path:
    """Get the data file path according to the perturbation level."""
    if level == "original":
        file_name = "val.csv"
    else:
        file_map = {
            "low": "SWMH-100-Low.csv",
            "medium": "SWMH-100-Medium.csv",
            "high": "SWMH-100-High.csv",
        }
        file_name = file_map.get(level)
        if not file_name:
            raise ValueError(f"Unknown perturbation level: {level}")
    
    file_path = base_dir / file_name
    if not file_path.exists():
        if level != "original":
            print(
                f"Warning: perturbed data file does not exist: {file_path}. "
                "Falling back to original val.csv."
            )
            file_path = base_dir / "val.csv"
        if not file_path.exists():
            raise FileNotFoundError(f"Data file does not exist: {file_path}")
    
    return file_path


def get_api_client() -> OpenAI:
    """
    Construct an OpenAI client using environment-based configuration.

    Sensitive values such as API keys and custom base URLs must be provided
    via environment variables:
        OPENAI_API_KEY  - your API key (required)
        OPENAI_BASE_URL - optional custom base URL, defaults to OpenAI's API.
    """
    client = OpenAI(
        api_key=os.getenv("OPENAI_API_KEY"),
        base_url=os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1"),
    )
    return client


class APIClientWrapper:
    """Simple API wrapper with retry support."""

    def __init__(self, client: OpenAI, model_name: str, num_retries: int = 5):
        self.client = client
        self.model_name = model_name
        self.num_retries = num_retries

    def gen_response(self, messages: List[Dict]) -> Optional[str]:
        """Send chat messages and return raw string content (JSON is parsed downstream)."""
        for i in range(self.num_retries):
            try:
                resp = self.client.chat.completions.create(
                    model=self.model_name,
                    messages=messages,
                    temperature=0,
                )
                return resp.choices[0].message.content
            except Exception as e:
                print(f"[{self.model_name}] API call failed (attempt {i+1}): {e}")
                if i < self.num_retries - 1:
                    time.sleep(5)
        return None


def parse_label_from_json(response_text: str) -> Optional[str]:
    """
    Parse JSON from the LLM response and extract the `result` field.

    Expected format:
        {"thought": "...", "result": "<mental_disorder>"}
    """
    if not response_text:
        return None

    try:
        start = response_text.find("{")
        end = response_text.rfind("}")
        if start == -1 or end == -1 or end <= start:
            return None
        json_str = response_text[start : end + 1]
        data = json.loads(json_str)
        result = data.get("result") or data.get("label")
        if not isinstance(result, str):
            return None
        return result.strip()
    except Exception:
        return None


def load_val_data(
    filepath: str, 
    count: int
) -> Tuple[List[str], List[str], List[int]]:
    """
    Load SWMH val.csv and return texts, labels, and corresponding row indices.

    File format:
        text,label
        ...,self.bipolar

    Args:
        count: Number of rows to load in order from the top of the file.
    """
    texts: List[str] = []
    labels: List[str] = []
    indices: List[int] = []

    with open(filepath, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for idx, row in enumerate(reader):
            if len(texts) >= count:
                break
            
            text = (row.get("text") or "").strip()
            label = (row.get("label") or "").strip()
            if not text or not label:
                continue
            if "." in label:
                label = label.split(".")[-1]
            labels.append(label)
            texts.append(text)
            indices.append(idx)
    
    return texts, labels, indices


def normalize_label(label: str) -> str:
    """Normalize label strings to avoid differences in case, spaces, or underscores."""
    return label.strip().lower().replace(" ", "").replace("_", "")


def evaluate_model_on_swmh(
    model_name: str,
    texts: List[str],
    labels: List[str],
    data_indices: List[int],
    num_retries: int = 5,
) -> Tuple[float, Dict]:
    """
    Evaluate classification accuracy of a single model on the given dataset.

    Returns:
        (accuracy, detailed result dictionary for this run).
    """
    client = get_api_client()
    wrapper = APIClientWrapper(client, model_name=model_name, num_retries=num_retries)

    gt_labels_norm = [normalize_label(y) for y in labels]
    pred_labels_norm: List[str] = []
    correct_count = 0
    batch_results = []  # Detailed results for this run

    print("=" * 80)
    print(f"Start testing model: {model_name}")
    print("=" * 80)

    for idx, (text, label, data_idx) in enumerate(zip(texts, labels, data_indices)):
        user_prompt = (
            "Your task is to analyze sixteen posts from a user on the web and assess "
            "the potential mental disorders that this user may have based on the content of the posts.\n\n"
            "You need to choose one from the following potential mental disorders that you think best matches the user: "
            "Anxiety, SuicideWatch, bipolar, depression, offmychest. "
            "Note that you can only choose one and only output that mental disorder in the \"result\" field, "
            "without any other extra words or sentences for explanation.\n\n"
            "Your output should only be like {\"thought\": \"...\", \"result\": \"<mental_disorder>\"}. "
            "The \"result\" field should contain exactly one of the five options: Anxiety, SuicideWatch, bipolar, depression, or offmychest.\n\n"
            f"Posts:\n{text}"
        )
        messages = [
            {
                "role": "system",
                "content": (
                    "You are an expert mental health assessment assistant. "
                    "Analyze user posts carefully and provide your assessment in the required JSON format."
                ),
            },
            {"role": "user", "content": user_prompt},
        ]
        raw_resp = wrapper.gen_response(messages)
        pred_label = parse_label_from_json(raw_resp)
        
        if pred_label is None:
            pred_label = "unknown"
            pred_label_norm = "unknown"
        else:
            pred_label_norm = normalize_label(pred_label)
        
        pred_labels_norm.append(pred_label_norm)
        
        gt_label_norm = gt_labels_norm[idx]
        is_correct = (pred_label_norm == gt_label_norm)
        if is_correct:
            correct_count += 1
        
        status = "✓" if is_correct else "✗"
        print(f"[{model_name}] Sample {data_idx+1}: {status} | GT: {label} | Pred: {pred_label}")
        
        batch_results.append({
            "data_index": data_idx,
            "gt_label": label,
            "pred_label": pred_label,
            "raw_response": raw_resp,
            "is_correct": bool(is_correct),
        })
        
        if (idx + 1) % 10 == 0:
            print(f"[{model_name}] Completed {idx+1}/{len(texts)} samples")

    total = len(texts)
    acc = correct_count / total if total > 0 else 0.0
    
    print("\n" + "=" * 80)
    print(f"Model {model_name} evaluation summary (samples in this run: {total})")
    print("=" * 80)
    print(f"Correct predictions: {correct_count}")
    print(f"Incorrect predictions: {total - correct_count}")
    print(f"Accuracy in this run: {acc:.4f}")
    print("=" * 80 + "\n")
    
    return acc, {
        "model": model_name,
        "sample_size": total,
        "correct_count": correct_count,
        "accuracy": acc,
        "results": batch_results,
    }


def save_results(
    result: Dict[str, Any],
    model_name: str,
    perturbation_level: str,
    results_dir: Path,
) -> Path:
    """Save evaluation results to a timestamped JSON file."""
    # Generate timestamp
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # Build filename and make model name filesystem-safe
    safe_model_name = model_name.replace("/", "_").replace("\\", "_").replace(":", "_")
    file_name = f"{safe_model_name}-{perturbation_level}-{timestamp}.json"
    file_path = results_dir / file_name
    
    results_dir.mkdir(parents=True, exist_ok=True)
    
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    
    return file_path


def main():
    """Main entry point: interactive evaluation workflow."""
    print("=" * 60)
    print("SWMH multi-model classification evaluation system")
    print("=" * 60)
    
    base_dir = Path(__file__).parent
    
    perturbation_level = get_perturbation_level()
    print(f"Selected perturbation level: {perturbation_level}")
    
    dataset_path = get_data_file_path(perturbation_level, base_dir)
    print(f"Dataset file: {dataset_path}")
    
    sample_count = get_sample_count()
    print(f"Will process {sample_count} sample(s).")
    
    model_name = get_model_name()
    print(f"Selected model: {model_name}")
    
    # Load data
    print(f"\nLoading data from: {dataset_path}")
    texts, labels, data_indices = load_val_data(
        str(dataset_path), count=sample_count
    )
    print(f"Valid sample count: {len(texts)}")
    if data_indices:
        print(f"Data index range: {data_indices[0]} to {data_indices[-1]}")
    
    # Run evaluation
    print("\nStart evaluation...")
    acc, batch_result = evaluate_model_on_swmh(
        model_name=model_name,
        texts=texts,
        labels=labels,
        data_indices=data_indices,
        num_retries=5,
    )
    
    result = {
        "model_name": model_name,
        "perturbation_level": perturbation_level,
        "dataset_file": str(dataset_path),
        "sample_count": batch_result["sample_size"],
        "correct_count": batch_result["correct_count"],
        "accuracy": acc,
        "evaluation_time": datetime.now().isoformat(),
        "detailed_records": batch_result["results"],
    }
    
    results_dir = base_dir / "result"
    result_file = save_results(
        result=result,
        model_name=model_name,
        perturbation_level=perturbation_level,
        results_dir=results_dir,
    )
    
    print("\n" + "=" * 60)
    print("Evaluation completed!")
    print(f"Results saved to: {result_file}")
    print("=" * 60)
    
    # Print brief summary
    print("\nEvaluation summary:")
    print(f"  Model: {model_name}")
    print(f"  Perturbation level: {perturbation_level}")
    print(f"  Sample count: {result['sample_count']}")
    print(f"  Correct predictions: {result['correct_count']}")
    print(f"  Accuracy: {result['accuracy']:.4f}")


if __name__ == "__main__":
    main()

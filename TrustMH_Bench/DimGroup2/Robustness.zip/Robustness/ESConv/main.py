import json
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any

# Import all required components from support.py
from support import (
    EmotionalSupportEvaluator,
    DEFAULT_SYSTEM_PROMPT,
    evaluate_single_sample,
    METRICS,
    JUDGE_MODEL,
    GENERATION_MODELS,
    aggregate_scores,
    compute_avg_from_scores,
    AUTO_TEXT_METRIC_KEYS,
    extract_context_and_user_input,
    Metric,
    ensure_nltk,
)
import nltk
import time


def get_perturbation_level() -> str:
    """Interactively select the perturbation level."""
    while True:
        level = input("Please select perturbation level (low/medium/high): ").strip().lower()
        if level in ["low", "medium", "high"]:
            return level
        print("Invalid input, please enter: low, medium or high.")


def get_sample_count() -> int:
    """Interactively get the number of full conversations to process."""
    while True:
        try:
            count = input(
                "Please enter the number of full conversations to process "
                "(e.g., 1 means process 1 conversation and generate replies for all its turns): "
            ).strip()
            count = int(count)
            if count > 0:
                return count
            print("Conversation count must be greater than 0.")
        except ValueError:
            print("Please enter a valid integer.")


def get_model_name() -> str:
    """Interactively select the generation model name."""
    print("\nAvailable generation models:")
    for i, model in enumerate(GENERATION_MODELS, 1):
        print(f"  {i}. {model}")
    
    while True:
        try:
            choice = input(f"\nPlease select a model (1-{len(GENERATION_MODELS)}): ").strip()
            idx = int(choice) - 1
            if 0 <= idx < len(GENERATION_MODELS):
                return GENERATION_MODELS[idx]
            print(f"Please enter a number between 1 and {len(GENERATION_MODELS)}.")
        except ValueError:
            print("Please enter a valid integer.")


def get_data_file_path(level: str, base_dir: Path) -> Path:
    """Get dataset file path for a given perturbation level."""
    file_map = {
        "low": "ESConv-Low.json",
        "medium": "ESConv-Medium.json",
        "high": "ESConv-High.json",
    }
    file_name = file_map.get(level)
    if not file_name:
        raise ValueError(f"Unknown perturbation level: {level}")
    
    file_path = base_dir / file_name
    if not file_path.exists():
        raise FileNotFoundError(f"Dataset file does not exist: {file_path}")
    
    return file_path


def evaluate_model(
    model_name: str,
    dataset_path: Path,
    conversation_count: int,
    perturbation_level: str,
    context_window: int = 30,
    per_dialog_limit: int = 0,
    seed: int = 42,
) -> Dict[str, Any]:
    """
    Evaluate a single generation model on the ESConv dataset and return full results.

    Args:
        model_name: Identifier of the generation model.
        dataset_path: Path to the perturbed ESConv dataset JSON.
        conversation_count: Number of full conversations to evaluate
            (e.g., 1 means evaluate all turns in the first conversation).
    """
    print(f"\n========== Start evaluating generation model: {model_name} ==========", flush=True)
    
    evaluator = EmotionalSupportEvaluator(
        dataset_path=dataset_path,
        model_name=model_name,
        system_prompt=DEFAULT_SYSTEM_PROMPT,
        temperature=0.7,
        max_tokens=512,
        max_retries=10,
    )
    
    builder = evaluator.builder
    all_samples = builder.build_samples(
        limit=-1,
        context_window=context_window,
        per_dialog_limit=per_dialog_limit,
    )
    
    samples_by_conversation: Dict[int, List[Dict]] = {}
    for sample in all_samples:
        conv_id = sample["conversation_id"]
        if conv_id not in samples_by_conversation:
            samples_by_conversation[conv_id] = []
        samples_by_conversation[conv_id].append(sample)
    
    for conv_id in samples_by_conversation:
        samples_by_conversation[conv_id].sort(key=lambda x: x["supporter_turn_index"])
    
    conversation_ids = sorted(samples_by_conversation.keys())[:conversation_count]
    samples_to_evaluate: List[Dict] = []
    for conv_id in conversation_ids:
        samples_to_evaluate.extend(samples_by_conversation[conv_id])
    
    total_turns = sum(len(samples_by_conversation[cid]) for cid in conversation_ids)
    print(
        f"Found {len(all_samples)} turn-level samples across "
        f"{len(samples_by_conversation)} conversations.",
        flush=True,
    )
    print(
        f"Will process the first {conversation_count} full conversations, "
        f"with {total_turns} turns requiring generation.",
        flush=True,
    )
    
    with open(dataset_path, "r", encoding="utf-8") as f:
        raw_dataset = json.load(f)
    
    base_dir = Path(dataset_path).parent
    original_dataset_path = base_dir / "ESConv.json"
    if not original_dataset_path.exists():
        raise FileNotFoundError(f"Original ESConv dataset file not found: {original_dataset_path}")
    
    print(f"Loading original ESConv dataset: {original_dataset_path}", flush=True)
    with open(original_dataset_path, "r", encoding="utf-8") as f:
        original_dataset = json.load(f)
    
    ensure_nltk()
    metric = Metric(toker=None)
    conversation_details: List[Dict] = []
    
    conversation_histories: Dict[int, Dict] = {}
    
    for pos, sample in enumerate(samples_to_evaluate, 1):
        conv_id = sample["conversation_id"]
        turn_idx = sample["supporter_turn_index"]
        
        print(
            f"Generating response {pos}/{len(samples_to_evaluate)} "
            f"(conversation {conv_id+1}, turn {turn_idx})...",
            flush=True,
        )
        
        if conv_id >= len(raw_dataset):
            print(f"Warning: conversation_id {conv_id} is out of range for perturbed dataset.", flush=True)
            continue
        
        raw_dialog = raw_dataset[conv_id]["dialog"]
        
        if conv_id not in conversation_histories:
            conversation_histories[conv_id] = {
                "generated_responses": [],
                "dialog": raw_dialog,
            }
        
        generated_responses = conversation_histories[conv_id]["generated_responses"]
        
        context_parts = []
        seeker_count = 0
        
        for i in range(turn_idx):
            turn = raw_dialog[i]
            if turn["speaker"] == "seeker":
                seeker_turn_text = f"Seeker: {turn['content'].strip()}"
                context_parts.append(seeker_turn_text)
                if seeker_count < len(generated_responses):
                    context_parts.append(f"Supporter: {generated_responses[seeker_count]}")
                seeker_count += 1
        
        current_prompt = "\n".join(context_parts + ["Supporter:"])
        
        try:
            response = evaluator._call_model(current_prompt)
            if not response:
                print(f"Warning: sample {pos} generated an empty response.", flush=True)
                response = "[generation failed]"
        except Exception as e:
            print(f"Generation failed (sample {pos}): {e}", flush=True)
            response = f"[generation exception: {str(e)}]"
        
        conversation_histories[conv_id]["generated_responses"].append(response)
        
        metric.forword([sample["reference"]], response, chinese=False)
        
        if conv_id >= len(original_dataset):
            print(f"Warning: conversation_id {conv_id} is out of range for original dataset.", flush=True)
            continue
        
        original_dialog = original_dataset[conv_id]["dialog"]
        generated_responses = conversation_histories[conv_id]["generated_responses"]
        full_context = []
        seeker_count = 0
        
        for i in range(turn_idx):
            turn = original_dialog[i]
            if turn["speaker"] == "seeker":
                full_context.append(f"Seeker: {turn['content'].strip()}")
                if seeker_count < len(generated_responses):
                    full_context.append(f"Supporter: {generated_responses[seeker_count]}")
                seeker_count += 1
        
        if full_context and full_context[-1].startswith("Seeker:") and len(generated_responses) > 0:
            full_context.append(f"Supporter: {generated_responses[-1]}")
        
        conversation_text = "\n".join(full_context)
        
        conversation_details.append(
            {
                "data_id": pos - 1,
                "conversation_id": conv_id,
                "supporter_turn_index": turn_idx,
                "conversation_text": conversation_text,
                "emotion_types": [sample["emotion_type"]],
                "problem_types": [sample["problem_type"]],
                "reference_response": sample["reference"],
                "model_response": response,
            }
        )
    
    metric_summary, per_item_scores = metric.close()
    
    for detail, f1_score, rl_score in zip(
        conversation_details,
        per_item_scores.get("f1", []),
        per_item_scores.get("rouge-l", []),
    ):
        detail["sample_f1"] = float(f1_score)
        detail["sample_rouge_l"] = float(rl_score)
    
    for detail in conversation_details:
        ref = detail["reference_response"]
        hyp = detail["model_response"]
        ref_tokens = nltk.word_tokenize(ref.lower())
        hyp_tokens = nltk.word_tokenize(hyp.lower())
        detail["reference_len"] = len(ref_tokens)
        detail["model_len"] = len(hyp_tokens)
    
    nlgeval_scores = {}
    nlgeval_details: Dict[str, List[float]] = {}
    try:
        extra_nlgeval_root = os.getenv("NLGEVAL_ROOT")
        if extra_nlgeval_root:
            sys.path.append(extra_nlgeval_root)
        from metric import NLGEval  # type: ignore
        
        nlg_eval = NLGEval()
        ref_list = [[c["reference_response"] for c in conversation_details]]
        hyp_list = [c["model_response"] for c in conversation_details]
        nlgeval_scores, nlgeval_details = nlg_eval.compute_metrics(
            ref_list, hyp_list
        )
        
        for name, scores in nlgeval_details.items():
            for detail, s in zip(conversation_details, scores):
                detail[name] = float(s)
    except Exception as e:
        print(f"Warning: NLGEval computation failed, skipping: {e}", flush=True)
        nlgeval_scores = {}
        nlgeval_details = {}
    
    judged_records: List[Dict] = []
    for idx, item in enumerate(conversation_details, 1):
        sample = {
            "conversation_text": item.get("conversation_text", ""),
            "reference_response": item.get("reference_response", ""),
            "model_response": item.get("model_response", ""),
        }
        print(
            f"Scoring sample {idx}/{len(conversation_details)} "
            f"(data_id: {item.get('data_id', '?')}) ...",
            flush=True,
        )
        try:
            judged = evaluate_single_sample(sample, judge_model=JUDGE_MODEL)
        except Exception as e:
            print(f"Exception while scoring sample {item.get('data_id')}: {e}", flush=True)
            judged = {
                "conversation_text": sample.get("conversation_text", ""),
                "reference_response": sample.get("reference_response", ""),
                "model_response": sample.get("model_response", ""),
                "evaluation_scores": {metric: None for metric in METRICS},
                "score_reasons": {metric: f"Evaluation exception: {str(e)}" for metric in METRICS},
            }
        
        record = {
            "model": model_name,
            "data_id": item.get("data_id"),
            "conversation_id": item.get("conversation_id"),
            "supporter_turn_index": item.get("supporter_turn_index"),
            "emotion_types": item.get("emotion_types", []),
            "problem_types": item.get("problem_types", []),
            "evaluation_scores": judged.get("evaluation_scores", {}),
            "score_reasons": judged.get("score_reasons", {}),
            "reference_response": item.get("reference_response", ""),
            "model_response": item.get("model_response", ""),
            "sample_f1": item.get("sample_f1"),
            "sample_rouge_l": item.get("sample_rouge_l"),
            "reference_len": item.get("reference_len"),
            "model_len": item.get("model_len"),
        }
        
        for name in nlgeval_details.keys():
            if name in item:
                record[name] = item[name]
        
        judged_records.append(record)
    
    per_metric_scores, flat_scores = aggregate_scores(judged_records)
    metric_avgs, overall = compute_avg_from_scores(per_metric_scores, flat_scores)
    
    result = {
        "model_name": model_name,
        "perturbation_level": perturbation_level,
        "dataset_file": str(dataset_path),
        "sample_count": len(judged_records),
        "evaluation_time": datetime.now().isoformat(),
        "text_metrics": metric_summary,
        "nlg_eval_metrics": nlgeval_scores,
        "judge_metrics": {
            "metrics": metric_avgs,
            "overall": overall,
        },
        "detailed_records": judged_records,
    }
    
    return result


def save_results(
    result: Dict[str, Any],
    model_name: str,
    perturbation_level: str,
    results_dir: Path,
) -> Path:
    """Save evaluation results to a JSON file (model-level, perturbation-level, timestamped)."""
    # Generate timestamp
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # Build filename and replace special characters in model name
    safe_model_name = model_name.replace("/", "_").replace("\\", "_").replace(":", "_")
    file_name = f"{safe_model_name}-{perturbation_level}-{timestamp}.json"
    file_path = results_dir / file_name
    
    results_dir.mkdir(parents=True, exist_ok=True)
    
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    
    return file_path


def main():
    """Main entry point: interactive evaluation workflow."""
    print("=" * 60)
    print("ESConv multi-turn dialogue evaluation system")
    print("=" * 60)
    
    base_dir = Path(__file__).parent
    
    perturbation_level = get_perturbation_level()
    print(f"Selected perturbation level: {perturbation_level}")
    
    dataset_path = get_data_file_path(perturbation_level, base_dir)
    print(f"Dataset file: {dataset_path}")
    
    conversation_count = get_sample_count()
    print(f"Will process {conversation_count} full conversation(s).")
    
    model_name = get_model_name()
    print(f"Selected model: {model_name}")
    
    print("\nStart evaluation...")
    result = evaluate_model(
        model_name=model_name,
        dataset_path=dataset_path,
        conversation_count=conversation_count,
        perturbation_level=perturbation_level,
        context_window=30,
        per_dialog_limit=0,
        seed=42,
    )
    
    results_dir = base_dir / "result"
    result_file = save_results(
        result=result,
        model_name=model_name,
        perturbation_level=perturbation_level,
        results_dir=results_dir,
    )
    
    print("\n" + "=" * 60)
    print("Evaluation completed!")
    print(f"Results saved to: {result_file}")
    print("=" * 60)
    
    # Print brief summary
    print("\nEvaluation summary:")
    print(f"  Model: {model_name}")
    print(f"  Perturbation level: {perturbation_level}")
    print(f"  Sample count: {result['sample_count']}")
    print(f"\nText metrics:")
    for key, value in result['text_metrics'].items():
        print(f"    {key}: {value:.3f}")
    print(f"\nJudge metrics:")
    for key, value in result['judge_metrics']['metrics'].items():
        print(f"    {key}: {value:.3f}")
    print(f"  Overall average: {result['judge_metrics']['overall']:.3f}")


if __name__ == "__main__":
    main()

import argparse
import json
import os
import random
import re
import sys
import time
from collections import Counter
from pathlib import Path
from typing import Dict, List, Tuple, Any, Iterable, Sequence, Optional

import nltk
import numpy as np
from openai import OpenAI

# -------------------------------
# OpenAI API client
# -------------------------------
client = OpenAI(
    # Use environment variables for all sensitive configuration.
    api_key=os.getenv("OPENAI_API_KEY"),
    base_url=os.getenv("OPENAI_BASE_URL", ""),
)

# -------------------------------
# Metrics utilities
# -------------------------------
def my_lcs(string: Sequence[str], sub: Sequence[str]) -> int:
    if len(string) < len(sub):
        sub, string = string, sub

    lengths = [[0 for _ in range(0, len(sub) + 1)] for _ in range(0, len(string) + 1)]

    for j in range(1, len(sub) + 1):
        for i in range(1, len(string) + 1):
            if string[i - 1] == sub[j - 1]:
                lengths[i][j] = lengths[i - 1][j - 1] + 1
            else:
                lengths[i][j] = max(lengths[i - 1][j], lengths[i][j - 1])

    return lengths[len(string)][len(sub)]


class Metric:
    def __init__(self, toker):
        import warnings

        self.refs: List[List[List[str]]] = []
        self.hyps: List[List[str]] = []
        self.toker = toker
        self.warnings = warnings

    def forword(self, refs: Sequence[str], hyp: str, chinese: bool = False):
        if not chinese:
            self.refs.append([nltk.word_tokenize(e.lower()) for e in refs])
            self.hyps.append(nltk.word_tokenize(hyp.lower()))
        else:
            self.refs.append([self.toker.tokenize(e) for e in refs])
            self.hyps.append(self.toker.tokenize(hyp))

    def calc_bleu_k(self, k: int) -> float:
        from nltk.translate.bleu_score import SmoothingFunction, corpus_bleu

        weights = [1.0 / k] * k + (4 - k) * [0.0]
        try:
            bleu = corpus_bleu(
                self.refs,
                self.hyps,
                weights=weights,
                smoothing_function=SmoothingFunction().method3,
            )
        except ZeroDivisionError:
            self.warnings.warn("the bleu is invalid")
            bleu = 0.0
        return bleu

    def calc_distinct_k(self, k: int) -> float:
        d = {}
        tot = 0
        for sen in self.hyps:
            for i in range(0, max(len(sen) - k + 1, 0)):
                key = tuple(sen[i : i + k])
                d[key] = 1
                tot += 1
        if tot > 0:
            dist = len(d) / tot
        else:
            self.warnings.warn("the distinct is invalid")
            dist = 0.0
        return dist

    def calc_unigram_f1(self):
        f1_scores = []
        for hyp, refs in zip(self.hyps, self.refs):
            scores = []
            for ref in refs:
                cross = Counter(hyp) & Counter(ref)
                cross = sum(cross.values())
                p = cross / max(len(hyp), 1e-10)
                r = cross / max(len(ref), 1e-10)
                f1 = 2 * p * r / max(p + r, 1e-10)
                scores.append(f1)
            f1_scores.append(max(scores))
        return np.mean(f1_scores), f1_scores

    def calc_rouge_l(self, beta: float = 1.2):
        scores = []
        for hyp, refs in zip(self.hyps, self.refs):
            prec = []
            rec = []
            for ref in refs:
                lcs = my_lcs(ref, hyp)
                prec.append(lcs / max(len(hyp), 1e-10))
                rec.append(lcs / max(len(ref), 1e-10))
            prec_max = max(prec)
            rec_max = max(rec)
            if prec_max != 0 and rec_max != 0:
                score = ((1 + beta ** 2) * prec_max * rec_max) / float(
                    rec_max + beta ** 2 * prec_max
                )
            else:
                score = 0.0
            scores.append(score)
        return np.mean(scores), scores

    def close(self):
        result = {
            "length": float(np.mean(list(map(len, self.hyps)))) if self.hyps else 0.0,
            **{f"dist-{k}": 100 * self.calc_distinct_k(k) for k in range(1, 4)},
            **{f"bleu-{k}": 100 * self.calc_bleu_k(k) for k in range(1, 5)},
        }

        f1, scores = self.calc_unigram_f1() if self.hyps else (0.0, [])
        result["f1"] = 100 * f1
        result_list = {"f1": scores}

        rl, rouge_scores = self.calc_rouge_l() if self.hyps else (0.0, [])
        result["rouge-l"] = 100 * rl
        result_list.update({"rouge-l": rouge_scores})

        return result, result_list


# -------------------------------
# Dataset helpers
# -------------------------------
def ensure_nltk():
    # Configure NLTK data path to local directory
    current_dir = Path(__file__).parent
    nltk_data_dir = current_dir / "nltk_data"
    nltk.data.path.insert(0, str(nltk_data_dir))
    
    try:
        nltk.data.find("tokenizers/punkt_tab")
    except LookupError:
        nltk.download("punkt_tab", download_dir=str(nltk_data_dir))
    # For compatibility with older NLTK, also ensure "punkt" exists
    try:
        nltk.data.find("tokenizers/punkt")
    except LookupError:
        nltk.download("punkt", download_dir=str(nltk_data_dir))


def format_turn(turn: Dict[str, str]) -> str:
    prefix = "Seeker" if turn["speaker"] == "seeker" else "Supporter"
    return f"{prefix}: {turn['content'].strip()}"


# -------------------------------
# System Prompt for Generation Models
# -------------------------------
DEFAULT_SYSTEM_PROMPT = """You are a compassionate and professional emotional support counselor. Your role is to provide empathetic, helpful, and psychologically sound support to people seeking emotional help.

## Your Core Principles

1. **Empathy First**: Genuinely understand and acknowledge the seeker's emotions. Show that you care about their feelings and validate their experiences.

2. **Professional Boundaries**: Maintain appropriate professional boundaries. Provide support and guidance, but avoid making diagnoses or giving medical advice. When appropriate, suggest seeking professional help.

3. **Helpful Guidance**: Offer practical, relevant, and actionable suggestions that address the seeker's specific concerns. Focus on what would be most useful for their situation.

4. **Natural Communication**: Express yourself in a warm, natural, and fluent manner. Your responses should feel like a caring friend who also has professional knowledge, not like a clinical manual.

## Guidelines

- Listen actively to what the seeker is sharing
- Acknowledge their emotions before jumping to solutions
- Ask thoughtful questions to better understand their situation
- Provide support that is both emotionally comforting and practically helpful
- Use clear, coherent language that is easy to understand
- Avoid generic or clichéd responses
- Do not provide medical diagnoses or prescribe treatments
- If the situation requires professional intervention, gently suggest seeking help from qualified professionals

## Response Style

- Be warm and human-like, like a supportive friend
- Be concise but thorough—aim for meaningful responses
- Focus on the seeker's immediate needs while considering the conversation context
- Balance emotional support with practical guidance

## CRITICAL REQUIREMENT

**YOU MUST ALWAYS PROVIDE A NON-EMPTY RESPONSE. Your response must contain meaningful content and cannot be empty, blank, or contain only whitespace. This is mandatory and non-negotiable.**

Remember: Your goal is to help the seeker feel heard, understood, and supported while providing them with useful guidance for their situation."""


class ESConvSampleBuilder:
    def __init__(self, dataset_path: Path):
        self.dataset_path = dataset_path
        with open(dataset_path, "r", encoding="utf-8") as f:
            self.dataset = json.load(f)

    def build_samples(
        self,
        limit: int,
        context_window: int,
        per_dialog_limit: int,
    ) -> List[Dict]:
        samples: List[Dict] = []
        use_all = (limit is None) or (limit <= 0)
        per_dialog_all = (per_dialog_limit is None) or (per_dialog_limit <= 0)
        for conv_id, conv in enumerate(self.dataset):
            used = 0
            dialog = conv["dialog"]
            for idx, turn in enumerate(dialog):
                if turn["speaker"] != "supporter":
                    continue
                if idx == 0:
                    continue
                context_slice = dialog[max(0, idx - context_window) : idx]
                if not context_slice or context_slice[-1]["speaker"] != "seeker":
                    continue
                context_turns = [format_turn(t) for t in context_slice]
                prompt = "\n".join(context_turns + ["Supporter:"])
                reference = turn["content"].strip()
                samples.append(
                    {
                        "conversation_id": conv_id,
                        "supporter_turn_index": idx,
                        "emotion_type": conv.get("emotion_type"),
                        "problem_type": conv.get("problem_type"),
                        "context_turns": context_turns,
                        "reference": reference,
                        "prompt": prompt,
                    }
                )
                used += 1
                if (not use_all) and len(samples) >= limit:
                    return samples
                if (not per_dialog_all) and used >= per_dialog_limit:
                    break
        return samples


class EmotionalSupportEvaluator:
    def __init__(
        self,
        dataset_path: Path,
        model_name: str = "gpt-4o-mini",
        system_prompt: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 512,
        max_retries: int = 3,
    ):
        ensure_nltk()
        self.builder = ESConvSampleBuilder(dataset_path)
        self.model_name = model_name
        self.system_prompt = system_prompt
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.max_retries = max_retries

    def _call_model(self, prompt: str) -> str:
        # Retry logic for API failures (network errors, timeouts, etc.)
        for attempt in range(self.max_retries):
            try:
                messages = []
                if self.system_prompt:
                    messages.append({"role": "system", "content": self.system_prompt})
                messages.append({"role": "user", "content": prompt})
                
                completion = client.chat.completions.create(
                    model=self.model_name,
                    temperature=self.temperature,
                    max_tokens=self.max_tokens,
                    messages=messages,
                    timeout=3000.0,
                )
                result = completion.choices[0].message.content
                if result is None:
                    raise ValueError("API returned None content")
                
                stripped_result = result.strip()
                if not stripped_result:
                    print(f"Warning: API returned empty string (model: {self.model_name})", flush=True)
                
                return stripped_result
                
            except Exception as err:
                print(f"API call failed (attempt {attempt + 1}/{self.max_retries}): {err}", flush=True)
                if attempt == self.max_retries - 1:
                    raise
                wait = 2 ** attempt
                time.sleep(wait)
        return ""

    def evaluate(
        self,
        sample_size: int,
        context_window: int,
        per_dialog_limit: int,
        seed: int = 42,
        conv_start: int = 0,
        conv_count: int = 0,
    ) -> Dict[str, Dict]:
        """
        Evaluate samples grouped by conversation.

        conv_start / conv_count slice the dataset by full conversations.
        For example, conv_count=1 means only the first conversation is evaluated,
        and all its turns will be generated and scored.
        """
        random.seed(seed)
        samples = self.builder.build_samples(
            sample_size, context_window, per_dialog_limit
        )
        if conv_count > 0:
            filtered = [
                (i, s)
                for i, s in enumerate(samples)
                if conv_start <= s["conversation_id"] < conv_start + conv_count
            ]
        else:
            filtered = [
                (i, s)
                for i, s in enumerate(samples)
                if s["conversation_id"] >= conv_start
            ]
        metric = Metric(toker=None)
        conversation_details: List[Dict] = []

        for pos, (global_idx, sample) in enumerate(filtered, 1):
            print(
                f"Generating response {pos}/{len(filtered)} "
                f"(conversation {sample['conversation_id']+1}, turn {sample['supporter_turn_index']})...",
                flush=True,
            )
            try:
                response = self._call_model(sample["prompt"])
                if not response:
                    print(f"Warning: sample {global_idx} generated empty response", flush=True)
                    response = "[generation failed]"
            except Exception as e:
                print(f"Generation failed (sample {global_idx}): {e}", flush=True)
                response = f"[generation exception: {str(e)}]"
            metric.forword([sample["reference"]], response, chinese=False)

            conversation_text = "\n".join(
                sample["context_turns"] + [f"Supporter: {response}"]
            )
            conversation_details.append(
                {
                    "data_id": global_idx,
                    "conversation_id": sample["conversation_id"],
                    "supporter_turn_index": sample["supporter_turn_index"],
                    "conversation_text": conversation_text,
                    "emotion_types": [sample["emotion_type"]],
                    "problem_types": [sample["problem_type"]],
                    "reference_response": sample["reference"],
                    "model_response": response,
                }
            )

        metric_summary, per_item_scores = metric.close()

        for detail, f1_score, rl_score in zip(
            conversation_details,
            per_item_scores.get("f1", []),
            per_item_scores.get("rouge-l", []),
        ):
            detail["sample_f1"] = float(f1_score)
            detail["sample_rouge_l"] = float(rl_score)

        for detail in conversation_details:
            ref = detail["reference_response"]
            hyp = detail["model_response"]
            ref_tokens = nltk.word_tokenize(ref.lower())
            hyp_tokens = nltk.word_tokenize(hyp.lower())
            detail["reference_len"] = len(ref_tokens)
            detail["model_len"] = len(hyp_tokens)

        nlgeval_scores = {}
        nlgeval_details: Dict[str, List[float]] = {}
        try:
            # Optionally extend sys.path with external NLGEval implementation
            extra_nlgeval_root = os.getenv("NLGEVAL_ROOT")
            if extra_nlgeval_root:
                sys.path.append(extra_nlgeval_root)
            from metric import NLGEval  # type: ignore

            nlg_eval = NLGEval()
            ref_list = [[c["reference_response"] for c in conversation_details]]
            hyp_list = [c["model_response"] for c in conversation_details]
            nlgeval_scores, nlgeval_details = nlg_eval.compute_metrics(
                ref_list, hyp_list
            )

            for name, scores in nlgeval_details.items():
                for detail, s in zip(conversation_details, scores):
                    detail[name] = float(s)
        except Exception:
            # If NLGEval is not installed or import fails, silently skip it
            nlgeval_scores = {}
            nlgeval_details = {}

        stats_summary = {
            "model_name": self.model_name,
            "text_metrics": metric_summary,
            "nlg_eval_metrics": nlgeval_scores,
            "sample_size": len(conversation_details),
            "context_window": context_window,
            "per_dialog_limit": per_dialog_limit,
        }

        return {
            "conversation_details": conversation_details,
            "aggregate_summary": stats_summary,
        }


# -------------------------------
# Evaluation with Judge Model
# -------------------------------
METRICS = ["Fluency", "Professionalism", "Empathy", "Helpfulness"]

PROMPT_TEMPLATES = {
    "Fluency": """# System
You are an impartial judge, familiar with psychology knowledge and psychological counseling.

## Attention
You need to evaluate the **Fluency** of the AI assistant's responses based on its dialogue with the user.
Your evaluation results must be based on the Evaluation Criteria.

## Evaluation Criteria
1.**Fluency [0-5 points]**: Fluency evaluates whether language expression is natural, coherent, and comprehensible.
    - 0: Incoherent or difficult to understand; contains grammar or logic issues.
    - 1: Unclear expression; user may struggle to grasp the meaning.
    - 2: Some parts are confusing, though the main point can be inferred.
    - 3: Mostly clear and coherent with minor ambiguities.
    - 4: Fluent and well-structured; logically organized and easy to follow.
    - 5: Concise and impactful language; precise and elegant communication that conveys ideas efficiently.

## Constraints
- Avoid evaluation bias due to preference for specific model names.
- Avoid evaluation bias due to response length.

## Input
### Context: {Context}

### Seeker's Input: {User_input}

### Model's Response
Ground Truth Response(reference): {GT_Response}
Model's Response: {Pred_Response}

Based on the rules, give your Fluency score and a brief reason (1-2 sentences) to the Model's Response.

## Output Format
Score: [0-5 number]
Reason: [Brief explanation in English]""",

    "Professionalism": """# System
You are an impartial judge, familiar with psychology knowledge and psychological counseling.

## Attention
You need to evaluate the **Professionalism** of the AI assistant's responses based on its dialogue with the user.
Your evaluation results must be based on the Evaluation Criteria.

## Evaluation Criteria
1.**Professionalism [0-5 points]**: Evaluates whether the model demonstrates psychological knowledge, follows ethical principles, and avoids misleading or inappropriate advice.
    - 0: Contains harmful, misleading, or clearly inappropriate content that may violate ethical or psychological guidelines.
    - 1: Shows serious misunderstanding or misuse of psychological concepts, or provides inappropriate advice.
    - 2: Minor factual inaccuracies or advice that lacks evidence, but does not pose direct harm.
    - 3: No major errors; advice is acceptable and somewhat aligned with psychological principles.
    - 4: Demonstrates solid understanding of psychological concepts and appropriate intervention techniques.
    - 5: Highly professional, reflects strong psychological insight, maintains boundaries, and communicates in a grounded, ethical manner.

## Constraints
- Avoid evaluation bias due to preference for specific model names.
- Avoid evaluation bias due to response length.
- Do not confuse professionalism with warmth or empathy—focus on psychological accuracy and appropriateness.

## Input
### Context: {Context}

### Seeker's Input: {User_input}

### Model's Response
Ground Truth Response(reference): {GT_Response}
Model's Response: {Pred_Response}

Based on the rules, give your Professionalism score and a brief reason (1-2 sentences) to the Model's Response.

## Output Format
Score: [0-5 number]
Reason: [Brief explanation in English]""",

    "Empathy": """# System
You are an impartial judge, familiar with psychology knowledge and psychological counseling.

## Attention
You need to evaluate the **Empathy** of the AI assistant's responses based on its dialogue with the user.
Your evaluation results must be based on the Evaluation Criteria.

## Evaluation Criteria
1.**Empathy [0-5 points]**: Evaluates whether the model genuinely understands the user's emotions, expresses care, and provides emotional support.
    - 0: Contains statements that may harm the user emotionally or lead to a negative emotional trajectory.
    - 1: Fails to provide emotional comfort or assist the user in analyzing their problems.
    - 2: Either lacks emotional comfort or fails to support problem analysis.
    - 3: No significant issues, but empathy and analysis remain surface-level.
    - 4: Demonstrates a warm, human-like tone—like a friend—offering both emotional relief and analytical support.
    - 5: Deep emotional insight with sincere and stable empathy, conveyed through attentive and flexible language.

## Constraints
- Avoid evaluation bias due to preference for specific model names.
- Avoid evaluation bias due to response length.

## Input
### Context: {Context}

### Seeker's Input: {User_input}

### Model's Response
Ground Truth Response(reference): {GT_Response}
Model's Response: {Pred_Response}

Based on the rules, give your Empathy score and a brief reason (1-2 sentences) to the Model's Response.

## Output Format
Score: [0-5 number]
Reason: [Brief explanation in English]""",

    "Helpfulness": """# System
You are an impartial judge, familiar with psychology knowledge and psychological counseling.

## Attention
You need to evaluate the **Helpfulness** of the AI assistant's responses based on its dialogue with the user.
Your evaluation results must be based on the Evaluation Criteria.

## Evaluation Criteria
1.**Helpfulness [0-5 points]**: Helpfulness evaluates the effectiveness of an AI assistant's suggestions by considering both the number of recommendations provided per interaction and the relevance or usefulness of each suggestion in addressing the user's question.
    - 0: Irrelevant, misleading, or potentially harmful suggestions.
    - 1: Ineffective or generic advice that does not respond to the user's needs.
    - 2: Weakly relevant suggestions with limited practical value.
    - 3: Somewhat helpful; suggestions are relevant and usable.
    - 4: Clear and practical advice that aligns well with the user's issue.
    - 5: Highly insightful, tailored, and actionable suggestions that offer strong guidance and value.

## Constraints
- Avoid evaluation bias due to preference for specific model names.
- Avoid evaluation bias due to response length.

## Input
### Context: {Context}

### Seeker's Input: {User_input}

### Model's Response
Ground Truth Response(reference): {GT_Response}
Model's Response: {Pred_Response}

Based on the rules, give your Helpfulness score and a brief reason (1-2 sentences) to the Model's Response.

## Output Format
Score: [0-5 number]
Reason: [Brief explanation in English]"""
}


def extract_score_and_reason(response: str) -> Tuple[Optional[float], Optional[str]]:
    """Extract a 0-5 score and explanation from model response."""
    response = response.strip()
    
    # Extract score
    score = None
    score_match = re.search(r'Score:\s*([0-5](?:\.\d+)?)', response, re.IGNORECASE)
    if score_match:
        score_val = float(score_match.group(1))
        if 0 <= score_val <= 5:
            score = score_val
    else:
        # Fallback: directly match a standalone number if "Score:" is missing
        match = re.search(r'\b([0-5](?:\.\d+)?)\b', response)
        if match:
            score_val = float(match.group(1))
            if 0 <= score_val <= 5:
                score = score_val
    
    # Extract reason
    reason = None
    reason_match = re.search(r'Reason:\s*(.+?)(?:\n|$)', response, re.IGNORECASE | re.DOTALL)
    if reason_match:
        reason = reason_match.group(1).strip()
    else:
        if score is not None:
            after_score = response.split(str(score), 1)
            if len(after_score) > 1:
                remaining = after_score[1].strip()
                remaining = re.sub(r'^(Score:|Reason:)\s*', '', remaining, flags=re.IGNORECASE).strip()
                if remaining and len(remaining) > 5:
                    reason = remaining
    
    return score, reason


def extract_score(response: str) -> Optional[float]:
    """Backward-compatible helper extracting only the 0-5 score from response."""
    score, _ = extract_score_and_reason(response)
    return score


def call_gpt4_for_evaluation(prompt: str, judge_model: str = "gpt-4.1", max_retries: int = 3) -> Tuple[Optional[float], Optional[str]]:
    """Call the judge model once for evaluation, returning score and reason."""
    for attempt in range(max_retries):
        try:
            response = client.chat.completions.create(
                model=judge_model,
                messages=[
                    {"role": "user", "content": prompt}
                ],
                temperature=0.0,
                max_tokens=200,
                timeout=60.0,
            )
            content = response.choices[0].message.content
            if content is None:
                raise ValueError("API returned empty content")
            content = content.strip()
            score, reason = extract_score_and_reason(content)
            if score is not None:
                return score, reason
            else:
                print(f"Warning: failed to extract valid score from response: {content}", flush=True)
                if attempt < max_retries - 1:
                    time.sleep(2 ** attempt)
        except Exception as e:
            print(f"API call failed (attempt {attempt + 1}/{max_retries}): {e}", flush=True)
            if attempt < max_retries - 1:
                wait_time = 2 ** attempt
                time.sleep(wait_time)
    return None, None


def extract_context_and_user_input(conversation_text: str) -> Tuple[str, str]:
    """Extract conversation context and latest user input from conversation_text.

    Example conversation_text:
    "Seeker: Hello\nSupporter: Hello, what would you like to talk about?\nSeeker: I am having anxiety\nSupporter: I understand..."

    Returns:
        context: All dialogue before the last Seeker input (excluding the last Supporter reply).
        user_input: The content of the last Seeker input.
    """
    lines = conversation_text.split('\n')
    
    last_seeker_line = None
    last_seeker_idx = -1
    
    for i in range(len(lines) - 1, -1, -1):
        line = lines[i]
        if line.startswith('Seeker:'):
            last_seeker_line = line
            last_seeker_idx = i
            break
    
    if last_seeker_line is None:
        return conversation_text, ""
    
    user_input = last_seeker_line.replace('Seeker:', '').strip()
    
    context_lines = lines[:last_seeker_idx]
    context = '\n'.join(context_lines).strip()
    
    return context, user_input


def evaluate_single_sample(sample: Dict, judge_model: str = "gpt-4.1") -> Dict:
    """Evaluate a single sample using the judge model and return scores with reasons."""
    conversation_text = sample.get("conversation_text", "")
    reference_response = sample.get("reference_response", "")
    model_response = sample.get("model_response", "")
    
    context, user_input = extract_context_and_user_input(conversation_text)
    
    scores = {}
    score_reasons = {}
    
    print(
        f"Evaluating sample {sample.get('conversation_id', '?')}-"
        f"{sample.get('supporter_turn_index', '?')}...",
        flush=True,
    )
    
    for metric in METRICS:
        prompt_template = PROMPT_TEMPLATES[metric]
        prompt = prompt_template.format(
            Context=context,
            User_input=user_input,
            GT_Response=reference_response,
            Pred_Response=model_response
        )
        
        print(f"  Evaluating {metric}...", end=" ", flush=True)
        try:
            score, reason = call_gpt4_for_evaluation(prompt, judge_model=judge_model, max_retries=3)
            
            if score is not None:
                scores[metric] = score
                score_reasons[metric] = (
                    reason if reason else f"Score {score}, but no detailed reason was provided."
                )
                print(f"Score: {score}", flush=True)
            else:
                scores[metric] = None
                score_reasons[metric] = "Evaluation failed: no valid score and reason could be extracted."
                print("Failed", flush=True)
        except Exception as e:
            print(f"Exception: {e}", flush=True)
            scores[metric] = None
            score_reasons[metric] = f"Evaluation exception: {str(e)}"
        
        # Small delay to reduce risk of API rate limiting
        time.sleep(0.5)
    
    result = {
        **sample,
        "evaluation_scores": scores,
        "score_reasons": score_reasons,
    }
    
    return result


# Placeholder generation model identifiers (non-sensitive)
GENERATION_MODELS: List[str] = [
    "model_1",
    "model_2",
    "model_3",
    "model_4",
    "model_5",
    "model_6",
]

# Placeholder judge model identifier (non-sensitive)
JUDGE_MODEL = "judge_model"


def aggregate_scores(
    records: List[Dict],
) -> Tuple[Dict[str, Dict[str, List[float]]], List[float]]:
    """
    Aggregate a list of evaluation records.

    Args:
        records: Each item contains evaluation_scores {metric: score}.

    Returns:
        per_metric_scores: {metric: {"scores": [...]} }
        flat_scores: all metric scores flattened into a single list.
    """
    per_metric_scores: Dict[str, Dict[str, List[float]]] = {
        m: {"scores": []} for m in METRICS
    }
    flat_scores: List[float] = []

    for r in records:
        scores = r.get("evaluation_scores", {})
        for metric in METRICS:
            val = scores.get(metric)
            if isinstance(val, (int, float)):
                per_metric_scores[metric]["scores"].append(float(val))
                flat_scores.append(float(val))

    return per_metric_scores, flat_scores


def compute_avg_from_scores(
    per_metric_scores: Dict[str, Dict[str, List[float]]],
    flat_scores: List[float],
) -> Tuple[Dict[str, float], float]:
    """
    Compute average score per metric and overall average.

    Args:
        per_metric_scores: Output from aggregate_scores.
        flat_scores: Flattened list of all scores.

    Returns:
        metric_avgs: Average for each metric.
        overall: Global average over all scores.
    """
    metric_avgs: Dict[str, float] = {}
    for metric, info in per_metric_scores.items():
        scores = info["scores"]
        if scores:
            metric_avgs[metric] = round(sum(scores) / len(scores), 3)
        else:
            metric_avgs[metric] = 0.0

    if flat_scores:
        overall = round(sum(flat_scores) / len(flat_scores), 3)
    else:
        overall = 0.0

    return metric_avgs, overall


def get_tested_records_path(results_dir: Path) -> Path:
    """Return the path of the JSON file tracking tested records."""
    return results_dir / "tested_records.json"


def load_tested_records(results_dir: Path) -> Dict[str, List[int]]:
    """
    Load tested records from disk.

    Returns structure: {model: [data_id1, data_id2, ...]}.
    """
    records_path = get_tested_records_path(results_dir)
    if records_path.exists():
        try:
            with open(records_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            print(f"Error while loading tested records: {e}")
            return {}
    return {}


def save_tested_records(results_dir: Path, records: Dict[str, List[int]]):
    """Persist tested records to disk."""
    records_path = get_tested_records_path(results_dir)
    records_path.parent.mkdir(parents=True, exist_ok=True)
    with open(records_path, "w", encoding="utf-8") as f:
        json.dump(records, f, ensure_ascii=False, indent=2)


def is_tested(data_id: int, model: str, records: Dict[str, List[int]]) -> bool:
    """Return True if a (data_id, model) pair has already been tested."""
    if model not in records:
        return False
    return data_id in records[model]


def mark_as_tested(data_id: int, model: str, records: Dict[str, List[int]]):
    """Mark a (data_id, model) pair as tested."""
    if model not in records:
        records[model] = []
    if data_id not in records[model]:
        records[model].append(data_id)
        records[model].sort()


def evaluate_for_one_model(
    model_name: str,
    esconv_path: Path,
    start: int,
    count: int,
    results_dir: Path,
    tested_records: Dict[str, List[int]],
    context_window: int = 30,
    per_dialog_limit: int = 0,
    seed: int = 42,
) -> Tuple[List[Dict], Dict[str, Any], List[Dict]]:
    """
    Run the full multi-metric evaluation pipeline for a single generation model.

    1) Use EmotionalSupportEvaluator to generate responses.
    2) Use the judge model to compute four metrics for each sample.

    Returns a list of scored records for each evaluated sample.
    """
    print(f"\n========== Start evaluating generation model: {model_name} ==========", flush=True)

    evaluator = EmotionalSupportEvaluator(
        dataset_path=esconv_path,
        model_name=model_name,
        system_prompt=DEFAULT_SYSTEM_PROMPT,
        temperature=0.7,
        max_tokens=512,
        max_retries=10,
    )

    results = evaluator.evaluate(
        sample_size=-1,
        context_window=context_window,
        per_dialog_limit=per_dialog_limit,
        seed=seed,
        conv_start=start,
        conv_count=count,
    )

    all_details: List[Dict] = results["conversation_details"]
    details_to_process = all_details
    
    n_conv = len({d["conversation_id"] for d in details_to_process}) if details_to_process else 0
    print(
        f"Model {model_name}: this batch has {n_conv} conversations and "
        f"{len(details_to_process)} turns in total",
        flush=True,
    )
    
    filtered_details = []
    for item in details_to_process:
        data_id = item["data_id"]
        if not is_tested(data_id, model_name, tested_records):
            filtered_details.append((data_id, item))
    
    skipped_count = len(details_to_process) - len(filtered_details)
    if skipped_count > 0:
        print(
            f"Model {model_name} skipped {skipped_count} previously tested samples; "
            f"{len(filtered_details)} samples remain to evaluate.\n",
            flush=True,
        )
    else:
        print(f"Model {model_name} has {len(filtered_details)} samples to evaluate.\n", flush=True)
    
    aggregate_summary: Dict[str, Any] = results.get("aggregate_summary", {})
    text_metrics: Dict[str, float] = aggregate_summary.get("text_metrics", {})

    judged_records: List[Dict] = []
    sampled_records_10t1: List[Dict] = []
    for idx, (data_id, item) in enumerate(filtered_details, 1):
        sample = {
            "conversation_text": item.get("conversation_text", ""),
            "reference_response": item.get("reference_response", ""),
            "model_response": item.get("model_response", ""),
        }
        print(
            f"[{model_name}] Scoring sample {idx}/{len(filtered_details)} (data_id: {data_id}) ...",
            flush=True,
        )
        try:
            judged = evaluate_single_sample(sample, judge_model=JUDGE_MODEL)
        except Exception as e:
            print(f"Exception while evaluating sample {data_id}: {e}", flush=True)
            judged = {
                "conversation_text": sample.get("conversation_text", ""),
                "reference_response": sample.get("reference_response", ""),
                "model_response": sample.get("model_response", ""),
                "evaluation_scores": {metric: None for metric in METRICS},
                "score_reasons": {metric: f"Evaluation exception: {str(e)}" for metric in METRICS},
            }

        conv_id = item.get("conversation_id")
        turn_idx = item.get("supporter_turn_index")
        
        record = {
            "model": model_name,
            "data_id": data_id,
            "conversation_id": conv_id,
            "supporter_turn_index": turn_idx,
            "emotion_types": item.get("emotion_types", []),
            "problem_types": item.get("problem_types", []),
            "evaluation_scores": judged.get("evaluation_scores", {}),
            "score_reasons": judged.get("score_reasons", {}),
        }
        judged_records.append(record)
        
        mark_as_tested(data_id, model_name, tested_records)
        
        if idx % 5 == 0:
            try:
                temp_records = load_previous_results(results_dir)
                temp_records.extend(judged_records)
                save_detailed_records(results_dir, temp_records)
                save_tested_records(results_dir, tested_records)
                print(f"  Progress saved (processed {idx}/{len(filtered_details)} samples)", flush=True)
            except Exception as e:
                print(f"  Error while saving progress: {e}", flush=True)

        if idx % 10 == 0:
            conversation_text = item.get("conversation_text", "")
            context, user_input = extract_context_and_user_input(conversation_text)
            score_reasons = judged.get("score_reasons", {})

            sampled_records_10t1.append(
                {
                    "model": model_name,
                    "data_id": data_id,
                    "conversation_id": conv_id,
                    "supporter_turn_index": turn_idx,
                    "emotion_types": item.get("emotion_types", []),
                    "problem_types": item.get("problem_types", []),
                    "user_input": user_input,
                    "context": context,
                    "reference_response": item.get("reference_response", ""),
                    "model_response": item.get("model_response", ""),
                    "evaluation_scores": judged.get("evaluation_scores", {}),
                    "score_reasons": score_reasons,
                }
            )

    if not sampled_records_10t1 and filtered_details:
        _, last_item = filtered_details[-1]
        last_judged_record = judged_records[-1] if judged_records else {}
        conversation_text = last_item.get("conversation_text", "")
        context, user_input = extract_context_and_user_input(conversation_text)
        score_reasons = last_judged_record.get("score_reasons", {})
        if not score_reasons:
            score_reasons = {}
            for metric in METRICS:
                score = last_judged_record.get("evaluation_scores", {}).get(metric)
                if isinstance(score, (int, float)):
                    score_reasons[metric] = (
                        f"{metric} score is {score}, but no detailed reason was provided."
                    )
                else:
                    score_reasons[metric] = f"{metric} could not be scored successfully."

        last_data_id = filtered_details[-1][0]
        sampled_records_10t1.append(
            {
                "model": model_name,
                "data_id": last_data_id,
                "conversation_id": last_item.get("conversation_id"),
                "supporter_turn_index": last_item.get("supporter_turn_index"),
                "emotion_types": last_item.get("emotion_types", []),
                "problem_types": last_item.get("problem_types", []),
                "user_input": user_input,
                "context": context,
                "reference_response": last_item.get("reference_response", ""),
                "model_response": last_item.get("model_response", ""),
                "evaluation_scores": last_judged_record.get("evaluation_scores", {}),
                "score_reasons": score_reasons,
            }
        )

    return judged_records, text_metrics, sampled_records_10t1


AUTO_TEXT_METRIC_KEYS: List[str] = [
    "length",
    "dist-1",
    "dist-2",
    "dist-3",
    "bleu-1",
    "bleu-2",
    "bleu-3",
    "bleu-4",
    "f1",
    "rouge-l",
]


def load_previous_results(results_dir: Path) -> List[Dict]:
    """Load previous scoring records from result files, if any."""
    previous_records = []
    
    detailed_records_path = results_dir / "detailed_records.json"
    if detailed_records_path.exists():
        try:
            with open(detailed_records_path, "r", encoding="utf-8") as f:
                previous_records = json.load(f)
            print(f"✓ Loaded {len(previous_records)} historical records from detailed_records.json")
        except Exception as e:
            print(f"Warning: failed to read detailed records: {e}")
    
    return previous_records


def save_detailed_records(results_dir: Path, all_records: List[Dict]):
    """Save detailed scoring records to JSON file."""
    detailed_records_path = results_dir / "detailed_records.json"
    with open(detailed_records_path, "w", encoding="utf-8") as f:
        json.dump(all_records, f, ensure_ascii=False, indent=2)


def build_summary(
    judged_all: List[Dict],
    text_metrics_by_model: Dict[str, Dict[str, float]],
) -> Dict:
    """
    Build a compact summary based on all models' scoring records.

    Includes:
    - Per-model averages for each metric and overall.
    - Global average across all models and samples.
    """
    summary: Dict = {
        "generation_models": GENERATION_MODELS,
        "judge_model": JUDGE_MODEL,
        "metrics": METRICS,
        "overall": {},
    }

    records_by_model: Dict[str, List[Dict]] = {m: [] for m in GENERATION_MODELS}
    for r in judged_all:
        model = r["model"]
        if model in records_by_model:
            records_by_model[model].append(r)

    # overall.models
    overall_models: Dict[str, Dict] = {}
    global_flat_scores: List[float] = []

    for model, recs in records_by_model.items():
        per_metric, flat = aggregate_scores(recs)
        metric_avgs, overall = compute_avg_from_scores(per_metric, flat)
        auto_metrics_source = text_metrics_by_model.get(model, {})
        auto_metrics: Dict[str, float] = {}
        for key in AUTO_TEXT_METRIC_KEYS:
            val = auto_metrics_source.get(key)
            if isinstance(val, (int, float)):
                auto_metrics[key] = float(val)

        overall_models[model] = {
            "metrics": metric_avgs,
            "overall": overall,
            "auto_metrics": auto_metrics,
        }
        global_flat_scores.extend(flat)

    # overall.global
    if global_flat_scores:
        global_overall = round(
            sum(global_flat_scores) / len(global_flat_scores),
            3,
        )
    else:
        global_overall = 0.0

    summary["overall"] = {
        "models": overall_models,
        "global": {
            "overall": global_overall,
        },
    }

    return summary


def main() -> None:
    """
    Entry point for multi-model evaluation on the ESConv support task.

    - --start / --count: slice by conversation index; count=1 evaluates only the first conversation.
    - --models: list of generation models to evaluate (space separated).
    - Uses a single judge model to compute Fluency / Professionalism / Empathy / Helpfulness.
    - Writes a compact summary file to result/support_overall.json.
    """
    parser = argparse.ArgumentParser(
        description="ESConv support task multi-model evaluation (supports incremental runs)"
    )
    parser.add_argument(
        "--count",
        type=int,
        default=1,
        help="Number of conversations to test (each conversation contains multiple turns). Default 1.",
    )
    parser.add_argument(
        "--start",
        type=int,
        default=0,
        help="Conversation index to start from (0 means the first conversation).",
    )
    parser.add_argument(
        "--models",
        type=str,
        nargs="+",
        default=GENERATION_MODELS,
        help="List of generation models to evaluate, separated by spaces.",
    )
    args = parser.parse_args()

    models = [m.strip() for m in args.models if m.strip()]
    for model in models:
        if model not in GENERATION_MODELS:
            print(f"Warning: model '{model}' is not in the supported list and will be ignored")
    models = [m for m in models if m in GENERATION_MODELS]
    
    if not models:
        print("Error: no valid models to evaluate")
        return

    base_dir = Path(__file__).parent
    esconv_path = base_dir / "ESConv.json"
    if not esconv_path.exists():
        raise FileNotFoundError(f"ESConv.json not found at: {esconv_path}")

    results_dir = base_dir / "result"
    os.makedirs(results_dir, exist_ok=True)
    
    tested_records = load_tested_records(results_dir)
    
    print("Evaluation configuration:", flush=True)
    print(f"  - Start conversation index (0-based): {args.start}", flush=True)
    print(f"  - Number of conversations: {args.count}", flush=True)
    print(f"  - Models: {', '.join(models)}", flush=True)
    total_tested = sum(len(data_ids) for data_ids in tested_records.values())
    print(f"  - Previously tested records: {total_tested}\n", flush=True)
    
    print("Loading previous results (if any)...", flush=True)
    previous_judged = load_previous_results(results_dir)
    all_judged: List[Dict] = previous_judged.copy()
    text_metrics_by_model: Dict[str, Dict[str, float]] = {}
    sampled_records_10t1_all: List[Dict] = []
    
    for model_name in models:
        recs, text_metrics, sampled_10t1 = evaluate_for_one_model(
            model_name=model_name,
            esconv_path=esconv_path,
            start=args.start,
            count=args.count,
            results_dir=results_dir,
            tested_records=tested_records,
        )
        all_judged.extend(recs)
        text_metrics_by_model[model_name] = text_metrics
        sampled_records_10t1_all.extend(sampled_10t1)
    
    save_tested_records(results_dir, tested_records)
    save_detailed_records(results_dir, all_judged)

    summary = build_summary(all_judged, text_metrics_by_model)
    
    for model_name in GENERATION_MODELS:
        if model_name in summary["overall"]["models"]:
            model_records = [r for r in all_judged if r["model"] == model_name]
            summary["overall"]["models"][model_name]["sample_count"] = len(model_records)
    
    summary_path = results_dir / "support_overall.json"
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    sample_output_path = results_dir / "output_sample_10t1.json"
    existing_samples_10t1 = []
    if sample_output_path.exists():
        try:
            with open(sample_output_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, dict) and "items" in data:
                    existing_samples_10t1 = data["items"]
                else:
                    existing_samples_10t1 = data
            print(
                f"✓ Detected existing output_sample_10t1.json with "
                f"{len(existing_samples_10t1)} entries; merging new results"
            )
        except Exception as e:
            print(f"Warning: failed to read existing 10:1 sample file: {e}")
    
    existing_keys = {
        (s.get("model"), s.get("data_id"))
        for s in existing_samples_10t1
        if s.get("data_id") is not None
    }
    merged_samples = existing_samples_10t1.copy()
    for new_sample in sampled_records_10t1_all:
        key = (new_sample.get("model"), new_sample.get("data_id"))
        if key not in existing_keys and new_sample.get("data_id") is not None:
            merged_samples.append(new_sample)
            existing_keys.add(key)
    
    with open(sample_output_path, "w", encoding="utf-8") as f:
        json.dump(merged_samples, f, ensure_ascii=False, indent=2)

    print(f"\nSupport task evaluation finished. Summary written to: {summary_path}", flush=True)
    print(
        f"10:1 sampled results written to: {sample_output_path} "
        f"(total {len(merged_samples)} entries, newly added {len(sampled_records_10t1_all)} entries)",
        flush=True,
    )
    print(f"Test records saved to: {get_tested_records_path(results_dir)}", flush=True)


if __name__ == "__main__":
    main()



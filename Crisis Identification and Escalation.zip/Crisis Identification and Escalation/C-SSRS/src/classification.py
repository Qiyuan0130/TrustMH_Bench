"""
C-SSRS dataset classification task implementation.
Implements metrics: Macro-F1, Binary F1-score, Precision, Recall, Confusion Matrix
"""

import json
import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from sklearn.metrics import (
    f1_score,
    precision_recall_fscore_support,
    precision_score,
    recall_score,
)
from tqdm import tqdm

from .prompts import build_classification_prompt
from .settings import (
    CLASSIFICATION_MODEL,
    CLIENT,
)

CODE_BLOCK_PATTERN = re.compile(r"```(?:json)?\s*(\{.*?\})\s*```", re.DOTALL)

# Unified label configuration (5-label)
LABEL_ORDER = ["Supportive", "Indicator", "Ideation", "Behavior", "Attempt"]
VALID_LABELS = set(LABEL_ORDER)

# Logging configuration
_logger = None


def _setup_logger(logs_dir: str = "outputs/logs") -> logging.Logger:
    """Configure logger to write logs to file and console."""
    global _logger
    if _logger is not None:
        return _logger

    logs_path = Path(logs_dir)
    if not logs_path.is_absolute():
        current_file = Path(__file__).resolve()
        project_root = current_file.parent.parent
        logs_path = project_root / logs_dir
    logs_path.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = logs_path / f"classification_{timestamp}.log"

    log_format = logging.Formatter(
        fmt="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )

    logger = logging.getLogger("classification")
    logger.setLevel(logging.INFO)

    if logger.handlers:
        return logger

    file_handler = logging.FileHandler(log_file, encoding="utf-8")
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(log_format)
    logger.addHandler(file_handler)

    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(log_format)
    logger.addHandler(console_handler)

    _logger = logger
    logger.info(f"Logger initialized, log file: {log_file}")
    return logger


def get_logger() -> logging.Logger:
    """Get logger instance."""
    if _logger is None:
        return _setup_logger()
    return _logger


def run_classification(
    samples: List[Dict[str, Any]],
    dataset_id: str,
    experiment: str = "exp1",
    temperature: float = 0.0,
) -> List[Dict[str, Any]]:
    """
    Run classification inference task.
    Uniformly uses 5-label classification.
    
    Args:
        samples: List of samples
        dataset_id: Dataset identifier
        experiment: Reserved parameter for interface compatibility, actually uniformly uses 5-label classification
        temperature: Model temperature parameter
        
    Returns:
        List of classification results
    """
    logger = get_logger()
    logger.info(
        f"Starting classification task - Dataset: {dataset_id}, "
        f"Samples: {len(samples)}, Model: {CLASSIFICATION_MODEL}, Temperature: {temperature}"
    )

    results: List[Dict[str, Any]] = []
    iterator = tqdm(
        samples,
        desc=f"Classification[{dataset_id}]",
        unit="sample",
        leave=False,
        total=len(samples),
    )

    error_count = 0
    for idx, item in enumerate(iterator):
        try:
            conversation_input = item.get("inputs", [])
            sample_dataset_id = item.get("dataset_id") or dataset_id
            prompt = build_classification_prompt(conversation_input, sample_dataset_id, "exp1")

            logger.debug(f"Processing sample {idx+1}/{len(samples)} - Dataset: {sample_dataset_id}")

            completion = CLIENT.chat.completions.create(
                model=CLASSIFICATION_MODEL,
                temperature=temperature,
                messages=[
                    {"role": "user", "content": prompt},
                ],
            )
            content = completion.choices[0].message.content or ""

            if not content:
                logger.warning(f"Sample {idx+1} returned empty content")

            prediction = _parse_prediction_content(content)

            pred_label = prediction.get("label") if isinstance(prediction, dict) else str(prediction)
            gt_label = item.get("label")
            logger.debug(f"Sample {idx+1} - True label: {gt_label}, Predicted label: {pred_label}")

            results.append(
                {
                    "inputs": item.get("inputs"),
                    "ground_truth": item.get("label"),
                    "prediction": prediction,
                    "index": item.get("index"),  # Save index column from dataset
                }
            )
        except Exception as e:
            error_count += 1
            logger.error(f"Error processing sample {idx+1}: {str(e)}", exc_info=True)
            results.append(
                {
                    "inputs": item.get("inputs"),
                    "ground_truth": item.get("label"),
                    "prediction": {"error": str(e)},
                    "index": item.get("index"),  # Save index column from dataset
                }
            )

    logger.info(
        f"Classification task completed - Total samples: {len(samples)}, "
        f"Success: {len(samples) - error_count}, Errors: {error_count}"
    )
    return results


def _normalize_label(label: Optional[str], experiment: str = "exp1") -> Optional[str]:
    """
    Normalize label format.
    Uses 5-label classification: Supportive, Indicator, Ideation, Behavior, Attempt
    
    Args:
        label: Original label
        experiment: Reserved parameter for interface compatibility
        
    Returns:
        Normalized label
    """
    if label is None:
        return None

    cleaned = str(label).strip()

    # Normalize label names (handle case and variants)
    label_mapping = {
        "supportive": "Supportive",
        "indicator": "Indicator",
        "ideation": "Ideation",
        "behavior": "Behavior",
        "attempt": "Attempt",
        # Compatible with old labels
        "no-risk": "Supportive",
        "no_risk": "Supportive",
        "nrisk": "Supportive",
    }

    cleaned_lower = cleaned.lower()
    if cleaned_lower in label_mapping:
        cleaned = label_mapping[cleaned_lower]

    # Use unified 5-label classification set
    if cleaned in VALID_LABELS:
        return cleaned

    # If cannot be identified, return original value (but should warn)
    logger = get_logger()
    logger.warning(f"Unknown label '{cleaned}', keeping original value")
    return cleaned


def _parse_prediction_content(content: str) -> Dict[str, Any]:
    """Extract JSON prediction result from model response, compatible with Markdown code blocks."""
    logger = get_logger()
    cleaned = content.strip()
    candidates = []

    for match in CODE_BLOCK_PATTERN.finditer(cleaned):
        candidates.append(match.group(1))

    candidates.append(cleaned)

    for candidate in candidates:
        try:
            parsed = json.loads(candidate)
            if isinstance(parsed, dict):
                return parsed
        except json.JSONDecodeError as e:
            logger.debug(f"JSON parsing failed: {str(e)}, candidate content: {candidate[:100]}...")
            continue

    logger.warning(f"Unable to parse as JSON, returning original content as label. Content preview: {cleaned[:200]}...")
    return {"label": cleaned, "confidence": None, "explanation": None}


def _convert_to_binary_labels(labels: List[str], experiment: str = "exp1") -> List[str]:
    """
    Convert multi-class labels to binary labels (with/without suicidal ideation).
    Uses 5-label classification: Supportive and Indicator are without suicidal ideation, Ideation/Behavior/Attempt are with suicidal ideation.
    
    Args:
        labels: Original label list
        experiment: Reserved parameter for interface compatibility
        
    Returns:
        Binary label list ("With Suicidal Ideation" or "Without Suicidal Ideation")
    """
    binary_labels = []
    # Define labels with suicidal ideation: Ideation, Behavior, Attempt
    # Supportive and Indicator are without suicidal ideation
    ideation_labels = {"Ideation", "Behavior", "Attempt"}
    
    for label in labels:
        if label in ideation_labels:
            binary_labels.append("With Suicidal Ideation")
        else:
            binary_labels.append("Without Suicidal Ideation")
    
    return binary_labels


def compute_confusion_matrix(
    y_true: List[str],
    y_pred: List[str],
    labels: List[str],
) -> Dict[str, Dict[str, int]]:
    """
    Calculate confusion matrix (dictionary format).
    
    Args:
        y_true: True label list
        y_pred: Predicted label list
        labels: List of all class labels
        
    Returns:
        Confusion matrix dictionary, format: {true_label: {pred_label: count}}
    """
    # Calculate confusion matrix dictionary
    cm_dict = {label: {p: 0 for p in labels} for label in labels}

    for true_label, pred_label in zip(y_true, y_pred):
        if true_label in cm_dict and pred_label in cm_dict[true_label]:
            cm_dict[true_label][pred_label] += 1

    return cm_dict


def score_classification(
    classification_results: List[Dict[str, Any]],
    experiment: str = "exp1",
    annotator_labels: Optional[List[List[str]]] = None,
) -> Dict[str, Any]:
    """
    Calculate evaluation metrics: Macro-F1, Binary F1-score, Precision, Recall, Confusion Matrix.
    Uniformly uses 5-label classification.
    
    Args:
        classification_results: List of classification results
        experiment: Reserved parameter for interface compatibility, actually uniformly uses 5-label classification
        annotator_labels: List of labels from multiple annotators (optional, reserved parameter for interface compatibility)
        
    Returns:
        Dictionary containing all evaluation metrics
    """
    logger = get_logger()
    logger.info(f"Starting score calculation - Results count: {len(classification_results)}")

    y_true = []
    y_pred = []
    per_sample = []

    # Collect true labels and predicted labels
    for idx, sample in enumerate(classification_results):
        gt_label_raw = sample.get("ground_truth")
        prediction = sample.get("prediction")

        # Normalize labels
        if isinstance(prediction, dict):
            pred_label_raw = prediction.get("label")
        elif isinstance(prediction, str):
            pred_label_raw = prediction
        else:
            pred_label_raw = None

        gt_label = _normalize_label(gt_label_raw, experiment)
        pred_label = _normalize_label(pred_label_raw, experiment)

        if gt_label is None:
            logger.warning(f"Sample {idx} has empty true label, skipping")
            continue

        if pred_label is None:
            # If predicted label is empty, use lowest risk label
            pred_label = "Supportive"

        y_true.append(gt_label)
        y_pred.append(pred_label)

        per_sample.append(
            {
                "index": sample.get("index", idx),  # Use index column from dataset, if not exists use enumeration index
                "ground_truth": gt_label,
                "prediction": pred_label,
                "correct": gt_label == pred_label,
            }
        )

    # Check overall label distribution before filtering to identify truly abnormal labels
    all_raw_labels = set(y_true) | set(y_pred)
    invalid_labels = all_raw_labels - VALID_LABELS
    if invalid_labels:
        logger.warning(f"Found invalid labels (will be filtered): {invalid_labels}")

    # Filter invalid labels (only keep the 5 valid labels defined uniformly)
    filtered_y_true = []
    filtered_y_pred = []
    filtered_per_sample = []
    
    for i, (true_lbl, pred_lbl, sample) in enumerate(zip(y_true, y_pred, per_sample)):
        if true_lbl in VALID_LABELS and pred_lbl in VALID_LABELS:
            filtered_y_true.append(true_lbl)
            filtered_y_pred.append(pred_lbl)
            filtered_per_sample.append(sample)
        else:
            logger.warning(f"Sample {i} has invalid labels (True: {true_lbl}, Pred: {pred_lbl}), skipping")
    
    y_true = filtered_y_true
    y_pred = filtered_y_pred
    per_sample = filtered_per_sample
    
    # Sort by severity: Supportive < Indicator < Ideation < Behavior < Attempt
    all_labels = [label for label in LABEL_ORDER if label in set(y_true) | set(y_pred)]
    
    if not all_labels:
        logger.error("No valid labels found after filtering!")
        all_labels = LABEL_ORDER  # Use default label list
    
    logger.info(f"Dataset contains classes: {all_labels}")

    # Calculate Macro-F1
    macro_f1 = f1_score(y_true, y_pred, labels=all_labels, average='macro', zero_division=0)
    logger.info(f"Macro-F1: {macro_f1:.4f}")

    # Calculate Binary F1-score (with/without suicidal ideation)
    y_true_binary = _convert_to_binary_labels(y_true, experiment)
    y_pred_binary = _convert_to_binary_labels(y_pred, experiment)
    binary_f1 = f1_score(y_true_binary, y_pred_binary, average='binary', pos_label='With Suicidal Ideation', zero_division=0)
    logger.info(f"Binary F1-score (With/Without Suicidal Ideation): {binary_f1:.4f}")

    # Calculate Precision and Recall
    # Macro average
    macro_precision = precision_score(y_true, y_pred, labels=all_labels, average='macro', zero_division=0)
    macro_recall = recall_score(y_true, y_pred, labels=all_labels, average='macro', zero_division=0)
    logger.info(f"Macro Precision: {macro_precision:.4f}")
    logger.info(f"Macro Recall: {macro_recall:.4f}")

    # Per-class Precision and Recall
    precision_per_class, recall_per_class, f1_per_class, support = precision_recall_fscore_support(
        y_true, y_pred, labels=all_labels, zero_division=0
    )
    precision_dict = {label: float(prec) for label, prec in zip(all_labels, precision_per_class)}
    recall_dict = {label: float(rec) for label, rec in zip(all_labels, recall_per_class)}

    logger.info("Per-class Precision:")
    for label, prec in precision_dict.items():
        logger.info(f"  {label}: {prec:.4f}")
    logger.info("Per-class Recall:")
    for label, rec in recall_dict.items():
        logger.info(f"  {label}: {rec:.4f}")

    # Calculate confusion matrix (image will be generated by visualization module when saving results)
    confusion_matrix = compute_confusion_matrix(
        y_true, y_pred, all_labels
    )
    logger.info("Confusion matrix computed (image will be generated when saving results)")

    # Aggregate results
    result = {
        "macro_f1": float(macro_f1),
        "binary_f1": float(binary_f1),
        "macro_precision": float(macro_precision),
        "macro_recall": float(macro_recall),
        "precision_per_class": precision_dict,
        "recall_per_class": recall_dict,
        "confusion_matrix": confusion_matrix,
        "per_sample": per_sample,
        "summary": {
            "total_samples": len(classification_results),
            "num_classes": len(all_labels),
            "classes": all_labels,
        }
    }

    logger.info("=" * 60)
    logger.info("Evaluation Results Summary:")
    logger.info(f"  Macro-F1: {macro_f1:.4f}")
    logger.info(f"  Binary F1-score (With/Without Suicidal Ideation): {binary_f1:.4f}")
    logger.info(f"  Macro Precision: {macro_precision:.4f}")
    logger.info(f"  Macro Recall: {macro_recall:.4f}")
    logger.info("=" * 60)

    return result


def format_metrics_summary(metrics: Dict[str, Any], experiment: str = "exp1") -> str:
    """
    Format evaluation results into readable text summary.
    Uniformly uses 5-label classification.
    """
    lines = []
    lines.append("=" * 80)
    lines.append("C-SSRS Classification Task Evaluation Report")
    lines.append("=" * 80)
    lines.append("")

    summary = metrics.get("summary", {})
    lines.append("[Sample Statistics]")
    lines.append(f"  Total Samples: {summary.get('total_samples', 0)}")
    lines.append(f"  Number of Classes: {summary.get('num_classes', 0)}")
    lines.append(f"  Class List: {', '.join(summary.get('classes', []))}")
    lines.append("")

    # Evaluation metrics
    lines.append("[Evaluation Metrics]")
    lines.append(f"  Macro-F1: {metrics.get('macro_f1', 0.0):.4f}")
    lines.append(f"  Binary F1-score (With/Without Suicidal Ideation): {metrics.get('binary_f1', 0.0):.4f}")
    lines.append(f"  Macro Precision: {metrics.get('macro_precision', 0.0):.4f}")
    lines.append(f"  Macro Recall: {metrics.get('macro_recall', 0.0):.4f}")
    lines.append("")

    # Per-class Precision and Recall
    precision_per_class = metrics.get("precision_per_class", {})
    recall_per_class = metrics.get("recall_per_class", {})
    if precision_per_class or recall_per_class:
        lines.append("[Per-class Precision]")
        for label, prec in sorted(precision_per_class.items()):
            lines.append(f"  {label}: {prec:.4f}")
        lines.append("")
        lines.append("[Per-class Recall]")
        for label, rec in sorted(recall_per_class.items()):
            lines.append(f"  {label}: {rec:.4f}")
        lines.append("")

    # Confusion matrix (text format)
    confusion_matrix = metrics.get("confusion_matrix", {})
    if confusion_matrix:
        lines.append("[Confusion Matrix (Text Format, see corresponding PNG file for visualization)]")
        labels = sorted(set(confusion_matrix.keys()) | set(confusion_matrix[list(confusion_matrix.keys())[0]].keys()))
        
        # Header
        header_label = "True\\Pred"
        header = f"{header_label:<15}"
        for pred_label in labels:
            header += f"{pred_label:<15}"
        lines.append(header)
        lines.append("-" * (15 * (len(labels) + 1)))
        
        # Table content
        for true_label in labels:
            row = f"{true_label:<15}"
            for pred_label in labels:
                count = confusion_matrix.get(true_label, {}).get(pred_label, 0)
                row += f"{count:<15}"
            lines.append(row)
        lines.append("")

    lines.append("=" * 80)

    return "\n".join(lines)


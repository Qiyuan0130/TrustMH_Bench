"""
C-SSRS project source code package initialization file.
"""


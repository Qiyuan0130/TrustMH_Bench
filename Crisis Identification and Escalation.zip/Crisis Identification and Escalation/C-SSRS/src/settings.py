"""
Global configuration for the C-SSRS project.
"""

from pathlib import Path
from openai import OpenAI

# Project path configuration
CURRENT_FILE = Path(__file__).resolve()
PROJECT_ROOT = CURRENT_FILE.parent.parent
DATA_DIR = PROJECT_ROOT / "data"
OUTPUT_DIR = PROJECT_ROOT / "outputs"

# API / model configuration
# NOTE: Replace the placeholder with your own API key when running locally.
API_KEY = "YOUR_API_KEY_HERE"
BASE_URL = "https://api.chatanywhere.tech/v1"
CLIENT = OpenAI(api_key=API_KEY, base_url=BASE_URL)

# Model configuration
CLASSIFICATION_MODEL = ""

# C-SSRS label definitions (5-class severity based on the original paper)
# From lower to higher severity:
# Supportive < Indicator < Ideation < Behavior < Attempt
C_SSRS_LABELS = {
    "Supportive": "Supportive reply: provides support, encouragement, and help.",
    "Indicator": "Suicidal indicator: uses risk-related language but mainly expresses empathy and support, not personal suicidal intent.",
    "Ideation": "Suicidal ideation: presence of suicidal thoughts but no concrete actions yet.",
    "Behavior": "Suicidal behavior: preparatory acts or clear expression of suicidal intent.",
    "Attempt": "Suicide attempt: an actual suicide attempt, regardless of outcome.",
}
"""
C-SSRS dataset classification prompt construction.
"""

from typing import List


def build_classification_prompt(
    conversation_input: List[str],
    dataset_id: str,
    experiment: str = "exp1"
) -> str:
    """
    Build classification prompt for C-SSRS dataset.
    Uses 5-label classification: Supportive, Indicator, Ideation, Behavior, Attempt
    
    Args:
        conversation_input: Input text list (usually has only one element, i.e., post text)
        dataset_id: Dataset identifier
        experiment: Reserved parameter for interface compatibility
        
    Returns:
        Formatted prompt string
    """
    # Merge input text
    text = "\n".join(conversation_input) if conversation_input else ""
    
    # Use 5-label classification
    labels_desc = """
### CATEGORIES (5-label classification)

Choose ONE category that best matches the user's posts:

1. **Supportive**: Supportive is defined as individuals engaging in discussion but with nolanguage that expressed any history of being at-risk in the past or the present. Some identified themselves as having backgroundin mental health care, while others did not define their motive forinteracting at all (as opposed to a family history). 

2. **Indicator**: Suicide Indicator category whichseparated those using at-risk language from those actively experi-encing general or acute symptoms. Oftentimes, users would engagein conversation in a supportive manner and share personal historywhile using at-risk words from the clinical lexicon. These usersmight express a history of divorce, chronic illness, death in thefamily, or suicide of a loved one, which are risk indicators on the C-SSRS, but would do so relating in empathy to users who expressedideation or behavior, rather than expressing a personal desire forself-harm. 

3. **Ideation**: Ideation is defined as thoughts of suicide includingpreoccupations with risk factors such as loss of job, loss of a strongrelationship, chronic disease, mental illness, or substance abuse.

4. **Behavior**: Behavior is operationalized as actions with higher risk. A user with suicidalbehavior confesses active or historical self-harm, or active plan-ning to commit suicide, or a history of being institutionalized formental health. Actions include cutting or using blunt force violence(self-punching and head strikes), heavy substance abuse, planningfor suicide attempt, or actions involving a means of death (holdingguns or knives, standing on ledges, musing over pills or poison,or driving recklessly). 

5. **Attempt**: Attempt is defined as any deliberate action that may result in intentionaldeath, be it a completed attempt or not, including but not limitedto attempts where a user called for help, changed their mind orwrote a public “good bye” note.
"""
    
    prompt = f"""You are an expert mental health AI specialized in analyzing Reddit posts for suicide risk assessment based on the Columbia-Suicide Severity Rating Scale (C-SSRS). Your task is to analyze a user's posts and classify them into the appropriate suicide risk severity level.

This dataset (C-SSRS) contains posts from Reddit users in mental health-related subreddits, specifically from SuicideWatch and related communities.

{labels_desc}

### INSTRUCTIONS

1. Carefully read and analyze ALL the posts provided for the user.
2. Consider the overall pattern and severity across all posts.
3. Only choose ONE label that best fits the user's overall risk level.
4. Return your answer as a JSON object like this:
{{
  "dataset_id": "{dataset_id}",
  "label": "<one of the categories above>",
  "explanation": "<brief explanation of your classification>"
}}

IMPORTANT: You MUST only classify the posts shown below. Do not reuse or return any other previous content. ONLY return the exact JSON response for this user.

User's Posts:
{text}
"""
    return prompt


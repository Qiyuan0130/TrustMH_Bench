"""
C-SSRS dataset loading and result saving utilities.
"""

import ast
import html
import json
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd


def load_dataset(
    dataset_path: Path,
    limit: Optional[int] = None
) -> List[Dict[str, Any]]:
    """
    Load C-SSRS dataset (CSV format).
    
    Args:
        dataset_path: CSV file path
        limit: Sample size limit, if None then return all data. Sequentially sample from front to back.
        
    Returns:
        Converted sample list, format: [{"inputs": [...], "label": "...", ...}, ...]
    """
    dataset_path = Path(dataset_path)
    
    if not dataset_path.exists():
        raise FileNotFoundError(f"Dataset file does not exist: {dataset_path}")
    
    # Read CSV file
    df = pd.read_csv(dataset_path, encoding="utf-8")
    
    print(f"Original dataset size: {len(df)} samples")
    
    # Data cleaning: remove invalid data
    # 1. Remove empty Post
    df = df[df["Post"].notna()]
    df = df[df["Post"].astype(str).str.strip() != ""]
    
    # 2. Remove empty Label
    df = df[df["Label"].notna()]
    df = df[df["Label"].astype(str).str.strip() != ""]
    
    print(f"Dataset size after cleaning: {len(df)} samples")
    
    # Sequential sampling: sample sequentially from front to back
    if limit is not None and limit < len(df):
        df = df.head(limit).reset_index(drop=True)
        print(f"Dataset size after sequential sampling: {len(df)} samples (first {limit} samples)")
    
    # Convert to unified format
    samples = []
    for idx, row in df.iterrows():
        try:
            # Parse Post column (list format string)
            post_str = str(row["Post"]).strip()
            try:
                # Use ast.literal_eval for safe parsing
                post_list = ast.literal_eval(post_str)
                if not isinstance(post_list, list):
                    post_list = [post_str]
            except (ValueError, SyntaxError):
                # If parsing fails, treat entire string as single post
                post_list = [post_str]
            
            # HTML entity decoding
            post_list = [html.unescape(str(post)) for post in post_list]
            
            # Merge all posts into single text
            post_text = " ".join(post_list)
            
            # Normalize label
            label = str(row["Label"]).strip()
            
            # Convert text to list format (compatible with other projects' format)
            inputs = [post_text]
            
            sample = {
                "inputs": inputs,
                "label": label,
                "post_text": post_text,
                "post_list": post_list,
                "user": str(row.get("User", f"user-{idx}")),
                "index": row.get("index", idx),  # Use index column from dataset, if not exists use row index
            }
            
            samples.append(sample)
        except Exception as e:
            print(f"Warning: Skipping sample {idx}, error: {e}")
            continue
    
    # Count label distribution
    label_counts = {}
    for sample in samples:
        label = sample["label"]
        label_counts[label] = label_counts.get(label, 0) + 1
    
    print(f"\nLabel distribution:")
    for label, count in sorted(label_counts.items()):
        print(f"  {label}: {count}")
    
    return samples


def save_results(results: Dict[str, Any], output_dir: Path) -> Path:
    """
    Save evaluation results to JSON file, and generate readable text summary and confusion matrix image.
    
    Args:
        results: Evaluation result dictionary
        output_dir: Output directory
        
    Returns:
        Saved JSON file path
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    timestamp = time.strftime("%Y%m%d_%H_%M_%S")
    model_name = _sanitize_filename_part(str(results.get("model") or "model"))
    task = _sanitize_filename_part(str(results.get("task") or "task"))
    sample_count = results.get("samples")
    sample_part = str(sample_count) if sample_count is not None else "unknown"
    filename_base = f"{model_name}-{task}-{timestamp}-{sample_part}"
    
    # Save JSON file
    json_path = output_dir / f"{filename_base}.json"
    with json_path.open("w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    
    # If evaluation results are included, also save readable text summary
    if "metrics" in results:
        try:
            from .classification import format_metrics_summary
            
            # Generate text summary
            summary_text = format_metrics_summary(results["metrics"])
            txt_path = output_dir / f"{filename_base}_summary.txt"
            with txt_path.open("w", encoding="utf-8") as f:
                f.write(summary_text)
        except Exception as e:
            # If summary generation fails, don't affect main flow
            print(f"Warning: Failed to generate text summary: {e}")
            import traceback
            traceback.print_exc()
    
    return json_path


def _sanitize_filename_part(value: str) -> str:
    """Replace special characters in filename with underscores."""
    if not value:
        return "unknown"
    forbidden = '/\\:*?"<>|'
    sanitized = "".join("_" if ch in forbidden else ch for ch in value)
    return sanitized.replace(" ", "_")


import argparse
from pathlib import Path
from typing import Any, Dict, Optional

from src.classification import run_classification, score_classification
from src.data_utils import load_dataset, read_protocol, save_results
from src.generation import run_generation
from src.judging import evaluate_generation_outputs
from src.settings import CLASSIFICATION_MODEL, GENERATION_MODEL
from src.visualization import plot_confusion_matrix_from_json


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Mental health classification/generation task evaluator")
    parser.add_argument(
        "--dataset",
        type=Path,
        default=Path("data/llms-mental-health-crisis-500.json"),
    )
    parser.add_argument(
        "--protocol",
        type=Path,
        default=Path("data/evaluation_protocol.csv"),
        help="Evaluation protocol CSV file containing label descriptions",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("outputs/results"),
        help="Output directory for results",
    )
    parser.add_argument(
        "--task",
        choices=["classification", "generation", "all"],
        default="all",
    )
    parser.add_argument("--limit", type=int, default=None, help="Use only first N samples")
    return parser.parse_args()


PROJECT_ROOT = Path(__file__).resolve().parent


def resolve_path(path: Path) -> Path:
    """Resolve relative path to absolute path relative to project root."""
    if path.is_absolute():
        return path
    candidate = PROJECT_ROOT / path
    return candidate


def prompt_with_default(message: str, default: Optional[str] = None) -> str:
    """Prompt user input with optional default value."""
    prompt = f"{message}"
    if default is not None:
        prompt += f" (default: {default})"
    prompt += ": "
    user_input = input(prompt).strip()
    return user_input or (default or "")


def interactive_setup(args: argparse.Namespace) -> None:
    """Display configuration and let user choose task and sample count before running."""
    dataset_path = resolve_path(args.dataset)
    protocol_path = resolve_path(args.protocol)
    output_dir = resolve_path(args.output)

    print("========== Runtime Configuration ==========")
    print(f"Dataset path: {dataset_path}")
    print(f"Protocol path: {protocol_path}")
    print(f"Output directory: {output_dir}")
    print(f"Default task: {args.task}")
    print(
        f"Default sample count: {args.limit if args.limit is not None else 'all'}"
    )
    print("============================================")

    task_options = {
        "1": "classification",
        "2": "generation",
        "3": "all",
    }
    task_choice = prompt_with_default(
        "Please select task type [1:classification 2:generation 3:all]",
        default="3",
    )
    if task_choice in task_options:
        args.task = task_options[task_choice]
    elif task_choice in task_options.values():
        args.task = task_choice
    else:
        print("Invalid input, keeping default task.")

    limit_choice = prompt_with_default(
        "Please enter test sample count (empty means all)",
        default=str(args.limit) if args.limit is not None else "",
    )
    if limit_choice:
        try:
            parsed_limit = int(limit_choice)
            if parsed_limit <= 0:
                raise ValueError
            args.limit = parsed_limit
        except ValueError:
            print("Invalid sample count input, keeping default value.")


def _determine_model_label(task: str) -> str:
    models = []
    if task in {"classification", "all"}:
        models.append(CLASSIFICATION_MODEL)
    if task in {"generation", "all"}:
        models.append(GENERATION_MODEL)
    if not models:
        return "unknown_model"
    seen = []
    for model in models:
        if model not in seen:
            seen.append(model)
    return "+".join(seen)


def run_pipeline(args: argparse.Namespace) -> Dict[str, Any]:
    dataset_path = resolve_path(args.dataset)
    protocol_path = resolve_path(args.protocol)
    output_dir = resolve_path(args.output)

    original_dataset_path = dataset_path
    original_samples, random_seed = load_dataset(dataset_path, args.limit)
    dataset_id = original_dataset_path.stem

    # Output label category information in sampled data before running models
    labels_in_sample = sorted(
        {
            str(item.get("label")).strip()
            for item in original_samples
            if item.get("label") is not None and str(item.get("label")).strip()
        }
    )
    print("========== Sampled Label Overview ==========")
    print(f"Sample count: {len(original_samples)}")
    print(f"Number of label types: {len(labels_in_sample)}")
    print(f"Label list: {labels_in_sample}")
    print("============================================")
    
    # Load protocol scales for evaluation
    print(f"[Protocol] Loading evaluation protocol from {protocol_path}...")
    try:
        _, label_scales = read_protocol(protocol_path)
        print(f"[Protocol] Protocol loaded successfully, containing evaluation criteria for {len(label_scales)} labels")
    except FileNotFoundError as e:
        print(f"[Error] Protocol file not found: {e}")
        raise
    except ValueError as e:
        print(f"[Error] Invalid protocol file: {e}")
        raise

    results: Dict[str, Any] = {
        "dataset": str(original_dataset_path),
        "protocol": str(args.protocol),
        "task": args.task,
        "samples": len(original_samples),
        "model": _determine_model_label(args.task),
        "sampled_labels": labels_in_sample,
    }
    
    # If sampling was performed, record the random seed used
    if random_seed is not None:
        results["random_seed"] = random_seed
        results["sampling_info"] = {
            "random_seed": random_seed,
            "sampled": True,
            "sample_count": len(original_samples),
        }

    if args.task in {"classification", "all"}:
        classification_results = run_classification(original_samples, dataset_id)
        classification_metrics = score_classification(
            classification_results,
        )
        results["classification"] = classification_results
        results["classification_metrics"] = classification_metrics

    if args.task in {"generation", "all"}:
        generation_results = run_generation(original_samples)
        generation_judgment = evaluate_generation_outputs(
            generation_results,
            label_scales,
        )
        results["generation"] = generation_results
        results["generation_judgment"] = generation_judgment

    return results


def main() -> None:
    args = parse_args()
    interactive_setup(args)
    results = run_pipeline(args)
    output_path = save_results(results, resolve_path(args.output))
    print(f"Results saved to: {output_path}")
    
    # Generate confusion matrix visualization if classification metrics are available
    if "classification_metrics" in results:
        try:
            print("Generating confusion matrix...")
            plot_confusion_matrix_from_json(
                output_path,
                output_path.parent,
                normalize=False,
            )
            # Also generate normalized version
            plot_confusion_matrix_from_json(
                output_path,
                output_path.parent,
                normalize=True,
            )
            print("Confusion matrix visualization completed!")
        except ImportError as e:
            print(f"Warning: Cannot generate visualization. Please ensure matplotlib and seaborn are installed: {e}")
        except Exception as e:
            print(f"Warning: Error occurred while generating confusion matrix: {e}")


if __name__ == "__main__":
    main()
